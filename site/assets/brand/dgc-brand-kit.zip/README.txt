DGC brand kit

DGC is the product name; Vibe DGC is the long form. Preserve paths and proportions. Violet: #7C5CFF.
