DGC harness comparison evidence

Harness: goose
Run: 90-task Aider polyglot slice, up to two rounds; round two resumes after a first-round failure. Each round has a 600-second allowance.
Machine-local repository, workspace, home, and temporary paths are normalized.
Task IDs, input hashes, timings, test results, usage totals, summary, and manifest remain.
Arbitrary harness stdout/stderr and test tails are intentionally omitted from the public bundle.
The manifests did not record the runner Git revision; see vibedgc.com/benchmark for limitations.
