"""dgc — an interactive coding-agent CLI harness for local LLMs."""

__version__ = "0.41.0"
