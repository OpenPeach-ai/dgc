"""DGC's look — one semantic-slot theme, read by both rich (markup/Style) and the
raw-ANSI surfaces (menu, logo, status line). No hardcoded colors anywhere else.

DGC is monochrome — near-black canvas, white text, neutral greys — with a single
purple accent. The one non-mono colour is `err` (a coding
tool must show errors in red). Everything is defined as RGB hex; `NO_COLOR`/non-TTY
degrade to plain text.
"""
from __future__ import annotations

import os
import unicodedata
from dataclasses import dataclass

from rich.text import Text

NO_COLOR = bool(os.environ.get("NO_COLOR"))


@dataclass(frozen=True)
class Theme:
    name: str
    # surfaces
    bg: str; surface: str; surface2: str; code: str
    band: str                       # the user-prompt band — a clearly-visible tinted lift off bg
    border: str; border_strong: str
    # text
    text: str; text_strong: str; muted: str; faint: str
    # the single accent (purple) + a bright lavender for glints/selection
    accent: str; accent_dim: str; accent_bright: str
    # semantic
    err: str; warn: str; ok: str
    # diff (monochrome: added brighter, removed faint)
    diff_add: str; diff_del: str


DARK = Theme(
    name="dark",
    bg="#0B0B0C", surface="#141416", surface2="#1A1A1D", code="#17171B",
    band="#242424",                 # a NEUTRAL dark grey band (Rgb 36,36,36) — the colour polished terminal
    #                                 CLIs use behind a submitted prompt. Neutral ON PURPOSE: any blue/purple
    #                                 tint collapses to navy/magenta when a 256-colour terminal downsamples it.
    #                                 Grey has no colour channel to collapse, so it stays a subtle grey lift at
    #                                 every depth (256 → idx 235 = rgb(38,38,38)). Don't add a hue here.
    border="#232326", border_strong="#303034",
    text="#F5F5F5", text_strong="#FFFFFF", muted="#9A9A9E", faint="#6A6A6E",
    accent="#7C5CFF", accent_dim="#6A4BF0", accent_bright="#A78BFA",
    err="#DC5A64", warn="#E0A24E", ok="#57C08A",
    diff_add="#F5F5F5", diff_del="#6A6A6E",
)

LIGHT = Theme(
    name="light",
    bg="#FFFFFF", surface="#F6F6F7", surface2="#EFEFF1", code="#F2F2F4",
    band="#DEDEDE",                 # neutral light-grey band (Rgb 222,222,222), one step lifted off the canvas
    border="#E6E6E8", border_strong="#D2D2D6",
    text="#141416", text_strong="#000000", muted="#5E5E64", faint="#8A8A90",
    accent="#5B3FE0", accent_dim="#4A31C8", accent_bright="#7C5CFF",
    err="#C43A44", warn="#B4791E", ok="#2E9E68",
    diff_add="#141416", diff_del="#9A9A9E",
)

THEMES = {"dark": DARK, "light": LIGHT}
_current = DARK


def theme() -> Theme:
    return _current


def _detect_theme() -> str:
    """Pick light/dark to MATCH the terminal, so `background: inherit` stays readable on either.
    Falls back to dark when we can't ask the terminal (non-TTY, no OSC-11 reply)."""
    import sys
    if not (sys.stdout.isatty() and sys.stdin.isatty()):
        return "dark"
    try:
        from . import termbg
        return "light" if termbg._terminal_is_light() else "dark"
    except Exception:
        return "dark"


def set_theme(name: str) -> bool:
    global _current
    if name == "auto":
        name = _detect_theme()
    t = THEMES.get(name)
    if t:
        _current = t
        return True
    return False


# --- colour helpers ----------------------------------------------------------
def _hex_rgb(h: str) -> tuple[int, int, int]:
    h = h.lstrip("#")
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def ansi_fg(h: str) -> str:
    """Truecolor foreground escape for the raw-ANSI surfaces; empty under NO_COLOR."""
    if NO_COLOR:
        return ""
    r, g, b = _hex_rgb(h)
    return f"\x1b[38;2;{r};{g};{b}m"


def lerp_rgb(a: str, b: str, t: float) -> str:
    """Blend two hex colours (t in 0..1) → '#rrggbb'. Used by the shimmer logo."""
    ar, ag, ab = _hex_rgb(a)
    br, bg, bb = _hex_rgb(b)
    t = 0.0 if t < 0 else 1.0 if t > 1 else t
    return "#%02x%02x%02x" % (round(ar + (br - ar) * t),
                              round(ag + (bg - ag) * t),
                              round(ab + (bb - ab) * t))


ANSI_BOLD = "" if NO_COLOR else "\x1b[1m"
ANSI_RESET = "" if NO_COLOR else "\x1b[0m"


# --- backward-compatible names used across the existing CLI (plain strings) ---
# Bound to the default dark theme. New mono+purple surfaces (logo, status, diff)
# read theme() directly so they honour /theme; the older markup stays dark.
BRAND = DARK.accent                 # rich markup colour, e.g. f"[{BRAND}]…[/]"
BRAND_MAGENTA = DARK.accent         # legacy alias — now purple, not magenta
DIM = DARK.faint                    # the one secondary grey (rich)
GRADIENT = ["#7C5CFF"]              # legacy; the banner no longer uses a gradient

# raw-ANSI for menu.py / logo / status
ANSI_BRAND = ansi_fg(DARK.accent)
ANSI_DIM = ansi_fg(DARK.faint)


def detect_color_depth():
    """The terminal's colour depth as a prompt_toolkit ColorDepth — one source of truth
    (detect + adapt). 24-bit when $COLORTERM advertises truecolor OR the terminal is a
    known truecolor emulator (rescues tmux/SSH sessions that strip COLORTERM); else 256,
    so we downsample cleanly instead of dumping 24-bit codes a terminal mangles to rainbow.
    """
    from prompt_toolkit.output import ColorDepth
    if NO_COLOR:
        return ColorDepth.DEPTH_4_BIT
    ct = os.environ.get("COLORTERM", "").lower()
    if "truecolor" in ct or "24bit" in ct:
        return ColorDepth.DEPTH_24_BIT
    # brand allowlist — known 24-bit terminals that don't always export COLORTERM
    tp = os.environ.get("TERM_PROGRAM", "").lower()
    term = os.environ.get("TERM", "").lower()
    if (os.environ.get("WT_SESSION")                      # Windows Terminal
            or tp in ("vscode", "iterm.app", "wezterm", "ghostty", "rio", "warp", "hyper")
            or any(b in term for b in ("kitty", "alacritty", "foot", "wezterm", "rio", "ghostty"))):
        return ColorDepth.DEPTH_24_BIT
    return ColorDepth.DEPTH_8_BIT


def rich_color_system() -> str:
    """rich's `color_system` string matching the terminal's REAL depth (same source of truth
    as detect_color_depth). Forcing rich to "truecolor" makes it emit 24-bit codes that a
    non-truecolor terminal downsamples to a blue/cyan mush with black code-block bands — the
    readability bug. Instead let rich downsample hex → 256/16 cleanly for the actual terminal."""
    from prompt_toolkit.output import ColorDepth
    d = detect_color_depth()
    if d == ColorDepth.DEPTH_24_BIT:
        return "truecolor"
    if d == ColorDepth.DEPTH_4_BIT:
        return "standard"
    return "256"


def terminal_safe_text(value) -> str:
    """Return literal terminal data without executable control or format characters.

    Newlines, tabs, and the Unicode joiners needed for ordinary scripts/emoji retain useful layout.
    Other C0/C1 controls and format characters are made visible, so model, tool, provider,
    repository, and hook data cannot inject ANSI/OSC sequences, carriage-return rewrites, bidi
    overrides, or invisible labels into a terminal renderer. This is a display-only boundary;
    stored/model-visible source stays exact.
    """
    text = str(value if value is not None else "")
    out: list[str] = []
    for char in text:
        if char in ("\n", "\t"):
            out.append(char)
        elif (unicodedata.category(char) == "Cc"
              or (unicodedata.category(char) == "Cf" and char not in ("\u200c", "\u200d"))):
            code = ord(char)
            out.append(f"\\u{code:04x}" if code <= 0xFFFF else f"\\U{code:08x}")
        else:
            out.append(char)
    return "".join(out)


def section(console, title: str, note: str | None = None) -> None:
    """A list header: blank line, bold-white title, optional dim '— note'."""
    line = Text("\n  ")
    line.append(terminal_safe_text(title), style="bold")
    if note:
        line.append("  — " + terminal_safe_text(note), style=theme().faint)
    console.print(line, highlight=False)


def list_none(console, s: str = "none yet") -> None:
    console.print(Text("  " + terminal_safe_text(s), style=theme().faint), highlight=False)


def next_step(console, s: str) -> None:
    console.print(Text("\n  " + terminal_safe_text(s), style=theme().faint), highlight=False)
