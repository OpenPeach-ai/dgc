"""Interactive CLI for dgc — REPL, slash commands, streaming render,
approval prompts and plan-mode approval flow."""
from __future__ import annotations

import argparse
import json
import os
import re
import shlex
import sys
import threading
import time
import webbrowser
from pathlib import Path

from prompt_toolkit import PromptSession
from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.history import FileHistory
from rich.console import Console
from rich.markup import escape as escape_markup
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from . import (__version__, attachments as attachments_mod, glyphs, logo as logo_mod,
               memory as memory_mod, render, sessions as sessions_mod)
from . import style as style_mod
from .agent import Agent
from .commands import (canonical_command_name, command_pairs_with_custom, command_specs,
                       custom_command_names)
from .config import (PROVIDERS, SEARCH_PROVIDERS, USER_CONFIG, USER_HOME, Config,
                     normalize_custom_base_url)
from .llm import LLMError
from .menu import select as menu_select
from .permissions import DISPLAY, MODES, MODE_DESCRIPTIONS, Rule, rule_for
from .redaction import redact_text, redact_value, secret_values
from .style import (ANSI_DIM, ANSI_RESET, BRAND, BRAND_MAGENTA, DIM, section,
                    terminal_safe_text)
from .tools import TOOL_SCHEMAS

from .update import (  # update-check lives in its own module so the TUI can share it
    UPDATE_CACHE, VERSION_URL, cached_update, refresh_update_async, run_update)


def _markup_literal(value) -> str:
    """Dynamic terminal data safe for insertion inside DGC-owned Rich markup."""
    return escape_markup(terminal_safe_text(value))


def _literal_cell(value, *, style: str | None = None) -> Text:
    """Literal terminal-safe cell for Rich tables and panels."""
    return Text(terminal_safe_text(value), style=style)


def auto_warning(console: Console) -> None:
    console.print(Panel(
        "full-auto approves [bold]every[/bold] file write and shell command with no prompts.\n"
        "Only use it on code and a directory you trust.",
        title="[bold red]⚠ auto mode[/bold red]", border_style="red", expand=False))


MODE_CYCLE = ["default", "acceptEdits", "plan", "auto"]
# mono + purple: muted / accent / lavender / red (auto stays red as a danger signal)
MODE_COLOR = {"default": "#9A9A9E", "acceptEdits": "#7C5CFF", "plan": "#A78BFA", "auto": "#DC5A64"}
THINK_LEVELS = ["off", "low", "medium", "high", "xhigh"]
DELEGATED_THINK_LEVELS = [*THINK_LEVELS, "max"]


# What a shell reports for a process a closed pipe (SIGPIPE, 13) ended: 128 + 13.
EXIT_READER_GONE = 141


class _StdoutConsole(Console):
    """The terminal's console. Rich answers a closed stdout with SystemExit(1) from inside whatever
    was printing, so `dgc -p … --output-format text | head -1` exited 1, the code of a failed turn,
    while the same run with --output-format json (its writes raise BrokenPipeError) exited 141."""

    def on_broken_pipe(self) -> None:
        self.quiet = True
        _silence_stdout()               # the interpreter's own last flush must not print a traceback
        raise SystemExit(EXIT_READER_GONE)


class UI:
    """All user-facing rendering + interaction. The agent calls back into this."""

    def __init__(self):
        self.console = _StdoutConsole(theme=render.markdown_theme(), highlight=False)
        self._theme_pushed = False   # did refresh_theme() already stack a palette on this console?
        self._thinking = False
        self._streamed = False
        self._rule_hook = None  # set by CLI: fn(rule_text) -> None
        self._live = None       # set by CLI during a live turn: the key-reader that owns stdin
        self._work_stop = None  # set while a "working…" spinner is running
        self._tool_count = 0    # tools used in the current turn (for the done marker)
        self.deny_reason = ""   # optional steer captured when the user denies a tool
        self.plan_feedback = "" # one-shot steer captured when the user rejects a plan
        self.non_interactive = False   # `dgc -p`: never wait on a menu, answer on the spot

    def refresh_theme(self) -> None:
        """Re-resolve this console's palette after /bg or /theme changed it.

        A rich Theme is baked into a Console when it is built, so the console the classic CLI has
        been printing through kept emitting dark-palette markdown onto a canvas `/bg light` had
        just turned white. Push onto the SAME console object rather than building a new one:
        `CLI.console` is an alias of it, and a replacement would leave that alias behind.
        """
        if getattr(self, "_theme_pushed", False):
            self.console.pop_theme()
        self.console.push_theme(render.markdown_theme())
        self._theme_pushed = True

    # --------------------------------------------------- working indicator ---
    def start_working(self, label: str = "working") -> None:
        """Show a live spinner from submit until the first token/tool — so the user
        knows the model is loading/generating, not that the CLI hung."""
        if not sys.stdout.isatty():
            return
        label = terminal_safe_text(label).replace("\n", " ")
        self.stop_working()
        stop = threading.Event()
        self._work_stop = stop

        def spin() -> None:
            frames = glyphs.THINK_FRAMES
            acc, dim, rst = style_mod.ansi_fg(style_mod.theme().accent), ANSI_DIM, ANSI_RESET
            t0, i = time.time(), 0
            while not stop.wait(0.14):
                el = int(time.time() - t0)
                et = f" {el}s" if el else ""
                sys.stdout.write(f"\r  {acc}{frames[i % len(frames)]}{rst} {dim}{label}…{et}"
                                 f"   {glyphs.MIDDOT} esc to stop{rst}\x1b[K")
                sys.stdout.flush()
                i += 1
        threading.Thread(target=spin, daemon=True).start()

    def stop_working(self) -> None:
        stop = self._work_stop
        if stop and not stop.is_set():
            stop.set()
            if sys.stdout.isatty():
                sys.stdout.write("\r\x1b[K")   # wipe the spinner line before real output
                sys.stdout.flush()
        self._work_stop = None

    def turn_complete(self, elapsed: float, cancelled: bool = False,
                      failed: bool = False) -> None:
        """A clear end-of-turn delimiter so the user knows the model is done and it's
        their turn — not still working, not waiting on a follow-up."""
        self.stop_working()
        if self._streamed:                       # close off any mid-stream line
            self.console.print()
            self._streamed = False
        if not sys.stdout.isatty():              # scripts / pipes don't want a UX marker
            return
        verb = "stopped" if cancelled else ("failed" if failed else "done")
        parts = [f"{elapsed:.0f}s"]
        if self._tool_count:
            parts.append(f"{self._tool_count} tool" + ("" if self._tool_count == 1 else "s"))
        self.console.print(f"  [{DIM}]· {verb} · {' · '.join(parts)}[/]", highlight=False)

    def _yield_stdin(self) -> None:
        """If a live key-reader owns stdin during this turn, ask it to release before we input()."""
        self.stop_working()
        live = self._live
        if live and live["active"].is_set():
            live["stop"].set()
            live["released"].wait(timeout=2)

    # ------------------------------------------------ streaming callbacks ---
    def on_text(self, chunk: str) -> None:
        self.stop_working()
        if self._thinking:
            self.console.print()
            self._thinking = False
        self.console.print(terminal_safe_text(chunk), end="", markup=False, highlight=False,
                           soft_wrap=True)
        self.console.file.flush()  # stream live — rich/stdout otherwise buffers until a newline
        self._streamed = True

    def on_thinking(self, chunk: str, block=None) -> None:
        self.stop_working()
        key = getattr(block, "key", None)
        if not self._thinking or (block is not None and key != getattr(self, "_thinking_key", None)):
            if self._thinking:
                self.console.print()
            from .reasoning import cli_thinking_label
            label = cli_thinking_label(getattr(block, "source", "unknown"),
                                       getattr(block, "provider", ""))
            self.console.print(f"\n[dim italic]{_markup_literal(label)}[/] ", end="")
            self._thinking = True
        self._thinking_key = key
        self.console.print(terminal_safe_text(chunk), end="", markup=False, highlight=False,
                           style="dim italic")
        self.console.file.flush()
        self._streamed = True

    def on_thinking_end(self, block) -> None:
        source = getattr(block, "source", "unknown")
        if source == "withheld":
            self.stop_working()
            if self._streamed:
                self.console.print()
            from .reasoning import cli_thinking_label
            label = cli_thinking_label(source, getattr(block, "provider", ""))
            self.console.print(f"[dim italic]{_markup_literal(label)}[/]", highlight=False)
            self._streamed = False
            self._thinking = False
        elif source == "narration" and getattr(block, "placement", "") == "inline":
            self.console.print(" · summarized", end="", markup=False, highlight=False, style="dim")
            self.console.file.flush()

    def end_stream(self, phase: str = "") -> None:
        # The REPL prints one prose stream per round and has no turn envelope to designate an
        # answer inside, so the phase is accepted and intentionally unused.
        if self._streamed:
            self.console.print()
            self._streamed = False
            self._thinking = False

    def turn_activity(self, state: str, label: str, detail: str = "") -> None:
        """The REPL's spinner already names its own phase; the loop's activity adds nothing here."""

    def model_wait(self, label, detail: str = "", *, since=None, restore: bool = True,
                   origin=None) -> None:
        """A silent model request renames a live spinner ("No response from the model…"). Tokens
        resuming stop the spinner themselves, so clearing needs nothing here."""
        if label and self._work_stop is not None and sys.stdout.isatty():
            self.start_working(str(label))

    # ------------------------------------------------------ tool rendering ---
    def tool_call(self, name: str, args: dict, call_id: str | None = None) -> None:
        self.stop_working()
        self._tool_count += 1
        summary = self._arg_summary(name, args)
        self.console.print(f"\n[bold {BRAND}]{glyphs.tool_icon(name)} {_markup_literal(name)}[/] "
                           f"[{DIM}]{_markup_literal(summary)}[/]", highlight=False)

    def tool_progress(self, name: str, message: str, *, progress=None, total=None,
                      level: str = "", call_id: str | None = None) -> None:
        self.stop_working()
        amount = ""
        if isinstance(progress, (int, float)) and not isinstance(progress, bool):
            if isinstance(total, (int, float)) and not isinstance(total, bool) and total:
                amount = f" · {progress:g}/{total:g} ({max(0, min(100, progress / total * 100)):.0f}%)"
            else:
                amount = f" · {progress:g}"
        color = "red" if level in ("error", "critical", "alert", "emergency") else DIM
        # MCP text is untrusted server output, not Rich markup.
        self.console.print(f"  · {terminal_safe_text(message)[:500]}{amount}", style=color, markup=False,
                           highlight=False)
        self.start_working(name)

    def tool_result(self, name: str, out: str, call_id: str | None = None) -> None:
        out = terminal_safe_text(out)
        if "\n--- " in out or out.startswith("---"):
            diff = out[out.find("---"):]
            if len(diff) < 8000:
                self.console.print(render.render_diff(diff))
                self.start_working()                         # spin again until the next step
                return
        lines = out.splitlines()
        for ln in lines[:12]:                                # flat, 2-space indented (no box)
            self.console.print("  " + ln, style=DIM, markup=False, highlight=False, soft_wrap=True)
        if len(lines) > 12:
            self.console.print(f"  … ({len(lines) - 12} more lines)", style=DIM,
                               markup=False, highlight=False)
        self.start_working()                                 # spin again until the next step

    def tool_images(self, call_id, images, caption: str = "", *, items=None, omitted: int = 0,
                    meta=None) -> None:
        """images: one dim line per image the step produced; the pixels stay in the chat panels."""
        for row in (meta or []):
            if not isinstance(row, dict):
                continue
            width, height = int(row.get("width") or 0), int(row.get("height") or 0)
            shape = f"{width}×{height}" if width and height else ""
            path = terminal_safe_text(str(row.get("path") or ""))
            if path:
                line = f"  ↳ image: {path}" + (f" ({shape})" if shape else "")
            else:
                name = terminal_safe_text(str(row.get("name") or "image"))
                line = f"  ↳ image: {name} (" + (f"{shape}, " if shape else "") + "not saved)"
            self.console.print(line, style=DIM, markup=False, highlight=False, soft_wrap=True)
        if omitted:
            self.console.print(f"  ↳ {int(omitted)} more image{'s' if int(omitted) != 1 else ''} not kept",
                               style=DIM, markup=False, highlight=False)

    def tool_denied(self, name: str, args: dict, reason: str,
                    call_id: str | None = None) -> None:
        self.stop_working()
        self.console.print(
            f"[bold red]✗ {_markup_literal(name)} denied[/bold red] "
            f"[{DIM}]{_markup_literal(reason)}[/]", highlight=False)

    def hook_activity(self, event: str, status: str, *, configured: int = 0,
                      duration_ms: int = 0, message: str = "") -> None:
        if status == "started":
            return
        detail = f" · {terminal_safe_text(message)}" if message else ""
        self.console.print(
            f"  · hook {terminal_safe_text(event)} {terminal_safe_text(status)} · "
            f"{configured} configured · {duration_ms}ms{detail}",
            style="red" if status not in ("completed",) else DIM,
            markup=False, highlight=False)

    @staticmethod
    def _arg_summary(name: str, args: dict) -> str:
        """The one argument worth showing beside a tool name — DGC's own keys first, then the keys
        a delegated vendor tool uses (Claude's `Read`/`Edit` carry `file_path`, Codex's `shell` a
        `command` list), so a subscription turn's cards are not blank."""
        for key in ("path", "file_path", "command", "cmd", "pattern", "query", "url", "name",
                    "memory", "symbol", "operation", "description"):
            if key in args and args[key] not in (None, ""):
                raw = args[key]
                if isinstance(raw, (list, tuple)):
                    raw = " ".join(str(v) for v in raw)
                value = terminal_safe_text(raw).replace("\n", " ")
                return value[:120] + ("…" if len(value) > 120 else "")
        return ""

    # ---------------------------------------------------------- approvals ---
    def approve(self, name: str, args: dict, call_id: str | None = None) -> str:
        """Return 'once' | 'always' | 'no'."""
        if getattr(self, "non_interactive", False):
            # A one-shot run from a terminal used to block on this arrow menu. A script has
            # nobody to answer it: deny, and tell the model and the user how to pre-approve.
            rule = rule_for(name, args)
            self.stop_working()
            self.console.print(f"  [{DIM}]permission needed for {_markup_literal(name)} — denied: a -p run "
                               f"never waits on a menu; rerun with --allow-tool \"{_markup_literal(rule)}\" "
                               f"or --mode acceptEdits|auto[/]", highlight=False)
            self.deny_reason = (f"non-interactive run: permission was not granted; the user can rerun "
                                f"with --allow-tool \"{rule}\" or --mode acceptEdits|auto")
            return "no"
        self._yield_stdin()
        section(self.console, "permission requested", name)
        if name == "bash":
            self.console.print(render.mono_syntax(
                terminal_safe_text(args.get("command", "")), "bash"))
        else:
            summary = self._arg_summary(name, args)
            if summary:
                self.console.print(f"  [{DIM}]{_markup_literal(summary)}[/]", highlight=False)
        rule = rule_for(name, args)
        idx = menu_select("Allow this?",
                          ["allow once", "always allow", "deny"],
                          ["just this time", f"add rule {terminal_safe_text(rule)}", "block it"])
        if idx in (0, 1):
            return {0: "once", 1: "always"}[idx]
        # denied (or esc) — capture optional feedback so the model can adjust in one step
        try:
            self.deny_reason = input("  why / what to do instead (optional) › ").strip()
        except (EOFError, KeyboardInterrupt):
            self.deny_reason = ""
        return "no"

    def present_plan(self, plan: str):
        """Return target mode string on approval, or None to keep planning."""
        if not getattr(self, "non_interactive", False):
            self._yield_stdin()
        section(self.console, "📋 proposed plan")
        self.console.print(render.render_markdown(terminal_safe_text(plan or "(empty plan)")))
        if getattr(self, "non_interactive", False):
            self.console.print(f"  [{DIM}]plan reported, not executed: a -p run cannot approve it — "
                               f"rerun with --mode acceptEdits|auto to build it[/]", highlight=False)
            self.plan_feedback = ("non-interactive run: the plan cannot be approved here; stop and "
                                  "report it as your final answer")
            return None
        idx = menu_select("Approve this plan?",
                          ["build with acceptEdits", "build in default", "build in full-auto",
                           "keep planning"],
                          ["auto-approve edits", "ask per action", "approve everything",
                           "reject & refine"])
        target = {0: "acceptEdits", 1: "default", 2: "auto"}.get(idx)
        if target == "auto":
            auto_warning(self.console)
            try:
                confirmed = input("  execute this plan in full-auto? [y/N] › ").strip().lower() in ("y", "yes")
            except (EOFError, KeyboardInterrupt):
                confirmed = False
            if not confirmed:
                self.plan_feedback = "Full-auto was not confirmed; offer a safer execution mode."
                return None
        if target:
            self.plan_feedback = ""
            return target
        try:
            self.plan_feedback = input("  feedback for the plan (optional): ").strip()
        except EOFError:
            self.plan_feedback = ""
            return None
        if self.plan_feedback:
            self.console.print(f"  [{DIM}]feedback noted — the agent will see your denial[/]")
        return None

    def ask_questions(self, questions: list[dict], call_id=None) -> dict:
        """Model-driven questions: arrow menu per question, cursor on the recommended option.

        One question is asked directly; several get a review screen whose Submit settles the batch
        (an unanswered question counts as skipped). Esc closes the question without an answer.
        """
        if getattr(self, "non_interactive", False):
            first = questions[0]["question"] if questions else ""
            self.console.print(f"  [{DIM}]question skipped in a -p run: {_markup_literal(first)}[/]",
                               highlight=False)
            return {"outcome": "unavailable", "answers": {}}
        self._yield_stdin()
        self.stop_working()
        answers: dict = {}
        if len(questions) == 1:
            entry = self._ask_one_question(questions[0])
            if entry is None:
                return {"outcome": "dismissed", "answers": {}}
            return {"outcome": "answered", "answers": {questions[0]["id"]: entry}}
        while True:
            def shown(q):
                entry = answers.get(q["id"])
                if entry is None:
                    return "not answered"
                picks = [q["options"][i]["label"] for i in entry["selected"]]
                text = ", ".join(picks + ([entry["other"]] if entry["other"] else []))
                return terminal_safe_text(text or "skipped")
            idx = menu_select("Questions — answer each, then Submit",
                              [terminal_safe_text(q["header"]) for q in questions] + ["Submit"],
                              [shown(q) for q in questions]
                              + [f"{len(answers)}/{len(questions)} answered · the rest are skipped"])
            if idx is None:
                return {"outcome": "dismissed", "answers": {}}
            if idx == len(questions):
                return {"outcome": "answered", "answers": {
                    q["id"]: answers.get(q["id"], {"selected": [], "other": ""}) for q in questions}}
            entry = self._ask_one_question(questions[idx])
            if entry is not None:
                answers[questions[idx]["id"]] = entry

    def _ask_one_question(self, q: dict) -> dict | None:
        """One question's answer ``{selected, other}``; None when the user pressed Esc."""
        from .questions import MAX_ANSWER
        options = q["options"]
        recommended = next((i for i, o in enumerate(options) if o["recommended"]), 0)
        hints = [("recommended · " if o["recommended"] else "") + terminal_safe_text(o["description"])
                 for o in options]
        if q.get("multi_select"):
            section(self.console, terminal_safe_text(q["question"]))
            for i, (o, hint) in enumerate(zip(options, hints), 1):
                self.console.print(f"  {i}) {_markup_literal(terminal_safe_text(o['label']))}"
                                   + (f"  [{DIM}]{_markup_literal(hint)}[/]" if hint else ""),
                                   highlight=False)
            try:
                raw = input("  comma-separated numbers (blank = skip) › ").strip()
                selected = sorted({int(part) - 1 for part in raw.replace(" ", ",").split(",") if part.strip()})
                note = input("  something else? (optional) › ").strip()
            except (EOFError, KeyboardInterrupt):
                return None
            except ValueError:
                self.info("Use the option numbers, separated by commas.")
                return self._ask_one_question(q)
            if any(not 0 <= i < len(options) for i in selected):
                self.info("Use the option numbers shown.")
                return self._ask_one_question(q)
            return {"selected": selected, "other": note[:MAX_ANSWER]}
        idx = menu_select(terminal_safe_text(q["question"] or "Choose one"),
                          [terminal_safe_text(o["label"]) for o in options] + ["Something else…", "Skip this question"],
                          hints + ["type your own answer", ""], initial=recommended)
        if idx is None:
            return None
        if idx == len(options):
            try:
                raw = input("  › ").strip()
            except (EOFError, KeyboardInterrupt):
                return None
            return {"selected": [], "other": raw[:MAX_ANSWER]}
        if idx == len(options) + 1:
            return {"selected": [], "other": ""}
        return {"selected": [idx], "other": ""}

    def options_resolved(self, call_id, outcome, questions, answers) -> None:
        from .questions import asked_summary
        if getattr(self, "non_interactive", False):
            return                      # a -p run already said the question was skipped
        lines = asked_summary(questions, answers, outcome)
        self.console.print(f"  [{DIM}]▸ {_markup_literal(terminal_safe_text(lines[0]))}[/]", highlight=False)
        for line in lines[1:]:
            self.console.print(f"    [{DIM}]{_markup_literal(terminal_safe_text(line))}[/]", highlight=False)

    def mcp_capabilities(self) -> dict:
        return {"sampling": {}, "elicitation": {"form": {}, "url": {}}}

    def mcp_input(self, server: str, kind: str, payload: dict, *, cancel=None) -> dict:
        """Review one MCP server request. Nothing is sampled, opened, or disclosed by default."""
        self._yield_stdin()
        self.stop_working()
        section(self.console, "MCP input requested", str(server)[:120])
        if cancel is not None and cancel.is_set():
            return {"action": "cancel"}
        if kind in ("sampling_request", "sampling_response"):
            title = ("Let this server ask your model?" if kind == "sampling_request"
                     else "Share this sampled response with the server?")
            self.console.print(title, style="bold", markup=False)
            self.console.print(terminal_safe_text(
                json.dumps(payload, ensure_ascii=False, indent=2))[:12_000],
                               style=DIM, markup=False, highlight=False, soft_wrap=True)
            idx = menu_select("MCP sampling consent", ["approve once", "decline", "cancel"],
                              ["continue this request", "tell the server no", "dismiss"])
            if cancel is not None and cancel.is_set():
                return {"action": "cancel"}
            return {"action": {0: "accept", 1: "decline"}.get(idx, "cancel")}
        if kind != "elicitation":
            return {"action": "cancel"}

        message = terminal_safe_text(payload.get("message") or "")
        self.console.print(message, markup=False, highlight=False, soft_wrap=True)
        if payload.get("mode") == "url":
            url = str(payload.get("url") or "")
            host = terminal_safe_text(payload.get("host") or "")
            self.console.print(f"Host: {host}", style="bold", markup=False)
            self.console.print(terminal_safe_text(url), style=DIM, markup=False, highlight=False,
                               soft_wrap=True)
            if payload.get("suspicious_host"):
                self.console.print("Warning: this host contains Punycode; inspect it carefully.",
                                   style="bold red", markup=False)
            idx = menu_select("Open this exact URL?", ["open in browser", "decline", "cancel"],
                              ["navigate outside DGC", "tell the server no", "dismiss"])
            if idx != 0:
                return {"action": "decline" if idx == 1 else "cancel"}
            if cancel is not None and cancel.is_set():
                return {"action": "cancel"}
            try:
                opened = webbrowser.open(url, new=2)
            except Exception:
                opened = False
            if not opened:
                self.error("could not open the MCP URL in a browser")
                return {"action": "cancel"}
            return {"action": "accept"}

        schema = payload.get("requestedSchema") or {}
        properties = schema.get("properties") or {}
        required = set(schema.get("required") or [])
        from .mcp import MCPInputError, _form_options, validate_elicitation_response

        while True:
            content: dict = {}
            try:
                for key, field in properties.items():
                    label = terminal_safe_text(field.get("title") or key)
                    optional = key not in required
                    options = _form_options(field)
                    kind_name = field.get("type")
                    if kind_name == "array":
                        shown = [terminal_safe_text(item.get("title")) for item in
                                 (field.get("items") or {}).get("anyOf", [])] or options
                        self.console.print(f"  {label}: " + ", ".join(
                            f"{i + 1}={name}" for i, name in enumerate(shown)), markup=False)
                        raw = input("  choose comma-separated numbers" +
                                    (" (blank skips)" if optional else "") + " › ").strip()
                        if not raw and optional:
                            continue
                        picks = [] if not raw else [int(part.strip()) - 1 for part in raw.split(",")]
                        content[key] = [options[i] for i in picks if 0 <= i < len(options)]
                    elif options:
                        labels = ([terminal_safe_text(item.get("title"))
                                   for item in field.get("oneOf", [])]
                                  or [terminal_safe_text(item)
                                      for item in (field.get("enumNames") or [])]
                                  or [terminal_safe_text(item) for item in options])
                        rows = list(labels) + (["skip"] if optional else [])
                        idx = menu_select(label, rows, [""] * len(rows))
                        if idx is None or (optional and idx == len(labels)):
                            continue
                        content[key] = options[idx]
                    elif kind_name == "boolean":
                        rows = ["yes", "no"] + (["skip"] if optional else [])
                        idx = menu_select(label, rows, [""] * len(rows))
                        if idx is None or (optional and idx == 2):
                            continue
                        content[key] = idx == 0
                    else:
                        default = field.get("default")
                        hint = f" [{default}]" if default is not None else ""
                        raw = input(f"  {label}{hint}{' (optional)' if optional else ''} › ").strip()
                        if not raw and default is not None:
                            value = default
                        elif not raw and optional:
                            continue
                        elif kind_name == "integer":
                            value = int(raw)
                        elif kind_name == "number":
                            value = float(raw)
                        else:
                            value = raw
                        content[key] = value
                candidate = validate_elicitation_response(
                    payload, {"action": "accept", "content": content})
            except (EOFError, KeyboardInterrupt):
                return {"action": "cancel"}
            except (ValueError, IndexError, MCPInputError) as exc:
                self.error(f"invalid form response: {exc}")
                continue
            self.console.print("Review before sharing:", style="bold", markup=False)
            self.console.print(terminal_safe_text(
                json.dumps(candidate["content"], ensure_ascii=False, indent=2)),
                               style=DIM, markup=False, highlight=False)
            idx = menu_select("Send this form to the MCP server?",
                              ["submit", "edit", "decline", "cancel"],
                              ["share these exact values", "change answers", "tell the server no", "dismiss"])
            if cancel is not None and cancel.is_set():
                return {"action": "cancel"}
            if idx == 0:
                return candidate
            if idx == 2:
                return {"action": "decline"}
            if idx != 1:
                return {"action": "cancel"}

    # ---------------------------------------------------------------- misc ---
    def on_todo(self, todos: list) -> None:
        self.stop_working()
        if not todos:
            return
        marks = {"done": "[green]☑[/green]", "in_progress": f"[{BRAND}]◐[/]", "pending": f"[{DIM}]☐[/]",
                 "blocked": "[red]⊘[/red]"}
        section(self.console, "todos")
        for t in todos:
            self.console.print(
                f"  {marks.get(t['status'], '☐')} {_markup_literal(t['content'])}",
                highlight=False)

    def artifact_ready(self, art) -> None:
        self.info(f"artifact ready: {art.name} · {art.url}")

    def goal_changed(self, goal: str, status: str) -> None:
        self.info(f"standing goal → {status}: {goal[:120]}")

    def info(self, msg: str) -> None:
        self.stop_working()
        self.console.print(
            f"  [{DIM}]· {_markup_literal(msg)}[/]", highlight=False)

    def error(self, msg: str) -> None:
        self.stop_working()
        self.console.print(
            f"[bold red]error:[/bold red] {_markup_literal(msg)}")

    def add_permission_rule(self, name: str, args: dict) -> str | None:
        """Persist an allow-rule for this tool call — the 'always allow' path."""
        if self._rule_hook:
            rule = str(rule_for(name, args))
            self._rule_hook(rule)
            return rule


# ------------------------------------------------------------------- REPL ---

def _help_table(console, rows) -> None:
    """Render literal command syntax in a responsive two-column grid."""
    from rich.text import Text
    values = [(terminal_safe_text(token).replace("\n", " "),
               terminal_safe_text(description).replace("\n", " "))
              for token, description in rows]
    if not values:
        return
    terminal_width = max(32, int(console.size.width or 80))
    token_width = min(max(len(token) + 2 for token, _description in values),
                      max(14, terminal_width // 2), 40)
    table = Table.grid(expand=True, padding=(0, 2))
    table.add_column(width=token_width, no_wrap=True, overflow="ellipsis")
    table.add_column(ratio=1)
    for token, description in values:
        command = Text("  ")
        command.append(token, style=BRAND)
        table.add_row(command, _literal_cell(description, style=DIM))
    console.print(table)


def render_help(console, project_root: Path | None = None) -> None:
    """Render classic help from the same command registry used by every command palette."""
    from rich.text import Text
    console.print("[bold]chat[/bold]", highlight=False)
    _help_table(console, (
        ("just type", "ask dgc anything; it uses tools to act on your project"),
        ("#fact", "quick-add a memory to DGC.md"),
        ("!cmd", "run a shell command directly"),
        ("@path/to/file", "attach one exact bounded text or image file"),
    ))

    console.print()
    console.print("[bold]slash commands[/bold]", highlight=False)
    _help_table(console, (("/" + (spec.usage or spec.name), spec.description)
                          for spec in command_specs("classic")))

    if project_root is not None:
        custom = custom_command_names(project_root)
        if custom:
            console.print()
            console.print("[bold]custom prompt commands[/bold]", highlight=False)
            _help_table(console, (("/" + name + " [ARGS]",
                                   "project or personal prompt template") for name in custom))

    quit_spec = next(spec for spec in command_specs("classic") if spec.name == "quit")
    aliases = " and ".join("/" + name for name in quit_spec.aliases)
    console.print(Text(f"  {aliases} are aliases for /quit", style=DIM))
    console.print(Text(
        "  while a turn runs: type a follow-up + Enter to queue it · Esc to interrupt",
        style=DIM))


class ClassicSlashCompleter(Completer):
    """Live classic-REPL completion derived from the shared command registry."""

    def __init__(self, project_root: Path, config=None):
        self.project_root = project_root
        self.config = config

    def get_completions(self, document, complete_event):
        del complete_event
        from .composer import composer_token, completion_rows
        token = composer_token(document.text, document.cursor_position)
        if token is None or token[0] not in ("/", "$"):
            return
        trigger, query, start, _end = token
        from .skills import discover_skills
        skills = discover_skills(self.project_root, disabled_names=self.config.get("disabled_skills", []) if self.config else [])
        for row in completion_rows("classic", self.project_root, skills=skills, trigger=trigger, query=query):
            yield Completion(row["label"], start_position=start - document.cursor_position,
                             display=row["label"], display_meta=row["desc"])


class CLI:
    def __init__(self, config: Config, ui=None):
        self.config = config
        from . import termbg
        termbg.configure(config)
        self.ui = ui if ui is not None else UI()
        self.ui._rule_hook = self._add_rule
        self.agent = Agent(config, self.ui)
        self.console = self.ui.console

    def _context_window_size(self) -> int:
        effective = getattr(self.agent, "context_size", None)
        if callable(effective):
            return int(effective())
        return int(self.config.get("context_size", 32768))

    # ------------------------------------------------------------- banner ---
    # DGC wordmark — assembled from fixed-width block letters so it always aligns.
    _LOGO_D = ["██████╗ ", "██╔══██╗", "██║  ██║", "██║  ██║", "██████╔╝", "╚═════╝ "]
    _LOGO_G = [" ██████╗ ", "██╔════╝ ", "██║  ███╗", "██║   ██║", "╚██████╔╝", " ╚═════╝ "]
    _LOGO_C = [" ██████╗", "██╔════╝", "██║     ", "██║     ", "╚██████╗", " ╚═════╝"]
    _LOGO_COLORS = ["#22D3EE", "#3EC7EE", "#6FA6EE", "#9B84E8", "#C25FD8", "#E84CC6"]  # cyan → magenta

    def _logo(self) -> None:
        c = self.console
        c.print()
        if (c.size.width or 80) < 34:                        # minimal: no art, one dim brand line
            cfg = self.config
            c.print(f"  [bold {BRAND_MAGENTA}]dgc[/] [{DIM}]v{__version__} · "
                    f"{_markup_literal(cfg.model)} · "
                    f"{_markup_literal(cfg.data.get('mode', 'default'))}[/]", highlight=False)
            return
        logo_mod.show(c, animate=bool(self.config.get("logo_animation", True)))   # animated shimmer wordmark
        c.print(f"  [{DIM}]v{__version__} · a coding agent for the models you run[/]", highlight=False)
        c.print(f"  [{DIM}]Built by Mohit Kalra[/]\n", highlight=False)

    def banner(self) -> None:
        c = self.console
        cfg = self.config
        mode = cfg.data.get("mode", "default")
        engine = str(cfg.get("subscription_engine", "") or "").strip().lower()
        think = (str(cfg.get("subscription_effort", "") or "").strip()
                 or "off") if engine else cfg.data.get("thinking", "off")
        active_model = (str(cfg.get("subscription_model", "") or "").strip()
                        or f"{engine} default") if engine else cfg.model
        self._logo()
        if (c.size.width or 80) < 34:                        # minimal: skip the config block
            return
        def row(label, value):                               # dim padded label + value (peachd statusLine)
            safe_label = _markup_literal(label)
            c.print(f"  [{DIM}]{safe_label:<8}[/]  {_markup_literal(value)}", highlight=False)
        row("endpoint", f"{engine} CLI subscription" if engine else cfg.base_url)
        row("model", active_model)
        c.print(f"  [{DIM}]{'mode':<8}[/]  "
                f"[{MODE_COLOR.get(mode, 'white')}]{_markup_literal(mode)}[/]  "
                f"[{DIM}]· {_markup_literal(MODE_DESCRIPTIONS.get(mode, ''))}[/]",
                highlight=False)
        row("thinking", think)
        if cfg.get("ultra_mode", False):
            from .ultra import worker_limit
            row("profile", f"Ultra · up to {worker_limit(cfg)} parallel agents · permissions unchanged")
        row("project", cfg.project_root)
        if self.agent.skills:
            row("skills", ", ".join(self.agent.skills))
        proj_mem, user_mem = memory_mod.load_memories(cfg.project_root)
        loaded = [n for n, m in (("DGC.md", proj_mem), ("user DGC.md", user_mem)) if m]
        if loaded:
            row("memory", "loaded: " + ", ".join(loaded))
        row("search", cfg.get("search_provider", "duckduckgo"))
        c.print(f"  [{DIM}]{'context':<8}[/]  ", render.context_bar(self.agent.estimate_tokens(),
                self._context_window_size()), highlight=False)
        upd = cached_update()
        if upd:
            c.print(f"  [bold {BRAND_MAGENTA}]⬆ update available: "
                    f"v{_markup_literal(upd)}[/]  "
                    f"[{DIM}]— run [bold]dgc update[/bold][/]", highlight=False)
        if mode == "auto":
            auto_warning(c)
        c.print(f"  [{DIM}]type [bold]/help[/bold] for commands, [bold]/exit[/bold] to quit[/]\n")

    # ------------------------------------------------------- rule handling ---
    def _add_rule(self, rule_text: str) -> None:
        try:
            Rule.parse(rule_text, "allow")
        except ValueError as e:
            self.ui.error(str(e))
            return
        self.config.permissions["allow"].append(rule_text)
        self.config.save()
        self.ui.info(f"rule saved: allow {rule_text}")

    # ------------------------------------------------------ slash commands ---
    def handle_slash(self, line: str) -> bool:
        parts = line[1:].split(None, 1)
        cmd = canonical_command_name(parts[0] if parts else "", "classic")
        rest = parts[1] if len(parts) > 1 else ""
        cfg = self.config

        if cmd in ("exit", "quit", "q"):
            raise EOFError
        if cmd == "help":
            render_help(self.console, cfg.project_root)
        elif cmd == "connect":
            args = rest.split()
            if len(args) > 1:
                self.ui.error("API keys are not accepted inline — use the masked prompt, dgc setup, or DGC_API_KEY")
                return True
            if not args:
                from .menu import select
                pk = list(PROVIDERS)
                idx = select("Connect a provider", [PROVIDERS[k]["label"] for k in pk],
                             [PROVIDERS[k]["base_url"] for k in pk])
                if idx is not None:
                    prov = PROVIDERS[pk[idx]]
                    cfg.set("subscription_engine", "")
                    cfg.set("subscription_model", "")
                    cfg.set("subscription_effort", "")
                    cfg.set("base_url", prov["base_url"])
                    cfg.set("api_mode", "auto")
                    if prov["needs_key"]:
                        from getpass import getpass
                        key = getpass(f"  API key for {prov['label']} › ").strip()
                        cfg.set("api_key", key or prov["api_key"])
                    else:
                        cfg.set("api_key", prov["api_key"])
                    self.agent.refresh_client()
                    self.ui.info(f"endpoint set to {cfg.base_url}  ·  model {cfg.model}")
            else:
                target = args[0]
                from . import subscriptions as subs
                engine = subs.get_engine(target)
                if engine is not None:
                    self._connect_engine(engine)
                    return True
                cfg.set("subscription_engine", "")
                cfg.set("subscription_model", "")
                cfg.set("subscription_effort", "")
                if target in PROVIDERS:
                    prov = PROVIDERS[target]
                    cfg.set("base_url", prov["base_url"])
                    cfg.set("api_mode", "auto")
                    if prov["needs_key"]:
                        from getpass import getpass
                        key = getpass(f"  API key for {prov['label']} › ").strip()
                        cfg.set("api_key", key or prov["api_key"])
                    else:
                        cfg.set("api_key", prov["api_key"])
                else:
                    normalized, changed = normalize_custom_base_url(target)
                    cfg.set("base_url", normalized)
                    if changed:
                        self.ui.info(f"normalized endpoint to {normalized} (OpenAI-compatible path)")
                self.agent.refresh_client()
                self.ui.info(f"endpoint set to {cfg.base_url}  ·  model {cfg.model}")
        elif cmd == "models":
            try:
                models = self.agent.client.list_models()
            except (LLMError, Exception) as e:
                self.ui.error(str(e))
                return True
            if not models:
                self.ui.info("no models offered by the endpoint")
            else:
                from .menu import select
                mi = select("Model", models)
                if mi is not None:
                    self._set_model(models[mi])
        elif cmd == "model":
            _se = str(cfg.get("subscription_engine", "") or "").strip().lower()
            if _se:                                    # steer the subscription's model, not the endpoint
                if rest:
                    cfg.set("subscription_model", rest.strip())
                    self.ui.info(f"subscription model → {rest.strip()}")
                else:
                    self.ui.info(f"subscription model: {cfg.get('subscription_model', '') or f'{_se} default'}"
                                 f"  ·  /model <name> steers {_se}")
            elif rest:
                self._set_model(rest.strip())
            else:
                self.ui.info(f"model: {cfg.model}")
        elif cmd in ("mode",):
            if not rest:
                i = MODE_CYCLE.index(self.agent.mode) if self.agent.mode in MODE_CYCLE else 0
                rest = MODE_CYCLE[(i + 1) % len(MODE_CYCLE)]
            if rest not in MODES:
                self.ui.error(f"unknown mode {rest!r} — choose from {', '.join(MODES)}")
                return True
            # Mode is durable and shared with the full-screen route, and a connected subscription
            # runs the classic REPL's turns too, so its mode invariant holds here as well.
            from . import subscriptions as subs
            active_engine = str(cfg.get("subscription_engine", "") or "").strip().lower()
            try:
                subs.validate_engine_mode(active_engine, rest)
            except subs.EngineModeUnsupported as exc:
                self.ui.error(str(exc))
                return True
            if rest == "auto" and self.agent.mode != "auto":
                auto_warning(self.console)
                if input("  enable full-auto? [y/N] › ").strip().lower() in ("y", "yes"):
                    self.agent.set_mode("auto")
                    self.ui.info(f"mode → auto ({MODE_DESCRIPTIONS['auto']})")
                else:
                    self.ui.info(f"kept {self.agent.mode}")
            else:
                self.agent.set_mode(rest)
                self.ui.info(f"mode → {rest} ({MODE_DESCRIPTIONS[rest]})")
        elif cmd in ("plan", "review", "init"):
            from .workflows import activate_workflow, expand_workflow_prompt, prepare_workflow
            try:
                workflow = prepare_workflow(cmd, rest, self.agent)
                text = expand_workflow_prompt(workflow.prompt, self.expand_mentions) if workflow.prompt else ""
                activate_workflow(workflow, self.agent)
            except ValueError as exc:
                self.ui.error(str(exc))
                return True
            self.ui.info(f"mode → {self.agent.mode} ({MODE_DESCRIPTIONS[self.agent.mode]})")
            if text:
                self._run_turn_live(text, getattr(self, "_followup_queue", []))
        elif cmd in ("view-plan", "plan-view", "viewplan"):
            plan = (sessions_mod.load_plan(self.agent.session_file, cfg.project_root)
                    if self.agent.session_file else None)
            if plan:
                self.console.print(render.render_markdown(terminal_safe_text(plan)))
            else:
                self.ui.info("no saved plan yet — /mode plan, then ask for one")
        elif cmd == "goal":
            action = rest.strip()
            low = action.lower()
            if low in ("clear", "off", "none", "remove", "delete"):
                if self.agent.set_goal(""):
                    self.ui.info("standing goal cleared")
                else:
                    self.ui.error(self.agent._last_persist_error or "goal update was not saved")
            elif low in ("complete", "completed", "done"):
                if not self.agent.update_goal("completed"):
                    if self.agent._last_persist_error:
                        self.ui.error(self.agent._last_persist_error)
                    else:
                        self.ui.info("no standing goal to complete")
            elif low in ("blocked", "block", "pause", "paused"):
                if not self.agent.update_goal("blocked" if low in ("blocked", "block") else "paused"):
                    if self.agent._last_persist_error:
                        self.ui.error(self.agent._last_persist_error)
                    else:
                        self.ui.info("no standing goal to pause")
            elif low in ("resume", "active", "reactivate"):
                if not self.agent.update_goal("active"):
                    if self.agent._last_persist_error:
                        self.ui.error(self.agent._last_persist_error)
                    else:
                        self.ui.info("no standing goal to resume")
                else:
                    self.agent._pending_images = None
                    from .goals import resume_prompt
                    self._run_turn_live(
                        resume_prompt(checklist_cleared=self.agent.todo_clear_in_force()),
                        getattr(self, "_followup_queue", []))
            elif low in ("", "review", "status"):
                if self.agent.goal:
                    from .goals import review_markdown
                    self.console.print(render.render_markdown(terminal_safe_text(review_markdown(self.agent.goal_snapshot()))))
                else:
                    self.ui.info("no standing goal — /goal <objective> to start one")
            elif action:
                from .goal_inputs import start_terminal_goal
                try:
                    notices = start_terminal_goal(action, self.agent)
                except ValueError as exc:
                    self.ui.error(str(exc)); return True
                for notice in notices:
                    self.ui.info(notice)
                self.ui.info(f"standing goal → active: {self.agent.goal[:120]}")
                self._run_turn_live(self.agent.goal, getattr(self, "_followup_queue", []))
        elif cmd == "think":
            _se = str(cfg.get("subscription_engine", "") or "").strip().lower()
            if _se:                                    # /think steers the subscription's reasoning effort
                from . import subscriptions as subs
                eng = subs.get_engine(_se)
                if eng is not None and not eng.supports_effort():
                    self.ui.error(f"{eng.short_label} takes no reasoning-effort flag — steer it via /model")
                elif rest in ("off", "low", "medium", "high", "xhigh", "max"):
                    val = "" if rest == "off" else rest
                    cfg.set("subscription_effort", val)
                    self.ui.info(f"subscription effort → {val or 'default'}")
                else:
                    self.ui.info(f"subscription effort: {cfg.get('subscription_effort', '') or 'default'}"
                                 "  ·  /think off|low|medium|high|xhigh|max")
                return True
            if not rest:
                i = THINK_LEVELS.index(cfg.get("thinking", "off"))
                rest = THINK_LEVELS[(i + 1) % len(THINK_LEVELS)]
            if rest not in THINK_LEVELS:
                self.ui.error(f"unknown level {rest!r} — choose from {', '.join(THINK_LEVELS)}")
            else:
                cfg.set("thinking", rest)   # persisted across restarts
                self.ui.info(f"thinking → {rest}")
                from .llm import is_reasoning_model
                if rest == "off" and is_reasoning_model(cfg.get("model", "")):
                    self.ui.info("  tip: this looks like a reasoning model — /think high often does "
                                 "better on hard tasks")
        elif cmd == "ultra":
            val = rest.strip().lower()
            if val in ("on", "true", "1", "yes", "enable", "enabled"):
                cfg.set("ultra_mode", True)
                self.agent._refresh_system()
                from .ultra import summary
                self.ui.info(f"{summary(cfg)} → on (permission mode remains {self.agent.mode})")
            elif val in ("off", "false", "0", "no", "disable", "disabled"):
                cfg.set("ultra_mode", False)
                self.agent._refresh_system()
                self.ui.info("DGC Ultra → off")
            elif val in ("", "status"):
                state = "on" if cfg.get("ultra_mode", False) else "off"
                from .ultra import summary
                self.ui.info(f"{summary(cfg)} → {state}; /ultra on|off")
            else:
                self.ui.error("usage: /ultra [on|off]")
        elif cmd == "preserve-thinking":
            val = rest.strip().lower()
            if val in ("on", "true", "1", "show", "yes"):
                cfg.set("preserve_thinking", True)   # persisted across restarts
                self.ui.info("preserve thinking → on (prior-turn reasoning kept in context)")
            elif val in ("off", "false", "0", "hide", "no"):
                cfg.set("preserve_thinking", False)
                self.ui.info("preserve thinking → off")
            else:
                cur = "on" if cfg.get("preserve_thinking", False) else "off"
                self.ui.info(f"preserve thinking: {cur} — /preserve-thinking on|off")
        elif cmd in ("code-action", "codeaction", "python-tool"):
            val = rest.strip().lower()
            if val in ("on", "true", "1", "yes"):
                cfg.set("code_action", True)   # persisted across restarts
                self.ui.info("code-action → on (persistent `python` tool advertised)")
            elif val in ("off", "false", "0", "no"):
                cfg.set("code_action", False)
                self.ui.info("code-action → off")
            else:
                cur = "on" if cfg.get("code_action", False) else "off"
                self.ui.info(f"code-action: {cur} — /code-action on|off")
        elif cmd in ("autonomous-gate", "auto-gate"):
            val = rest.strip()
            if val.lower() in ("off", "none", "clear", "unset", ""):
                if not val:
                    gate = cfg.get("autonomous_gate", "") or ""
                    if gate:
                        self.ui.info(f"autonomous gate: `{gate}` — max {cfg.get('autonomous_max_turns', 30)} "
                                     "retries. /autonomous-gate off to clear")
                    else:
                        self.ui.info("autonomous gate: off — /autonomous-gate \"<cmd>\" to set one")
                else:
                    cfg.set("autonomous_gate", "")
                    self.agent.autonomous_gate = ""
                    self.ui.info("autonomous gate → off")
            else:
                cfg.set("autonomous_gate", val)
                self.agent.autonomous_gate = val
                self.ui.info(f"autonomous gate → `{val}` (must exit 0 before a turn may stop; "
                             f"max {cfg.get('autonomous_max_turns', 30)} retries)")
        elif cmd in ("export-training", "export-jsonl"):
            summary = export_training_core(cfg, out=(rest.strip() or "./dgc-training.jsonl"))
            if summary.get("error"):
                self.ui.error(summary["error"])
            else:
                self.ui.info(
                    f"export-training → wrote {summary['written']} session(s), "
                    f"skipped {summary['skipped']}, to {summary['out']} (secrets scrubbed)")
        elif cmd == "notes":
            from .notes import handle_command
            self.console.print(render.render_markdown(handle_command(self.agent, rest)))
        elif cmd == "trust":
            from .trust import handle_trust_command
            self.console.print(render.render_markdown(handle_trust_command(cfg, cfg.project_root, rest)))
        elif cmd == "permissions":
            self._permissions_cmd(rest)
        elif cmd == "memory":
            self._memory_cmd(rest)
        elif cmd == "skills":
            from .skills import manage_skills
            try:
                output = manage_skills(cfg, rest)
                self.agent.reload_skills()
                self.console.print(terminal_safe_text(redact_text(output, secret_values(cfg))), markup=False, highlight=False)
            except (OSError, ValueError) as exc:
                self.ui.error(str(exc))
        elif cmd == "mcp":
            from .mcp_management import manage_mcp
            from .mcp_context import stage_context
            try:
                self.agent.cancelled.clear()
                result = manage_mcp(cfg, self.agent.mcp, rest, agent=self.agent)
                if isinstance(result, dict):
                    stage_context(self.agent, result)
                    result = f"Attached {result['server']} · {result['identifier']} to the next prompt. /mcp context lists snapshots; /mcp clear-context removes them."
                self.console.print(terminal_safe_text(redact_text(result, secret_values(cfg))), markup=False, highlight=False)
            except (OSError, ValueError) as exc:
                self.ui.error(redact_text(str(exc), secret_values(cfg)))
        elif cmd == "hooks":
            from .hooks import hook_catalog
            catalog = hook_catalog(cfg)
            table = Table("event", "configured", "matchers", "state")
            for item in catalog["items"]:
                table.add_row(item["event"], str(item["configured"]),
                              _literal_cell(", ".join(item["matchers"]) or "—"),
                              "ready" if item["valid"] else "invalid")
            self.console.print(table)
            if catalog["invalid"]:
                self.ui.error(f"hook configuration has {catalog['invalid']} invalid or unsupported entry(s)")
        elif cmd == "skill":
            args = rest.split(None, 1)
            self.agent.reload_skills()
            sk = self.agent.skills.get(args[0]) if args else None
            if not sk:
                self.ui.error(f"unknown skill — try /skills")
            elif not sk.enabled:
                self.ui.error(f"Skill ${sk.name} is disabled. Use /skills enable {sk.name} first.")
            else:
                self.agent.run_turn(f"${sk.name}\n\n" + (args[1] if len(args) > 1 else "Apply this skill to the current task."))
        elif cmd == "status":
            self.banner()
        elif cmd == "usage":
            from . import usage_ledger
            try:
                report = usage_ledger.report(usage_ledger.normalize_range(rest))
            except ValueError as exc:
                self.ui.error(str(exc))
            else:
                self.console.print(render.render_markdown(usage_ledger.format_report(report)))
        elif cmd == "eta":
            from .eta import format_stats
            snapshot_fn = getattr(self.agent, "eta_snapshot", None)
            snapshot = snapshot_fn() if callable(snapshot_fn) else None
            if rest.strip().lower() in ("stats", "stat", "calibration") or snapshot is None:
                self.console.print(render.render_markdown(format_stats(self.agent.eta_stats_summary())))
                if snapshot is None and not rest.strip():
                    self.ui.info("no turn is running; the range appears in the status line 20 s into a turn")
            else:
                self.ui.info(f"{snapshot.label} · basis {snapshot.basis} · confidence {snapshot.confidence:.0%}"
                             if snapshot.visible else f"estimating… {snapshot.elapsed:.0f}s in")
        elif cmd == "context":
            used, size = self.agent.estimate_tokens(), self._context_window_size()
            self.console.print("  [bold]context[/bold]  ", render.context_bar(used, size), highlight=False)
        elif cmd in ("bg", "background"):
            from . import termbg
            if termbg.switch(cfg, rest.strip().lower()):
                self.ui.refresh_theme()      # the canvas moved; the console must move with it
                self.ui.info(f"background → {cfg.get('background')}"
                             + (" (applies on next launch)" if cfg.get("background") == "auto" else ""))
            else:
                self.ui.info(f"background: {cfg.get('background', 'inherit')} · /bg auto|dark|light|inherit")
        elif cmd == "theme":
            from . import termbg
            if not rest:
                self.ui.info(f"theme: {style_mod.theme().name}  ·  available: auto, dark, light")
            else:
                canvas_before = cfg.get("background")
                if termbg.switch_theme(cfg, rest.strip().lower()):
                    self.ui.refresh_theme()
                    self.banner()
                    canvas_after = cfg.get("background")
                    if canvas_after != canvas_before:   # readability forced the canvas to follow
                        self.ui.info(f"background → {canvas_after} — {rest.strip().lower()} text "
                                     f"would not have been readable on the {canvas_before} canvas")
                else:
                    # The handler takes auto as well; listing only style_mod.THEMES told the user
                    # that the value the info line offers them is not a value.
                    self.ui.error(f"unknown theme {rest!r} — choose from auto, dark, light")
        elif cmd == "compact":
            if not self.agent.maybe_compact(force=True, trigger="manual"):
                self.ui.error(self.agent._last_persist_error or "context compaction failed")
        elif cmd in ("branch", "fork"):
            if self.agent.fork_session(rest):
                self.ui.info(f"branched into {self.agent.session_name or 'a new chat'}"
                             " — this chat keeps everything up to here")
            else:
                self.ui.error(getattr(self.agent, "_last_persist_error", "")
                              or "the branch could not be saved")
        elif cmd in ("clear", "new"):
            self.agent.reset()
            self.agent.session_file = sessions_mod.new_path(cfg.project_root)
            self.ui.info("new session started" if cmd == "new" else "conversation cleared")
        elif cmd == "todo":
            # The checklist outlives the turn that wrote it. `/todo clear` is the exit for a list
            # the model left behind or a resumed session brought back, short of a new chat.
            if rest.strip().lower() == "clear":
                # Through the agent's own callback (its UI is this one), so the ETA estimator
                # and the terminal see the same empty list.
                if self.agent.clear_todos():
                    self.ui.info("todo list cleared")
                else:
                    self.ui.error(self.agent._last_persist_error
                                  or "todo list cleared, but the session could not be saved")
            else:
                self.ui.error("usage: /todo clear")
        elif cmd == "rewind":
            pts = self.agent.checkpoints.listing()
            if not pts:
                self.ui.info("no checkpoints yet — run a turn first")
            else:
                labels = [f"{prev}  [{nf} file{'' if nf == 1 else 's'}]" for (_i, prev, nf) in pts]
                mi = select("Rewind to (restores code + conversation)", labels)
                if mi is not None:
                    msgs, nfiles = self.agent.rewind(pts[mi][0])
                    if msgs >= 0:
                        self.ui.info(f"↩ rewound — restored {nfiles} file(s); conversation truncated")
                    else:
                        self.ui.error("rewind could not complete; the recovery point was retained")
        elif cmd == "search":
            self._search_cmd(rest)
        elif cmd == "resume":
            self._resume_cmd()
        elif cmd in ("artifact", "artifacts"):
            from . import artifacts
            args = rest.split()
            if len(args) == 2 and args[0] in ("stop", "remove", "rm"):
                self.ui.info("artifact stopped" if artifacts.stop(args[1]) else f"no artifact {args[1]!r}")
            else:
                arts = artifacts.registry()
                if not arts:
                    self.ui.info("no project artifacts are running")
                else:
                    table = Table("id", "name", "URL", "age")
                    for art in arts:
                        table.add_row(*(_literal_cell(value) for value in
                                        (art.id, art.name, art.url, art.uptime)))
                    self.console.print(table)
        elif cmd in ("handoff", "handover"):
            md = self.agent.generate_handoff(save=True)
            path = self.agent._last_handoff_path
            if path:
                self.ui.info(f"handoff saved → {path}")
            elif self.agent._last_handoff_error:
                self.ui.error(self.agent._last_handoff_error)
            self.console.print(render.render_markdown(terminal_safe_text(md)))
        elif cmd == "name":
            if rest.strip():
                if self.agent.name_session(rest.strip()):
                    self.ui.info(f"session named: {rest.strip()}")
                else:
                    self.ui.error(self.agent._last_persist_error or "session rename failed")
            else:
                self.ui.info(f"current session: {self.agent.session_name or '(unnamed)'} — /name <name>")
        elif cmd == "worktree":
            self._worktree_cmd(rest)
        elif cmd == "tasks":
            self._tasks_cmd(rest)
        elif cmd == "update":
            run_update()
        elif cmd == "agents":
            from .subagents import meta_text, summary_parts, tree_items
            registry = getattr(self.agent, "subagents", None)
            counts = registry.counts() if registry is not None else {}
            if counts.get("total"):              # this chat's task sub-agents, as the TUI lists them
                from .render import fmt_tokens
                snap = registry.snapshot()
                marks = {"queued": glyphs.AGENT_QUEUED, "running": glyphs.AGENT_RUN,
                         "waiting": glyphs.AGENT_WAIT, "finished": glyphs.CHECK,
                         "failed": glyphs.CROSS, "stopped": glyphs.BLOCKED}
                self.console.print(Text("agents in this chat · " + " · ".join(summary_parts(counts))))
                for level, item in tree_items(snap["items"]):
                    desc = " ".join(style_mod.terminal_safe_text(
                        item.get("description") or "(no description)").split())
                    meta = " ".join(style_mod.terminal_safe_text(meta_text(
                        item, main_model=str(cfg.model or ""), fmt_tokens=fmt_tokens,
                        finished_word=False)).split())
                    mark = marks.get(item.get("state"), glyphs.AGENT_IDLE)
                    self.console.print(Text(f"  {'  ' * level}{mark} {desc}" + (f"  {meta}" if meta else "")))
                hidden = int(counts.get("total", 0)) - len(snap["items"])
                if hidden > 0:
                    self.console.print(Text(f"  {glyphs.ELLIPSIS_V} {hidden} more not listed"))
            defs = self.agent.agent_defs
            sm = cfg.get("subagent_model") or f"(inherit main: {cfg.model})"
            sh = cfg.get("subagent_base_url") or f"(inherit main: {cfg.base_url})"
            st = cfg.get("subagent_api_mode") or "(inherit/infer)"
            self.console.print(
                f"[bold]Sub-agent defaults[/bold]  model [{BRAND}]{_markup_literal(sm)}[/]  ·  "
                f"host [{BRAND}]{_markup_literal(sh)}[/]  ·  "
                f"transport [{BRAND}]{_markup_literal(st)}[/]")
            self.console.print("[dim]/subagent model NAME  ·  /subagent host URL  ·  "
                               "/subagent transport MODE  ·  /subagent clear[/dim]")
            if defs:
                table = Table("agent", "description", "model", "host", "transport")
                for a in defs.values():
                    table.add_row(*(_literal_cell(value) for value in (
                        a.name, a.description + (" (built-in)" if a.builtin else ""),
                        a.model or "(default)",
                        a.base_url or "(default)", a.api_mode or "(inherit/infer)")))
                self.console.print(table)
            custom = [a for a in defs.values() if not a.builtin]
            if not custom:
                self.ui.info("add .dgc/agents/<name>.md to override a built-in or add your own "
                             "(frontmatter: model, base_url, api_mode, api_key_env, effort, tools)")
        elif cmd == "subagent":
            args = rest.split()
            if not args:
                self.ui.info(f"sub-agent model: {cfg.get('subagent_model') or '(inherit main)'}  ·  "
                             f"host: {cfg.get('subagent_base_url') or '(inherit main)'}  ·  "
                             f"transport: {cfg.get('subagent_api_mode') or '(inherit/infer)'}")
            elif args[0] == "model" and len(args) > 1:
                cfg.set("subagent_model", args[1])
                self.ui.info(f"sub-agent model → {args[1]}")
            elif args[0] == "host" and len(args) > 1:
                if len(args) > 2:
                    self.ui.error("API keys are not accepted inline — use DGC_SUBAGENT_API_KEY")
                    return True
                cfg.set("subagent_base_url", args[1])
                self.ui.info(f"sub-agent host → {args[1]}")
            elif args[0] == "transport" and len(args) == 2:
                mode = args[1].lower()
                if mode not in ("auto", "ollama", "anthropic", "chat_completions", "responses"):
                    self.ui.error(
                        "transport must be auto, ollama, anthropic, chat_completions, or responses")
                    return True
                cfg.set("subagent_api_mode", mode)
                self.ui.info(f"sub-agent transport → {mode}")
            elif args[0] == "clear":
                for k in ("subagent_model", "subagent_base_url", "subagent_api_key",
                          "subagent_api_mode"):
                    cfg.set(k, "")
                self.ui.info("sub-agent overrides cleared — inherits the main model/host")
            else:
                self.ui.error("usage: /subagent [model NAME | host URL | transport MODE | clear]")
        else:
            from .commands import discover_commands, render_command
            custom = discover_commands(self.config.project_root)
            if cmd in custom:
                rendered = render_command(custom[cmd], rest, self.config.project_root)
                if rendered:
                    self.agent.run_turn(rendered)
            else:
                self.console.print(
                    f"[dim]unknown command /{_markup_literal(cmd)} — try /help[/dim]")
        return True

    def _search_cmd(self, rest: str) -> None:
        cfg = self.config
        args = rest.split()
        if not args:
            self.ui.info(f"web search: {cfg.get('search_provider', 'duckduckgo')}  ·  "
                         f"options: {', '.join(SEARCH_PROVIDERS)}")
            return
        p = args[0].lower()
        if p not in SEARCH_PROVIDERS:
            self.ui.error("providers: " + ", ".join(SEARCH_PROVIDERS))
            return
        meta = SEARCH_PROVIDERS[p]
        cfg.set("search_provider", p)
        if meta["needs_key"]:
            if len(args) > 1:
                self.ui.error("API keys are not accepted inline — use the masked prompt, dgc setup, or DGC_SEARCH_API_KEY")
                return
            from getpass import getpass
            key = getpass(f"  API key for {meta['label']} › ").strip()
            cfg.set("search_api_key", key)
        if meta["needs_url"]:
            url = args[1] if len(args) > 1 else input(f"  base URL for {meta['label']} › ").strip()
            cfg.set("search_url", url)
        self.ui.info(f"web search → {meta['label']}")

    def _show_restored_todos(self) -> None:
        """Replay a resumed session's checklist, redacted like the transcript it came with."""
        todos = self.agent.todos
        if todos:
            self.ui.on_todo(redact_value(list(todos), secret_values(self.config)))

    def _resume_cmd(self) -> None:
        items = sessions_mod.listing(
            self.config.project_root, redact_secrets=secret_values(self.config))
        if not items:
            self.ui.info("no saved sessions in this directory")
            return
        from .menu import select
        labels = [f"{sessions_mod.when(ts)}  ({cnt} msgs)  {(nm + ' · ' if nm else '')}{prev}"
                  for (p, ts, prev, cnt, nm) in items[:20]]
        si = select("Resume a session", labels)
        if si is None:
            return
        n = self.agent.load_session(items[si][0])
        self.ui.info(f"resumed session ({n} messages)"
                     + (f" — {self.agent.session_name}" if self.agent.session_name else ""))
        self._show_restored_todos()

    def _set_model(self, model: str) -> None:
        self.config.set("model", model)
        self.agent.refresh_client()
        ctx = self.agent.recommended_context_size(model)
        if ctx and ctx != int(self.config.get("context_size", 32768)):
            self.config.set("context_size", ctx)
            self.ui.info(f"model → {model}  ·  context auto-set to {ctx // 1024}k (/context to change)")
        else:
            self.ui.info(f"model → {model}")

    def _worktree_cmd(self, rest: str) -> None:
        from . import worktree as wt
        root = self.config.project_root
        parts = rest.split()
        if not parts or parts[0] == "list":
            wts = wt.list_worktrees(root)
            if not wts:
                self.ui.info("not a git repo, or no worktrees — /worktree <name> to create one")
                return
            style_mod.section(self.console, "git worktrees")
            for w in wts:
                self.console.print(
                    f"  [{BRAND}]{_markup_literal(w.get('branch', '(detached)'))}[/]  "
                    f"[{DIM}]{_markup_literal(w['path'])}[/]", highlight=False)
            return
        if parts[0] == "remove" and len(parts) > 1:
            err = wt.remove(root, " ".join(parts[1:]))
            (self.ui.error if err else self.ui.info)(err or f"removed worktree '{parts[1]}'")
            return
        wt_path, branch, err = wt.create(root, rest.strip())
        if err:
            self.ui.error(err)
            return
        self.ui.info(f"created worktree on branch {branch}")
        self._reroot(wt_path, f"worktree {branch}")

    def _tasks_cmd(self, rest: str) -> None:
        try:
            parts = shlex.split(rest)
        except ValueError as exc:
            self.ui.error(f"invalid /tasks arguments: {exc}")
            return
        action = parts[0].lower() if parts else "list"
        tasks, errors = self.agent.retained_tasks()
        if action in ("list", "show"):
            selected = tasks
            if action == "show":
                if len(parts) != 2:
                    self.ui.error("usage: /tasks show ID")
                    return
                selected = [task for task in tasks if task.id == parts[1]]
                if not selected:
                    self.ui.error(f"no retained task matching {parts[1]!r}")
                    return
            if not selected:
                self.ui.info("no retained sub-agent work for this project")
            else:
                table = Table("id", "state", "paths", "reason", "worktree")
                for task in selected[:100]:
                    state = ("legacy/manual" if task.legacy else
                             ("ready" if task.available else "stale"))
                    paths = ", ".join(task.display_paths[:5]) or "(none)"
                    if len(task.display_paths) > 5:
                        paths += f" (+{len(task.display_paths) - 5})"
                    table.add_row(*(_literal_cell(value) for value in (
                        task.id, state, paths, task.reason or "(unspecified)", task.path)))
                self.console.print(table)
                if len(selected) > 100:
                    self.ui.info(f"showing 100 of {len(selected)} records — /tasks show ID for one record")
            for error in errors:
                self.ui.error(error)
            if selected:
                self.ui.info("/tasks apply ID  ·  /tasks drop ID --confirm")
            return
        if action not in ("apply", "drop") or len(parts) < 2:
            self.ui.error("usage: /tasks [list | show ID | apply ID | drop ID --confirm]")
            return
        task_id = parts[1]
        if action == "drop" and "--confirm" not in parts[2:]:
            self.ui.info(f"drop permanently deletes the retained checkout; repeat: "
                         f"/tasks drop {shlex.quote(task_id)} --confirm")
            return
        result = self.agent.resolve_retained_task(task_id, action)
        if result.status == "applied":
            warning = f" Cleanup warning: {result.cleanup_error}." if result.cleanup_error else ""
            self.ui.info(f"applied retained task {task_id}: {len(result.paths)} path(s).{warning} "
                         "Use /rewind to undo.")
        elif result.status == "clean":
            warning = f" Cleanup warning: {result.cleanup_error}." if result.cleanup_error else ""
            self.ui.info(f"retained task {task_id} had no remaining changes.{warning}")
        elif result.status == "dropped":
            self.ui.info(f"dropped retained task {task_id}")
        else:
            conflicts = f" Conflicts: {', '.join(result.conflicts[:12])}." if result.conflicts else ""
            self.ui.error(f"could not {action} retained task {task_id}: "
                          f"{result.error or result.status}.{conflicts}")

    def _reroot(self, new_root, label: str) -> None:
        import os as _os
        try:
            _os.chdir(new_root)
        except OSError:
            pass
        self.config.project_root = new_root
        self.agent.ctx.project_root = new_root
        self.agent.reset()
        self.agent.session_file = sessions_mod.new_path(new_root)
        self.agent.session_name = label
        self.ui.info(f"switched to {new_root} — fresh session")

    def _permissions_cmd(self, rest: str) -> None:
        if not rest:
            for action in ("allow", "ask", "deny"):
                rules = self.config.permissions[action]
                self.console.print(f"[bold]{action}[/bold] ({len(rules)})")
                for r in rules:
                    self.console.print(f"  {terminal_safe_text(r)}", markup=False, highlight=False)
            return
        m = re.match(r"(allow|ask|deny)\s+(.+)", rest, re.S)
        if not m:
            self.ui.error("usage: /permissions allow|ask|deny Tool(pattern)")
            return
        action, rule_text = m.group(1), m.group(2).strip()
        try:
            Rule.parse(rule_text, action)
        except ValueError as e:
            self.ui.error(str(e))
            return
        self.config.permissions[action].append(rule_text)
        self.config.save()
        self.ui.info(f"rule saved: {action} {rule_text}")

    def _memory_cmd(self, rest: str) -> None:
        if not rest or rest == "show":
            proj, user = memory_mod.load_memories(
                self.config.project_root,
                sanitizer=lambda value: redact_text(value, secret_values(self.config)))
            self.console.print(Panel(
                _literal_cell(memory_mod.bounded_memory_view(proj or "(none)", 8000)),
                title="project DGC.md", expand=False))
            self.console.print(Panel(
                _literal_cell(memory_mod.bounded_memory_view(user or "(none)", 8000)),
                title="~/.dgc/DGC.md", expand=False))
            return
        m = re.match(r"add\s+(user\s+)?(.+)", rest, re.S)
        if not m:
            self.ui.error("usage: /memory [show] | /memory add [user] TEXT")
            return
        scope = "user" if m.group(1) else "project"
        self.agent.cancelled.clear()
        path = memory_mod.add_memory(
            m.group(2), self.config.project_root, scope, cancelled=self.agent.cancelled)
        self.ui.info(f"memory saved to {path}")

    # ----------------------------------------------------------- input prep ---
    def expand_mentions(self, text: str) -> str:
        """Prepare @path attachments through the shared explicit-user disclosure boundary."""
        self.agent._pending_images = None
        result = attachments_mod.expand_attachments(
            text, self.config.project_root,
            sanitizer=lambda value: redact_text(value, secret_values(self.config)),
            cancelled=self.agent.cancelled)
        self.agent._pending_images = list(result.images) or None
        for notice in result.notices:
            self.ui.info(notice)
        return result.text

    def run_bang(self, command: str) -> None:
        from .tools import direct_bash
        self.agent.cancelled.clear()
        out = direct_bash(command, self.agent.ctx)
        # Shell output is data, never Rich markup. This also keeps terminal control text from being
        # interpreted as a DGC status/card even when a build dependency prints hostile diagnostics.
        self.console.print(terminal_safe_text(out), markup=False, highlight=False, soft_wrap=True)

    # ---------------------------------------------------------------- loop ---
    def repl(self) -> None:
        self.banner()
        USER_HOME.mkdir(parents=True, exist_ok=True)
        session: PromptSession = PromptSession(
            history=FileHistory(str(USER_HOME / "history")),
            completer=ClassicSlashCompleter(self.config.project_root, self.config),
            complete_while_typing=True)
        from prompt_toolkit.formatted_text import ANSI
        queue: list[str] = []
        draft = ""
        self._followup_queue = queue
        while True:
            mode = self.agent.mode
            th = style_mod.theme()
            acc, dim, rst = style_mod.ansi_fg(th.accent), style_mod.ansi_fg(th.faint), style_mod.ANSI_RESET
            if queue and not getattr(self, "_queue_paused", False):
                line = queue.pop(0)
                self.console.print(
                    f"  [{DIM}]{glyphs.ARROW} {_markup_literal(line)}[/]", highlight=False)
            else:
                try:                                    # ❯ prefix + right-aligned `model · mode`
                    rp = ANSI(f"{dim}{terminal_safe_text(self._model_label())}  {glyphs.MIDDOT}  "
                              f"{terminal_safe_text(mode)}{rst}")
                    line = session.prompt(ANSI(f"{acc}{glyphs.ARROW}{rst} "), rprompt=rp, default=draft).strip()
                    draft = ""
                except KeyboardInterrupt:
                    continue
                except EOFError:
                    break
            if not line:
                continue
            try:
                from .composer import composer_token, compose_prompt
                token = composer_token(line, len(line))
                if token and token[0] == "/" and token[2] > 0:
                    name, prefix = token[1], line[:token[2]].rstrip()
                    from .commands import resolve_command, discover_commands
                    if resolve_command(name, "classic"):
                        if name in ("goal", "plan", "review", "init"):
                            self.handle_slash("/" + name + " " + prefix)
                        else:
                            draft = prefix
                            self.handle_slash("/" + name)
                        continue
                    if name in discover_commands(self.config.project_root):
                        if re.match(r"(?i)^/goal(?:\s|$)", prefix):
                            self.handle_slash(line)
                            continue
                        line = compose_prompt(prefix, templates=[name], catalog=self.agent.skills,
                                              project_root=self.config.project_root)
                if line.startswith("/"):
                    self.handle_slash(line)
                elif line.startswith("#"):
                    self.agent.cancelled.clear()
                    path = memory_mod.add_memory(
                        line[1:], self.config.project_root, cancelled=self.agent.cancelled)
                    self.ui.info(f"memory saved to {path}")
                elif line.startswith("!"):
                    self.run_bang(line[1:])
                else:
                    self._run_turn_live(self.expand_mentions(line), queue)
            except EOFError:
                break
            except KeyboardInterrupt:
                self.ui.info("interrupted")
            except Exception as e:  # keep the REPL alive
                self.ui.error(f"{type(e).__name__}: {e}")
        self.console.print("[dim]bye[/dim]")

    def _run_turn_body(self, text: str):
        """One turn: through the connected subscription CLI when there is one, else the native
        agent loop. _run_turn_live cleared stale state before exposing the interruptible turn, so
        neither path resets cancellation — an Esc that lands while the worker starts must hold."""
        engine = str(self.config.get("subscription_engine", "") or "").strip().lower()
        if engine:
            return self._run_delegated_turn(engine, text)
        return self.agent.run_turn(text, reset_cancel=False)

    def _run_delegated_turn(self, engine_key: str, prompt: str) -> bool:
        """The classic REPL's delegated turn. The vendor CLI's stream renders through the same
        inline callbacks a native turn uses, so the spinner, the tool cards and the done marker
        behave identically; Esc/Ctrl-C kills the vendor's whole process group. --classic used to
        fall back to the native model here, silently, whatever the user had connected."""
        from . import subscriptions as subs
        engine = subs.get_engine(engine_key)
        if engine is None:
            self.ui.error(f"unknown subscription engine '{engine_key}'")
            return False
        if getattr(self.agent, "_pending_images", None):
            self.agent._pending_images = None
            self.ui.error("subscription CLI delegation does not yet support DGC image attachments")
            return False
        try:
            subs.preflight(engine)
        except subs.EngineError as exc:
            self.ui.error(str(exc))
            return False
        self.ui.info(f"running this turn through {engine.label}…")
        self.ui.start_working(engine.short_label)     # info() cleared the spinner; spin to the first event
        try:
            res = subs.delegate_turn(self.config, self.agent, self.ui, engine, prompt)
        except subs.EngineError as exc:
            self.ui.error(str(exc))
            return False
        if res.get("cancelled"):
            return False
        if res.get("timeout"):
            self.ui.error("the delegated turn hit the time budget and was stopped")
            return False
        if res.get("error"):
            self.ui.error(str(res["error"]))
        elif res.get("rc") not in (0, None):
            self.ui.error(f"{engine.short_label} exited with status {res['rc']}")
        return bool(res.get("ok"))

    def _model_label(self) -> str:
        """What the prompt calls 'the model': the connected subscription's route when there is
        one (its own model if steered), else the endpoint model — as the full-screen app shows."""
        engine_key = str(self.config.get("subscription_engine", "") or "").strip().lower()
        if engine_key:
            from . import subscriptions as subs
            engine = subs.get_engine(engine_key)
            if engine is not None:
                model = str(self.config.get("subscription_model", "") or "").strip()
                return f"{engine.short_label} · {model}" if model else f"{engine.short_label} · subscription"
        return str(self.config.model)

    def _connect_engine(self, engine) -> None:
        """/connect <engine>: route this REPL's turns through the user's own subscription CLI."""
        from . import subscriptions as subs
        try:
            subs.preflight(engine)
        except subs.EngineError as exc:
            self.ui.error(str(exc))
            return
        try:
            subs.validate_engine_mode(engine.key, self.agent.mode)
        except subs.EngineModeUnsupported as exc:
            self.ui.error(f"{exc} — change it with /mode first, then /connect {engine.key}")
            return
        cfg = self.config
        cfg.set("subscription_engine", engine.key)
        cfg.set("subscription_model", "")
        cfg.set("subscription_effort", "")
        self.ui.info(f"{engine.label} now runs your turns  ·  "
                     "/model and /think steer its own model and effort  ·  "
                     "/connect <provider> returns to a model endpoint")

    def _run_turn_live(self, text: str, queue: list[str]) -> None:
        """Run a turn on a worker thread while the main thread watches the keyboard:
        Esc / Ctrl-C interrupts the turn; Enter steers native turns, Tab queues the next turn.
        The reader cleanly hands stdin back when a tool needs an approval prompt."""
        self._followup_queue = queue
        self._queue_paused = False
        self.agent.cancelled.clear()
        self.ui._tool_count = 0
        t0 = time.time()
        self.ui.start_working()          # live spinner until the first token / tool
        done = threading.Event()
        outcome = {"failed": False}

        def work() -> None:
            try:
                outcome["failed"] = self._run_turn_body(text) is False
            except Exception as e:
                outcome["failed"] = True
                self.ui.error(f"{type(e).__name__}: {e}")
            finally:
                take = getattr(self.agent, "take_deferred_steers", None)
                deferred = take() if callable(take) else []
                queue[:0] = deferred
                self._queue_paused = bool(queue) and (outcome["failed"] or self.agent.cancelled.is_set())
                if self._queue_paused:
                    self.ui.info("Follow-ups retained. Send a new prompt to continue the queue.")
                self.ui.stop_working()
                done.set()

        threading.Thread(target=work, daemon=True).start()

        if not (sys.stdin.isatty() and sys.stdout.isatty()):
            done.wait()
            self.ui.turn_complete(time.time() - t0, self.agent.cancelled.is_set(),
                                  failed=outcome["failed"])
            return

        import select as _sel
        import termios
        import tty
        fd = sys.stdin.fileno()
        live = {"active": threading.Event(), "stop": threading.Event(), "released": threading.Event()}
        live["active"].set()
        self.ui._live = live
        old = termios.tcgetattr(fd)
        buf = ""
        import codecs
        decoder = codecs.getincrementaldecoder("utf-8")("replace")
        try:
            tty.setcbreak(fd)  # char-at-a-time, ECHO off, but keep \n->\r\n and signals
            while not done.is_set():
                if live["stop"].is_set():
                    break                       # an approval prompt needs stdin — hand it over
                try:
                    r, _, _ = _sel.select([fd], [], [], 0.12)
                except (OSError, ValueError):
                    break
                if not r:
                    continue
                try:
                    ch = decoder.decode(os.read(fd, 1))
                except OSError:
                    break
                if ch in ("\x1b", "\x03"):       # Esc / Ctrl-C — interrupt this turn
                    self.agent.cancelled.set()
                    self.console.print("\n[dim]⎋ interrupting…[/dim]", highlight=False)
                    buf = ""
                elif ch in ("\r", "\n", "\t"):
                    if buf.strip():
                        entry = buf.strip()
                        action = entry.lower()
                        from .commands import resolve_command
                        name, _, arguments = entry[1:].partition(" ") if entry.startswith("/") else ("", "", "")
                        spec = resolve_command(name, "classic")
                        if spec and spec.name == "skills":
                            from .skills import manage_skills
                            try:
                                output = manage_skills(self.config, arguments, catalog=self.agent.skills, read_only=True)
                                self.console.print(terminal_safe_text(redact_text(output, secret_values(self.config))), markup=False)
                            except (OSError, ValueError) as exc:
                                self.ui.error(str(exc))
                        elif spec and spec.name == "mode":
                            self.handle_slash(entry)
                        elif action in ("/goal pause", "/goal clear", "/goal delete"):
                            self.agent.request_goal_control("pause" if action.endswith("pause") else "clear")
                        elif action in ("/goal", "/goal review", "/goal status"):
                            from .goals import review_markdown
                            self.console.print(render.render_markdown(terminal_safe_text(review_markdown(self.agent.goal_snapshot()))))
                        elif ch != "\t" and not entry.startswith("/") and self.agent.steer(entry):
                            self.console.print("↳ applying follow-up", style="dim")
                        else:
                            queue.append(entry)
                            self.console.print(f"[dim]↵ queued: {_markup_literal(entry[:70])}[/dim]", highlight=False)
                    buf = ""
                elif ch == "\x7f":               # backspace
                    buf = buf[:-1]
                elif ch.isprintable():
                    buf += ch
        except KeyboardInterrupt:
            self.agent.cancelled.set()
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
            live["active"].clear()
            live["released"].set()               # let a waiting approval proceed
            self.ui._live = None
        done.wait()
        self.ui.turn_complete(time.time() - t0, self.agent.cancelled.is_set(),
                              failed=outcome["failed"])


def run_doctor(config: Config) -> None:
    """`dgc doctor` — verify the endpoint is reachable and the model is available."""
    from . import sandbox
    from .llm import LLMClient
    c = Console()
    sandbox_report = sandbox.capabilities(config)
    sandbox_requested = sandbox.requested(config)
    c.print("[bold]DGC doctor[/bold] — checking your setup\n")
    c.print(f"  endpoint      {terminal_safe_text(config.base_url)}", markup=False,
            highlight=False)
    c.print(f"  model         {terminal_safe_text(config.model)}", markup=False, highlight=False)
    c.print(f"  mode          {terminal_safe_text(config.data.get('mode', 'default'))}", markup=False,
            highlight=False)
    c.print(f"  context_size  {config.get('context_size')}", markup=False, highlight=False)
    c.print(f"  config file   {terminal_safe_text(USER_CONFIG)}", markup=False, highlight=False)
    c.print(f"  sandbox       {'on' if sandbox_requested else 'off'} — "
            f"{terminal_safe_text(sandbox.describe(config))}\n", markup=False, highlight=False)
    if sandbox_requested and sandbox_report.available:
        c.print(f"  sandbox fs    {terminal_safe_text(sandbox_report.filesystem)}", markup=False,
                highlight=False)
        c.print(f"  sandbox home  {terminal_safe_text(sandbox_report.home)}", markup=False,
                highlight=False)
        c.print(f"  sandbox temp  {terminal_safe_text(sandbox_report.temporary)}", markup=False,
                highlight=False)
        c.print(f"  sandbox proc  {terminal_safe_text(sandbox_report.process)}", markup=False,
                highlight=False)
        c.print(f"  sandbox net   {terminal_safe_text(sandbox_report.network)}\n", markup=False,
                highlight=False)
    if sandbox_requested and not sandbox_report.available:
        c.print("  [bold red]✗[/bold red] sandbox is enabled but this platform has no supported backend")
        c.print("    → install bubblewrap on Linux, use sandbox-exec on macOS, or run [bold]/sandbox off[/bold]")
    # installation — which install runs, and which one `dgc update` would change
    try:
        from . import install_layout as _layout
        install_rows, install_notes = _layout.installation_report()
    except Exception as exc:  # a diagnostic must not stop the endpoint check below
        install_rows, install_notes = [], [f"could not inspect the installation: {type(exc).__name__}: {exc}"]
    c.print("  [bold]installation[/bold] — what runs and what `dgc update` changes")
    # soft_wrap: these are mostly paths, and a path folded at the console width cannot be copied.
    for label, value in install_rows:
        c.print(f"    {label:15}{terminal_safe_text(value)}", markup=False, highlight=False,
                soft_wrap=True)
    for note in install_notes:
        c.print(f"  [yellow]![/yellow] {_markup_literal(note)}", highlight=False, soft_wrap=True)
    c.print("")
    # subscription engines — run your own plan through the official first-party CLI
    from . import subscriptions as _subs
    active = str(config.get("subscription_engine", "")).strip().lower()
    active_problem = ""
    c.print("  [bold]subscription engines[/bold] — run your own plan via the official CLI")
    subscription_status = _subs.status()
    for s in subscription_status:
        if s["auth_state"] == "signed_in":
            state = "[green]✓ signed in[/green]"
        elif s["auth_state"] == "check_on_launch":
            state = "[cyan]? auth checked by CLI on launch[/cyan]"
        elif s["auth_state"] == "signed_out":
            state = "[yellow]! not signed in[/yellow]"
        else:
            state = "[dim]not installed[/dim]"
        star = "  [bold cyan]← active[/bold cyan]" if s["key"] == active else ""
        c.print(f"    {s['key']:6} {state}{star}")
    if active in _subs.ENGINES:
        eng = _subs.ENGINES[active]
        c.print(f"  [cyan]→ delegating each turn to {terminal_safe_text(eng.label)}[/cyan] "
                f"(the model endpoint below is only the fallback)\n")
        active_status = next(s for s in subscription_status if s["key"] == active)
        if not active_status["installed"]:
            active_problem = f"the active {eng.short_label} CLI is not installed"
            c.print(f"  [yellow]![/yellow] {terminal_safe_text(active_problem)}\n")
        elif active_status["auth_state"] == "signed_out":
            active_problem = f"the active {eng.short_label} CLI is not signed in"
            c.print(f"  [yellow]![/yellow] but you are not signed in — run "
                    f"[bold]{terminal_safe_text(eng.login_cmd)}[/bold] once\n")
        elif eng.key == "kimi" and str(config.data.get("mode", "default")) != "auto":
            active_problem = "Kimi prompt mode requires DGC auto mode"
            c.print("  [yellow]![/yellow] Kimi's prompt mode is inherently auto-approved; "
                    "select [bold]/mode auto[/bold] or another engine\n")
    else:
        c.print("")
    client = LLMClient(config.base_url, config.api_key, config.model,
                       api_mode=str(config.get("api_mode", "auto")))
    try:
        models = client.list_models()
    except Exception as e:
        c.print(f"  [bold red]✗[/bold red] cannot reach {_markup_literal(config.base_url)} — "
                f"{_markup_literal(type(e).__name__)}: {_markup_literal(e)}")
        c.print("    → start your server (ollama serve / llama-server / LM Studio) or fix the URL & key")
        c.print("    → run [bold]dgc setup[/bold] to reconfigure")
        return
    c.print(f"  [green]✓[/green] endpoint reachable — {len(models)} model(s) offered")
    if config.model in models:
        c.print(f"  [green]✓[/green] model '{_markup_literal(config.model)}' is available")
    else:
        c.print(f"  [yellow]![/yellow] model '{_markup_literal(config.model)}' not offered by this server")
        if models:
            shown = ", ".join(models[:12]) + ("…" if len(models) > 12 else "")
            c.print(f"    available: {terminal_safe_text(shown)}", markup=False, highlight=False)
        c.print("    → set one: [bold]dgc --model <name>[/bold]  or  [bold]dgc setup[/bold]")
    if active_problem:
        c.print(f"\n  [bold red]not ready[/bold red] — {terminal_safe_text(active_problem)}.\n")
    elif sandbox_requested and not sandbox_report.available:
        c.print("\n  [bold red]not ready[/bold red] — sandboxed shell commands will fail closed.\n")
    else:
        c.print("\n  [bold green]ready[/bold green] — run [bold]dgc[/bold] to start.\n")


def export_training_core(config, *, out: str = "./dgc-training.jsonl", all_projects: bool = False,
                         session: str | None = None, successful_only: bool = False,
                         min_turns: int = 1) -> dict:
    """Shared engine for `dgc export-training` and the `/export-training` slash command.

    Read-only over the persisted transcripts: selects the session files for the chosen scope,
    reshapes + deep-scrubs each into one training record, and writes them as JSONL. Returns a
    summary dict (``scope``/``written``/``skipped``/``out``/``successful_only``) or ``{"error": …}``.
    """
    from . import training_export
    secrets = secret_values(config)
    if session:
        p = sessions_mod.by_id(config.project_root, session)
        if p is None:
            found = sessions_mod.find_global(session)
            p = found[0] if found else None
        if p is None:
            return {"error": f"no session '{session}' found"}
        files = [p]
        scope = f"session {p.stem}"
    elif all_projects:
        files = [row[0] for row in sessions_mod.listing_all(redact_secrets=secrets)]
        scope = "all projects"
    else:
        files = [row[0] for row in sessions_mod.listing(
            config.project_root, redact_secrets=secrets)]
        scope = f"project {config.project_root.name}"
    total = len(files)
    records = list(training_export.iter_training_records(
        files, config, successful_only=successful_only, min_turns=max(1, int(min_turns or 1))))
    out_path = Path(out).expanduser()
    written = training_export.write_jsonl(records, out_path)
    return {"scope": scope, "written": written, "skipped": total - written,
            "out": out_path, "successful_only": successful_only}


def run_export_training(argv: list[str]) -> int:
    """`dgc export-training` — turn real DGC sessions into scrubbed, training-ready JSONL.

    Read-only over the persisted transcripts: reshapes each session into one OpenAI-style
    ``messages`` record (with ``tool_calls``) plus outcome ``meta``, deep-scrubs every field of
    every record through the redaction layer, and writes one JSON object per line.
    """
    parser = argparse.ArgumentParser(
        allow_abbrev=False, prog="dgc export-training",
        description="Export your real DGC sessions as scrubbed fine-tuning JSONL for a local model.")
    parser.add_argument("--out", default="./dgc-training.jsonl", metavar="FILE",
                        help="output JSONL path (default ./dgc-training.jsonl)")
    parser.add_argument("--all", action="store_true",
                        help="export sessions from every project (default: this project's sessions)")
    parser.add_argument("--session", metavar="ID",
                        help="export a single session by id (a unique prefix is accepted)")
    parser.add_argument("--successful-only", action="store_true",
                        help="keep only sessions that show successful work (an edit landed, no edit "
                             "failures, or a completed goal)")
    parser.add_argument("--min-turns", type=int, default=1, metavar="N",
                        help="drop sessions with fewer than N user turns (default 1)")
    args = parser.parse_args(argv)

    config = Config()
    c = Console()

    summary = export_training_core(
        config, out=args.out, all_projects=args.all, session=args.session,
        successful_only=args.successful_only, min_turns=args.min_turns)
    if summary.get("error"):
        c.print(f"  [yellow]![/yellow] {terminal_safe_text(summary['error'])}")
        return 1
    scope = summary["scope"]
    written = summary["written"]
    skipped = summary["skipped"]
    out_path = summary["out"]

    c.print("[bold]DGC export-training[/bold] — your sessions → scrubbed fine-tuning JSONL\n")
    c.print(f"  scope         {terminal_safe_text(scope)}", markup=False, highlight=False)
    c.print(f"  exported      {written} session(s)", markup=False, highlight=False)
    c.print(f"  skipped       {skipped} (empty / below --min-turns"
            + ("/ not successful" if args.successful_only else "") + ")",
            markup=False, highlight=False)
    c.print(f"  output        {terminal_safe_text(out_path)}", markup=False, highlight=False)
    c.print("  secrets       [green]scrubbed[/green] — every field deep-redacted before export")
    if written == 0:
        c.print("\n  [yellow]nothing exported[/yellow] — no matching sessions in this scope.\n")
    else:
        c.print(f"\n  [bold green]done[/bold green] — wrote {written} record(s) "
                f"to {terminal_safe_text(out_path)}\n", markup=True, highlight=False)
    return 0


def run_setup(config: Config) -> None:
    """`dgc setup` — interactive first-run wizard: pick a provider, key, model, context."""
    from .llm import LLMClient
    c = Console()
    c.print("\n[bold]DGC setup[/bold] — point DGC at a model you run\n")
    from .menu import select
    from . import subscriptions as _subs
    # Subscription engines first — run your own Claude/Codex/Qwen/Kimi plan via its official CLI.
    subs_status = _subs.status()
    sub_labels = [f"{s['label']} — your own subscription" for s in subs_status]
    sub_hints = [("✓ signed in" if s["auth_state"] == "signed_in"
                  else ("authentication checked securely by the CLI on launch"
                        if s["auth_state"] == "check_on_launch" else
                        f"not signed in · run: {s['login_cmd']}" if s["installed"]
                        else "CLI not installed")) for s in subs_status]
    keys = list(PROVIDERS)
    prov_labels = sub_labels + [PROVIDERS[k]["label"] for k in keys] + ["custom endpoint (enter your own URL)"]
    prov_hints = sub_hints + [PROVIDERS[k]["base_url"] for k in keys] + [""]
    idx = select("Provider", prov_labels, prov_hints)
    if idx is None:
        c.print("[dim]cancelled[/dim]"); return
    n_sub = len(subs_status)
    if idx < n_sub:
        s = subs_status[idx]
        try:
            _subs.validate_engine_mode(s["key"], str(config.get("mode", "default")))
        except _subs.EngineModeUnsupported:
            auto_warning(c)
            accepted = input(
                f"  {s['label'].split(' (')[0]} requires full-auto; enable it? [y/N] › "
            ).strip().lower() in ("y", "yes")
            if not accepted:
                c.print("  [dim]cancelled — provider and permission mode were not changed[/dim]\n")
                return
            config.set("mode", "auto")
        config.set("subscription_engine", s["key"])
        config.set("subscription_model", "")
        config.set("subscription_effort", "")
        c.print(f"\n  [bold green]selected[/bold green] {terminal_safe_text(s['label'])} — "
                f"DGC will run each turn through your subscription via the official CLI.")
        if s["auth_state"] == "signed_in":
            c.print("  [green]✓ already signed in.[/green]")
        elif s["auth_state"] == "check_on_launch":
            c.print("  [cyan]authentication will be verified by the official CLI on first run.[/cyan]")
        else:
            c.print(f"  [yellow]sign in first:[/yellow] run "
                    f"[bold]{terminal_safe_text(s['login_cmd'])}[/bold] once, then retry.")
        c.print('  try it:  [bold]dgc -p "list the files in this folder"[/bold]  ·  '
                "[bold]dgc doctor[/bold] to verify\n")
        return
    idx -= n_sub                          # shift back into the direct-model provider list
    if idx < len(keys):
        prov = PROVIDERS[keys[idx]]
        base_url, api_key = prov["base_url"], prov["api_key"]
        if prov["needs_key"]:
            from getpass import getpass
            api_key = getpass(f"  API key for {prov['label']} › ").strip() or api_key
    else:
        base_url = input("  base URL (…/v1) › ").strip()
        if not base_url:
            c.print("[dim]cancelled[/dim]"); return
        base_url, _bu_changed = normalize_custom_base_url(base_url)
        if _bu_changed:
            c.print(f"  [dim]normalized endpoint to {base_url} (OpenAI-compatible path)[/dim]")
        from getpass import getpass
        api_key = getpass("  API key (blank for local) › ").strip() or "sk-local"
    config.set("subscription_engine", "")     # a direct model turns delegation back off
    config.set("base_url", base_url)
    if idx < len(keys):
        config.set("api_mode", "auto")
    config.set("api_key", api_key)
    client = LLMClient(config.base_url, config.api_key, config.model,
                       api_mode=str(config.get("api_mode", "auto")))
    try:
        models = client.list_models()
    except Exception as e:
        c.print(f"  [yellow]couldn't list models[/yellow] ({type(e).__name__}) — set one by name below.")
        models = []
    model_changed = False
    if models:
        mi = select("Model", models[:60])
        if mi is not None:
            config.set("model", models[mi])
            model_changed = True
    else:
        m = input(f"  model name [{config.model}] › ").strip()
        if m:
            config.set("model", m)
            model_changed = True
    if model_changed:
        from .config import context_for_model
        selected_client = LLMClient(
            config.base_url, config.api_key, config.model,
            api_mode=str(config.get("api_mode", "auto")))
        discovered_context = (selected_client.model_context_limit()
                              if selected_client.api_mode == "anthropic" else 0)
        suggested_context = discovered_context or context_for_model(config.model)
        if suggested_context:
            config.set("context_size", suggested_context)
    cs = input(f"  context window in tokens [{config.get('context_size')}] › ").strip()
    if cs.isdigit():
        config.set("context_size", int(cs))
    skeys = list(SEARCH_PROVIDERS)
    si = select("Web search  (optional — powers the web_search tool)",
                [SEARCH_PROVIDERS[k]["label"] for k in skeys])
    sk = skeys[si] if si is not None else "duckduckgo"
    config.set("search_provider", sk)
    meta = SEARCH_PROVIDERS[sk]
    if meta["needs_key"]:
        from getpass import getpass
        config.set("search_api_key", getpass(f"  API key for {meta['label']} › ").strip())
    if meta["needs_url"]:
        config.set("search_url", input(f"  base URL for {meta['label']} › ").strip())
    c.print(f"\n  [bold green]saved[/bold green] → {_markup_literal(USER_CONFIG)}")
    c.print(f"  endpoint {terminal_safe_text(config.base_url)}  ·  "
            f"model {terminal_safe_text(config.model)}  ·  "
            f"context {config.get('context_size')}  ·  search {config.get('search_provider')}",
            markup=False, highlight=False)
    c.print("  run [bold]dgc[/bold] to start  ·  [bold]dgc doctor[/bold] to verify\n")


def run_help() -> None:
    """`dgc help` — CLI commands + in-REPL commands, for new users."""
    c = Console()
    c.print("\n[bold]DGC[/bold] — a coding-agent CLI for the models you run  [dim](Built by Mohit Kalra)[/dim]\n")
    c.print("[bold]command line[/bold]")
    c.print("  dgc                     start the interactive agent")
    c.print("  dgc setup               configure provider / model / context")
    c.print("  dgc doctor              check the endpoint + model are reachable")
    c.print("  dgc help                this help")
    c.print("  dgc -p \"<task>\"         run one task and exit  (add --mode auto for hands-off)")
    c.print("  git diff | dgc -p \"…\"   piped input is appended to the prompt; -p - reads it as the prompt")
    c.print("  dgc -p … --output-format json   the dgc serve event stream, ending in a result object")
    c.print("  dgc -p … --output FILE --print-session-id      save the answer · print the id for --resume")
    c.print("  dgc --add-dir PATH --allow-tool RULE --sandbox on|off|read-only   per-run permissions")
    c.print("  dgc --mode MODE         default | acceptEdits | plan | auto")
    c.print("  dgc -c / --continue     resume the most recent session in this directory")
    c.print("  dgc --resume            pick a past session to resume")
    c.print("  dgc --classic           inline mode: the transcript stays in your terminal's scrollback")
    c.print("  dgc update              update DGC to the latest version")
    c.print("  dgc export [ID] [FILE]  save a session as Markdown")
    c.print("  dgc trust               list the folders the trust gate skips  (dgc trust revoke N|PATH|here)")
    c.print("  dgc notes [QUERY]       what this project already learned, across sessions")
    c.print("  dgc usage               tokens counted on this machine, by model and day  (--range R, --json)")
    c.print("  dgc export-training     export your sessions as scrubbed fine-tuning JSONL")
    c.print("  dgc protocol describe   inspect the installed headless/editor contract as JSON")
    c.print("  dgc skills              list, create, install and manage skill packages")
    c.print("  dgc mcp                 manage servers, resources, prompts and connections")
    c.print("  dgc serve · dgc acp     editor back-ends (JSON over stdio · Agent Client Protocol)")
    c.print("  dgc bug                 where to report a bug")
    c.print("  dgc <command> --help    usage for any of the above")
    c.print("  dgc --model N --base-url URL --api-key-env NAME   configure without exposing a key\n")
    render_help(c)


def run_usage(argv: list[str]) -> int:
    """`dgc usage [--range R] [--json]`: the local token ledger, read-only.

    It never builds a Config or an Agent: reading the ledger needs no endpoint, key or project.
    """
    from . import usage_ledger
    parser = argparse.ArgumentParser(
        prog="dgc usage", allow_abbrev=False,
        description="Tokens and requests DGC counted on this machine, by model and by day.")
    parser.add_argument("--range", dest="range_name", default="7d",
                        help="today, 7d, 30d, month or all (default 7d)")
    parser.add_argument("--json", action="store_true", help="print the report as JSON")
    try:
        args = parser.parse_args(argv)
        range_name = usage_ledger.normalize_range(args.range_name)
    except SystemExit as exc:
        return int(exc.code or 0)
    except ValueError as exc:
        print(f"dgc usage: {exc}", file=sys.stderr)
        return 2
    report = usage_ledger.report(range_name)
    if args.json:
        print(json.dumps(report, indent=2))
    else:
        Console().print(render.render_markdown(usage_ledger.format_report(report, shell=True)))
    return 1 if report.get("error") else 0


SUBCOMMAND_USAGE: dict[str, str] = {
    "setup": "dgc setup                          configure provider, model and context interactively",
    "doctor": "dgc doctor                         check that the endpoint and model are reachable",
    "help": "dgc help                           the command overview",
    "update": "dgc update [--rollback|--version X|--list]  install the latest DGC beside this one, or switch versions",
    "export": "dgc export [ID] [FILE]             save a session as Markdown (default: the most recent, to ~/.dgc/exports)",
    "trust": "dgc trust [revoke N|PATH|here]     list the folders the trust gate skips, or forget one",
    "notes": "dgc notes [QUERY]                  what this project already learned; searches the trace",
    "usage": "dgc usage [--range today|7d|30d|month|all] [--json]   tokens counted on this machine, by model and day",
    "export-training": "dgc export-training [--help]       export sessions as scrubbed fine-tuning JSONL",
    "serve": "dgc serve                          headless JSON backend for editor front-ends (stdio)",
    "acp": "dgc acp                            Agent Client Protocol backend (JSON-RPC over stdio)",
    "protocol": "dgc protocol describe|validate     inspect or validate the editor/headless contract",
    "bug": "dgc bug                            where to report a bug or request a feature",
    "skills": "dgc skills [list|reload|show NAME|enable NAME|disable NAME|create NAME [--user]|install DIR [--user] [--allow-external]]",
    "mcp": "dgc mcp ...                        manage MCP servers, resources, prompts and connections",
}


def _subcommand_help(name: str) -> int:
    """`--help` on a subcommand prints its usage and exits; it never runs the subcommand."""
    print("usage: " + SUBCOMMAND_USAGE[name])
    if name == "update":
        print("  Downloads install.sh from $DGC_BASE_URL (default https://vibedgc.com) to a temporary\n"
              "  file and runs it with bash. The new version is built in its own directory; the dgc\n"
              "  launcher switches to it only once it is complete, so a failed update leaves the\n"
              "  current version running.\n"
              "  --rollback     switch back to the version that was active before the last switch\n"
              "                 (when none is recorded, the newest kept version older than the active one)\n"
              "  --version X    switch to kept version X, or install X if it is the published release\n"
              "  --list         show the kept versions and which one is active\n"
              "  Exit status: 0 done, 1 failed (previous version still active), 2 usage error,\n"
              "  3 another update is running.")
    return 0


def main(argv: list[str] | None = None) -> int | None:
    raw_argv = list(sys.argv[1:] if argv is None else argv)
    # A dgc started from a versioned install marks its version as in use, so an update's
    # retention never deletes the tree under a running process (no-op for any other install).
    from .install_layout import hold_runtime_lock
    hold_runtime_lock()
    if raw_argv and raw_argv[0] in SUBCOMMAND_USAGE:
        # Every subcommand honours the universal help reflex BEFORE anything can run. Six of
        # eleven used to execute instead — `dgc update --help` piped a remote installer into bash.
        if any(value in ("--help", "-h") for value in raw_argv[1:]) and raw_argv[0] not in ("export-training", "protocol"):
            return _subcommand_help(raw_argv[0])
        if raw_argv[0] == "mcp":
            from .mcp_management import manage_mcp, USAGE
            cfg = Config()
            from .mcp import MCPManager
            ui = UI()
            manager = MCPManager(cfg.project_root, disabled_names=cfg.get("disabled_mcp_servers", []),
                                 client_capabilities=Agent._mcp_client_capabilities(ui))
            agent = Agent(cfg, ui, mcp=manager)
            try:
                if len(raw_argv) >= 3 and raw_argv[1] in ("resources", "templates", "prompts", "read", "prompt"):
                    runtime = cfg.mcp_runtime_servers()
                    name = raw_argv[2]
                    if name not in runtime:
                        raise ValueError("Unknown MCP server")
                    manager.connect_all({name: runtime[name]}, cancel=agent.cancelled, input_handler=agent._handle_mcp_input)
                result = manage_mcp(cfg, agent.mcp, shlex.join(raw_argv[1:]), agent=agent)
                output = json.dumps(result, ensure_ascii=False, indent=2) if isinstance(result, dict) else result
                print(terminal_safe_text(redact_text(output, secret_values(cfg))))
                return 0
            except (OSError, ValueError) as exc:
                print(terminal_safe_text(redact_text(str(exc), secret_values(cfg))), file=sys.stderr)
                return 1
            finally:
                agent.mcp.stop_all()
        if raw_argv[0] == "skills":
            from .skills import manage_skills
            cfg = Config()
            try:
                print(terminal_safe_text(redact_text(manage_skills(cfg, shlex.join(raw_argv[1:])), secret_values(cfg))))
                return 0
            except (OSError, ValueError) as exc:
                print(terminal_safe_text(redact_text(str(exc), secret_values(cfg))), file=sys.stderr)
                return 1
        if raw_argv[0] == "help":
            run_help(); return
        if raw_argv[0] == "export-training":
            return run_export_training(raw_argv[1:])
        if raw_argv[0] == "bug":
            print("\n  Report a bug or request a feature:\n"
                  "    https://github.com/OpenPeach-ai/dgc/issues\n")
            return
        if raw_argv[0] == "update":
            return run_update(raw_argv[1:])
        if raw_argv[0] == "notes":
            from .notes import handle_command
            cfg = Config()
            agent = Agent(cfg, UI())
            Console().print(render.render_markdown(handle_command(agent, " ".join(raw_argv[1:]))))
            return 0
        if raw_argv[0] == "usage":
            return run_usage(raw_argv[1:])
        if raw_argv[0] == "trust":
            from .trust import handle_trust_command
            cfg = Config()
            Console().print(render.render_markdown(
                handle_trust_command(cfg, cfg.project_root, " ".join(raw_argv[1:]))))
            return 0
        if raw_argv[0] == "export":
            return run_export(raw_argv[1:])
        if raw_argv[0] == "serve":
            # headless JSON backend for editor front-ends — stdout is protocol-only,
            # so this returns before the banner / update-check ever run.
            from .headless import serve
            serve(Config()); return
        if raw_argv[0] == "acp":
            # Agent Client Protocol (JSON-RPC over stdio) for Zed/JetBrains/Neovim/Emacs.
            from .acp import serve as acp_serve
            acp_serve(); return
        if raw_argv[0] == "protocol":
            # Contract discovery/validation is intentionally side-effect-free: no Config, update
            # check, model endpoint, session, or user-state access.
            from .protocol_cli import main as protocol_main
            return protocol_main(raw_argv[1:])
        cfg = Config()
        for warning in cfg.credential_warnings:
            print(f"warning: {warning}", file=sys.stderr)
        (run_setup if raw_argv[0] == "setup" else run_doctor)(cfg)
        return

    parser = argparse.ArgumentParser(
        allow_abbrev=False,
        prog="dgc", description="DGC — a coding-agent CLI for the models you run",
        epilog="commands: setup · doctor · help · update · export · export-training · usage · protocol · skills · mcp · "
               "serve · acp · bug  (dgc <command> --help for each)  ·  dgc -p '<task>' runs one task")
    parser.add_argument("-p", "--prompt", help="run a single prompt non-interactively and exit")
    parser.add_argument("--mode", choices=MODES, help="permission mode for this session")
    parser.add_argument("--think", choices=DELEGATED_THINK_LEVELS,
                        help="thinking level for this session (with -p --engine, that delegated turn only)")
    ultra_group = parser.add_mutually_exclusive_group()
    ultra_group.add_argument("--ultra", dest="ultra", action="store_true", default=None,
                             help="use extended reasoning and proactive bounded sub-agents for this session")
    ultra_group.add_argument("--no-ultra", dest="ultra", action="store_false",
                             help="disable the Ultra execution profile for this session")
    parser.add_argument("--model",
                        help="model name (interactive: saved as your default; with -p: this run only)")
    parser.add_argument("--engine", metavar="NAME", default=None,
                        help="with -p, run the one-shot turn through a subscription CLI "
                             "(claude|codex|qwen|kimi|copilot) via your own login, without changing config")
    parser.add_argument("--base-url", help="OpenAI-compatible endpoint URL (interactive: saved; with -p: this run only)")
    parser.add_argument("--api-key-env", metavar="NAME",
                        help="read the endpoint API key from environment variable NAME without persisting it")
    parser.add_argument("--trust", action="store_true",
                        help="persist this workspace as trusted, then run non-interactive acceptEdits/auto")
    parser.add_argument("-c", "--continue", dest="cont", action="store_true",
                        help="resume the most recent session in this directory")
    parser.add_argument("--resume", nargs="?", const="", default=None, metavar="ID",
                        help="resume a past session by id (dgc --resume <id>), or pick one (dgc --resume)")
    parser.add_argument("--autonomous-gate", metavar="CMD", default=None,
                        help="a check command native local/API turns must pass before stopping; "
                             "delegated subscription turns bypass it")
    parser.add_argument("--autonomous-max-turns", type=int, default=None, metavar="N",
                        help="bound on failed --autonomous-gate retries before the turn stops (default 30)")
    parser.add_argument("--classic", action="store_true", help="use the classic inline REPL instead of the full-screen app")
    parser.add_argument("--output-format", choices=("text", "json"), default="text",
                        help="with -p: text, or the NDJSON event stream `dgc serve` speaks, ending in a result object")
    parser.add_argument("--output", metavar="FILE", default=None,
                        help="with -p: also write the final answer to FILE")
    parser.add_argument("--print-session-id", action="store_true",
                        help="with -p: print the session id on stderr, for --resume")
    parser.add_argument("--add-dir", action="append", metavar="PATH", default=None,
                        help="let this run read and edit files under PATH as well (repeatable)")
    parser.add_argument("--allow-tool", action="append", metavar="RULE", default=None,
                        help='pre-approve a tool for this run, e.g. "Bash(npm test)" or "Edit" (repeatable)')
    parser.add_argument("--sandbox", choices=("on", "off", "read-only"), default=None,
                        help="confine shell commands for this run; read-only also denies every file edit")
    parser.add_argument("--version", action="version", version=f"dgc {__version__}")
    args = parser.parse_args(argv)
    if not args.prompt:          # one-shot `-p` has no banner to show an update in — skip the check
        refresh_update_async()

    config = Config()
    for warning in config.credential_warnings:
        print(f"warning: {warning}", file=sys.stderr)
    if args.engine is not None and args.prompt is None:
        parser.error("--engine is available only with -p/--prompt")
    for flag, given in (("--output-format json", args.output_format == "json"),
                        ("--output", args.output is not None),
                        ("--print-session-id", args.print_session_id)):
        if given and args.prompt is None:
            parser.error(f"{flag} is available only with -p/--prompt")
    apply_run_flags(config, args, parser)
    # Work out the one-shot route before applying native model/thinking overrides.  When a
    # subscription engine owns this turn, --model/--think are vendor-CLI pass-throughs for this
    # invocation only; they must not silently rewrite the fallback native route in config.json.
    _oneshot_engine = (str(args.engine if args.engine is not None
                           else config.get("subscription_engine", "")).strip().lower()
                       if args.prompt is not None else "")
    _interactive_engine = (
        str(config.get("subscription_engine", "") or "").strip().lower()
        if args.prompt is None else ""
    )
    _override_engine = _oneshot_engine or _interactive_engine
    if args.think == "max" and not _override_engine:
        parser.error("--think max is available only when a subscription route is active")
    if _override_engine:
        from . import subscriptions as _subscriptions
        _override_spec = _subscriptions.get_engine(_override_engine)
        if args.think and _override_spec is not None and not _override_spec.supports_effort():
            parser.error(f"{_override_spec.short_label} does not expose a reasoning-effort flag; "
                         "select its reasoning model with --model instead")
        if args.mode is not None or args.prompt is not None:
            try:
                _subscriptions.validate_engine_mode(
                    _override_engine, args.mode or str(config.get("mode", "default")))
            except _subscriptions.EngineModeUnsupported as exc:
                parser.error(str(exc))
    # One-shot runs are scripts and benchmarks: a --model/--base-url there is for THIS run and must
    # not become the user's default. The interactive launch keeps the documented behaviour of
    # `dgc --model N --base-url URL` as a way to configure without exposing a key.
    _persist_flags = args.prompt is None
    if args.base_url:
        config.set("base_url", args.base_url, persist=_persist_flags)
    if args.api_key_env:
        if args.api_key_env not in os.environ:
            parser.error(f"environment variable {args.api_key_env!r} is not set")
        config.set_runtime_secret("api_key", os.environ[args.api_key_env])
    if args.model and not _oneshot_engine:
        if _interactive_engine:
            config.data["subscription_model"] = args.model
        else:
            config.set("model", args.model, persist=_persist_flags)
    if args.mode:
        config.data["mode"] = args.mode
    if args.think and not _oneshot_engine:
        if _interactive_engine:
            config.data["subscription_effort"] = "" if args.think == "off" else args.think
        else:
            config.data["thinking"] = args.think
    if args.ultra is not None:
        config.data["ultra_mode"] = args.ultra
    if args.autonomous_gate is not None:
        config.data["autonomous_gate"] = args.autonomous_gate
    if args.autonomous_max_turns is not None:
        config.data["autonomous_max_turns"] = args.autonomous_max_turns

    if args.prompt is not None:
        from .trust import is_trusted, mark_trusted
        if args.trust:
            mark_trusted(config, config.project_root)
        elif config.data.get("mode") in ("acceptEdits", "auto") and not is_trusted(config, config.project_root):
            parser.error("non-interactive acceptEdits/auto requires a trusted workspace; review it, then add --trust")

    cli = CLI(config, ui=_json_oneshot_ui(config)
              if args.prompt is not None and args.output_format == "json" else None)

    # session persistence (transcripts resume across runs)
    if args.cont:
        p = sessions_mod.latest(config.project_root)
        if p:
            n = cli.agent.load_session(p)
            cli.ui.info(f"resumed session ({n} messages) — {p.name}")
            cli._show_restored_todos()
            cli.agent.compact_resumed_session()
        else:
            cli.ui.info("no previous session here — starting fresh")
            cli.agent.session_file = sessions_mod.new_path(config.project_root)
    elif args.resume is not None and args.resume != "":     # `dgc --resume <id>` → load it directly
        p = sessions_mod.by_id(config.project_root, args.resume)
        if p:
            n = cli.agent.load_session(p)
            cli.ui.info(f"resumed session ({n} messages) — {p.stem}")
            cli._show_restored_todos()
            cli.agent.compact_resumed_session()
        else:
            cli.ui.info(f"no session '{args.resume}' in this project — starting fresh")
            cli.agent.session_file = sessions_mod.new_path(config.project_root)
    elif args.resume is not None:                           # `dgc --resume` → pick from a list
        items = sessions_mod.listing(
            config.project_root, redact_secrets=secret_values(config))
        if items:
            from .menu import select
            labels = [f"{sessions_mod.when(ts)}  ({cnt} msgs)  {(nm + ' · ' if nm else '')}{prev}"
                      for (pp, ts, prev, cnt, nm) in items[:20]]
            si = select("Resume a session", labels)
            if si is not None:
                cli.agent.load_session(items[si][0])
                cli._show_restored_todos()
                cli.agent.compact_resumed_session()
            else:
                cli.agent.session_file = sessions_mod.new_path(config.project_root)
        else:
            cli.agent.session_file = sessions_mod.new_path(config.project_root)
    else:
        cli.agent.session_file = sessions_mod.new_path(config.project_root)

    if args.prompt is not None:
        try:
            code = _run_oneshot(cli, config, args, parser, _oneshot_engine)
            sys.stdout.flush()
        except BrokenPipeError:
            # The reader went away (`dgc -p ... | head -1`). Say nothing more: point stdout at
            # /dev/null so the interpreter's own final flush cannot print a traceback and exit 120.
            _silence_stdout()
            return EXIT_READER_GONE
        return code
    else:
        import atexit

        from . import termbg
        termbg.apply(config)                 # dark canvas on a light terminal, for the whole session
        atexit.register(termbg.reset)
        # atexit does NOT run when SIGTERM or SIGHUP takes the default disposition, and a closed
        # terminal window sends exactly those: without this the user's shell inherits DGC's canvas
        # and keeps it until they reset(1) by hand. Handle the signal, hand the colors back, then
        # finish dying the way an unhandled signal would (see termbg.resend).
        _stop_handlers: dict = {}

        def _restore_terminal_and_die(signum) -> None:
            termbg.reset()
            termbg.resend(signum, _stop_handlers)

        _stop_handlers.update(termbg.install_stop_handler(_restore_terminal_and_die))
        try:
            from .trust import confirm_trust
            if not confirm_trust(config, config.project_root):   # first-run trust gate
                return
            if config.get("artifact_autostart", True):   # bring saved artifact previews back up
                try:
                    from . import artifacts
                    artifacts.autostart_if_pending(
                        int(config.get("artifact_port", 45000)),
                        lan=(str(config.get("artifact_bind", "localhost")).lower() == "lan"),
                        hostname=str(config.get("artifact_hostname", "") or ""))
                except Exception:
                    pass
            if args.classic or not sys.stdout.isatty():
                cli.repl()
            else:
                from .tui import TUI
                return TUI(config, agent=cli.agent).run()   # non-zero when a /update failed
        finally:
            termbg.restore_stop_handlers(_stop_handlers)
            termbg.reset()
            _print_resume_hint(cli.agent, config)   # after the alt-screen is restored — no blank lines


def _run_subscription_oneshot(config, agent, engine_key: str, prompt: str, cont: bool,
                              *, model_override: str | None = None,
                              effort_override: str | None = None) -> int:
    """One-shot turn delegated to the user's own logged-in first-party CLI (their
    subscription). DGC streams the vendor CLI's output; the vendor owns auth, the
    model call, its tools, and its ToS. Returns a process exit code."""
    from . import subscriptions as subs
    ui = agent.ui
    engine = subs.get_engine(engine_key)
    if engine is None:
        ui.error(f"unknown subscription engine {engine_key} — one of: {', '.join(subs.ENGINE_KEYS)}")
        return 1
    if getattr(agent, "_pending_images", None):
        agent._pending_images = None
        ui.error("subscription CLI delegation does not yet support DGC image attachments; "
                 "no vendor process was started")
        return 1
    try:
        subs.preflight(engine)
    except subs.EngineError as e:
        ui.error(str(e))
        return 1
    ui.info(f"running your turn through {engine.label}…")
    configured_engine = str(config.get("subscription_engine", "")).strip().lower()
    model = (str(model_override).strip() if model_override is not None else
             str(config.get("subscription_model", "")).strip()
             if configured_engine == engine.key else "")
    effort = (str(effort_override).strip() if effort_override is not None else
              str(config.get("subscription_effort", "")).strip()
              if configured_engine == engine.key else "")
    # Subscription configuration uses an empty value for the vendor's default effort.  Keep
    # --think off useful without sending a value that first-party CLIs do not accept.
    if effort == "off":
        effort = ""
    if effort and not engine.supports_effort():
        ui.error(f"{engine.short_label} does not expose a reasoning-effort flag; omit --think or "
                 "choose its reasoning model with --model")
        return 1
    try:
        # The run's UI renders the stream exactly as a native `dgc -p` turn does: text as it
        # arrives, tool cards with their edit diffs — inline, or as NDJSON events.
        res = subs.delegate_turn(config, agent, ui, engine, prompt,
                                 model=model, effort=effort, cont=bool(cont))
    except subs.EngineError as e:
        ui.error(str(e))
        return 1
    if res.get("timeout"):
        ui.error("the delegated turn hit the time budget and was stopped")
        return 1
    if res.get("cancelled"):
        ui.error("delegated turn was stopped")
        return 1
    if res.get("error"):
        ui.error(str(res["error"]))
    elif res.get("rc") not in (0, None):
        ui.error(f"{engine.short_label} exited with status {res['rc']}")
    return 0 if res.get("ok") else 1


_MAX_STDIN_BYTES = 2 * 1024 * 1024


def _piped_stdin() -> bool:
    """Whether stdin is something that was piped or redirected in, and can safely be read.

    Only a pipe or a regular file — `git diff | dgc -p …`, `dgc -p - < notes.txt`. A terminal is
    the user, and anything else (most importantly an inherited socket, which is what a supervisor,
    an editor or a background launcher hands down) is NOT input: reading it blocks until a peer
    that will never write decides to close. `dgc -p` hung forever in exactly that shape.
    """
    import stat as stat_mod
    stream = sys.stdin
    if stream is None:
        return False
    try:
        if stream.isatty():
            return False
        mode = os.fstat(stream.fileno()).st_mode
    except (AttributeError, OSError, ValueError):
        return False
    return stat_mod.S_ISFIFO(mode) or stat_mod.S_ISREG(mode)


def _oneshot_prompt(prompt: str) -> str:
    """`-p` reads piped input too: `git diff | dgc -p "review"` appends the diff to the prompt,
    and `-p -` is the input alone. A terminal, /dev/null, or an inherited socket contributes
    nothing."""
    stream = sys.stdin
    data = ""
    if _piped_stdin():
        try:
            data = stream.read(_MAX_STDIN_BYTES + 1)
        except (OSError, ValueError):
            data = ""
    truncated = len(data) > _MAX_STDIN_BYTES
    data = data[:_MAX_STDIN_BYTES].rstrip("\n")
    if not data.strip():
        return "" if prompt == "-" else prompt
    note = "\n[input truncated at 2 MB]" if truncated else ""
    if prompt == "-":
        return data + note
    return f"{prompt}\n\n<input from stdin>\n{data}{note}\n</input>"


def _silence_stdout() -> None:
    try:
        devnull = os.open(os.devnull, os.O_WRONLY)
        os.dup2(devnull, sys.stdout.fileno())
        os.close(devnull)
    except (OSError, ValueError, AttributeError):
        pass


def _last_assistant_text(agent) -> str:
    for message in reversed(getattr(agent, "messages", []) or []):
        if isinstance(message, dict) and message.get("role") == "assistant":
            content = message.get("content")
            if isinstance(content, str) and content.strip():
                return content.strip()
    return ""


def apply_run_flags(config, args, parser) -> None:
    """--add-dir / --allow-tool / --sandbox apply to this run only.

    The rules go to ``config.session_permissions``, which the permission engine merges with the
    saved rules and ``config.save()`` never writes, and the sandbox choice is set without
    persisting. The plumbing already served the editor bridge; the CLI just never wired it.
    """
    from pathlib import Path
    from .permissions import Rule
    allow: list[str] = []
    deny: list[str] = []
    for raw in (getattr(args, "add_dir", None) or []):
        try:
            path = Path(str(raw)).expanduser().resolve(strict=True)
        except (OSError, RuntimeError):
            parser.error(f"--add-dir: {raw} does not exist")
        if not path.is_dir():
            parser.error(f"--add-dir: {raw} is not a directory")
        allow.append(f"ExternalDirectory({path})")
    for raw in (getattr(args, "allow_tool", None) or []):
        try:
            allow.append(Rule.parse(str(raw), "allow").render())
        except ValueError as exc:
            parser.error(f"--allow-tool: {exc}")
    choice = getattr(args, "sandbox", None)
    if choice:
        config.set("sandbox", choice != "off", persist=False)
        config.data["sandbox_read_only"] = choice == "read-only"
        if choice == "read-only":                      # deny wins over every mode and rule
            deny += ["Write", "Edit", "MultiEdit", "ApplyPatch"]
    if allow or deny:
        existing = getattr(config, "session_permissions", None) or {}
        config.session_permissions = {
            "allow": [*(existing.get("allow") or []), *allow],
            "ask": list(existing.get("ask") or []),
            "deny": [*(existing.get("deny") or []), *deny],
        }


def _json_oneshot_ui(config):
    """`-p --output-format json`: the `dgc serve` event stream on stdout, every blocking question
    answered on the spot — a script has nobody to ask — and a closing `result` object."""
    from .headless import HeadlessUI
    from .protocol import Emitter, PendingRequests

    class _OneShotJsonUI(HeadlessUI):
        non_interactive = True
        todo_clear_hint = ""        # a script has no slash line to type `/todo clear` into

        def __init__(self, emitter, pending):
            super().__init__(emitter, pending)
            # stdout carries only events; anything the CLI prints directly goes to stderr
            self.console = Console(file=sys.stderr, highlight=False)
            self.deny_reason = ""

        def approve_live(self, name, args, call_id=None, *, recheck=None):
            rule = str(rule_for(name, args))
            self.em.emit("permission_request", id=None, call_id=call_id, name=name, args=args,
                         command=(args.get("command") if name == "bash" else None),
                         suggested_rule=rule, choices=["once", "always", "deny"],
                         decision="deny", reason="non-interactive run")
            self.deny_reason = (f"non-interactive run: permission was not granted; the user can "
                                f"rerun with --allow-tool \"{rule}\" or --mode acceptEdits|auto")
            return "no"

        def present_plan(self, plan):
            self.em.emit("plan_proposal", id=None, plan=plan,
                         choices=["auto", "acceptEdits", "default", "reject"],
                         decision="reject", reason="non-interactive run")
            self.plan_feedback = ("non-interactive run: the plan cannot be approved here; stop and "
                                  "report it as your final answer")
            return None

        def ask_questions(self, questions, call_id=None):
            # The v14 request, answered on the spot like its permission/plan siblings.
            self.em.emit("options_request", id=None, call_id=call_id if isinstance(call_id, str) else None,
                         questions=list(questions), decision=None, reason="non-interactive run")
            return {"outcome": "unavailable", "answers": {}}

        def mcp_input(self, server, kind, payload, *, cancel=None):
            return {"action": "cancel"}

    return _OneShotJsonUI(Emitter(sys.stdout, sanitizer=lambda event: redact_value(
        event, secret_values(config))), PendingRequests())


def _run_oneshot(cli, config, args, parser, engine_key: str) -> int:
    """`dgc -p`: one turn, then exit with 0 on success — as text, or as NDJSON events."""
    json_mode = args.output_format == "json"
    prompt = _oneshot_prompt(args.prompt)
    if not prompt.strip():
        parser.error("-p - reads the prompt from stdin, which was empty")
    cli.ui.non_interactive = True
    started = time.time()

    def session_id() -> str:
        sf = getattr(cli.agent, "session_file", None)
        return sf.stem if sf else ""
    if json_mode:
        cli.ui.em.emit("turn_start", turn_id="t1", prompt=prompt, session_id=session_id())
    if engine_key:
        ok = _run_subscription_oneshot(
            config, cli.agent, engine_key, cli.expand_mentions(prompt),
            bool(args.cont or args.resume is not None),
            model_override=args.model, effort_override=args.think) == 0
    else:
        if config.data.get("mode") == "auto" and not json_mode:
            print("⚠ auto mode: DGC will run every command and file write with no approval.", file=sys.stderr)
        ok = cli.agent.run_turn(cli.expand_mentions(prompt)) is not False
        cli.ui.end_stream()
        if not json_mode:
            print()
    text = _last_assistant_text(cli.agent)
    if args.output:
        from pathlib import Path
        target = Path(args.output).expanduser()
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text + ("\n" if text and not text.endswith("\n") else ""), encoding="utf-8")
    if json_mode:
        cancelled = bool(getattr(cli.agent, "cancelled", None) and cli.agent.cancelled.is_set())
        cli.ui.em.emit("turn_end", turn_id="t1",
                       reason="completed" if ok else ("cancelled" if cancelled else "error"),
                       token_estimate=int(cli.agent.estimate_tokens() or 0))
        cli.ui.em.emit("result", ok=ok, text=text, session_id=session_id(),
                       elapsed_s=round(time.time() - started, 3),
                       usage=dict(getattr(cli.agent, "usage_totals", {}) or {}),
                       output=str(args.output) if args.output else None)
    elif args.print_session_id and session_id():
        print(f"session: {session_id()}", file=sys.stderr)
    return 0 if ok else 1


def run_export(argv: list[str]) -> int:
    """`dgc export [ID] [FILE]` — save a session as Markdown, the most recent one by default."""
    from rich.console import Console
    c = Console()
    cfg = Config()
    ident = argv[0] if argv and not argv[0].startswith("-") else ""
    target = argv[1] if len(argv) > 1 and not argv[1].startswith("-") else None
    path = sessions_mod.by_id(cfg.project_root, ident) if ident else sessions_mod.latest(cfg.project_root)
    if path is None:
        c.print("  [yellow]no session found[/yellow] "
                + ("for that id" if ident else "in this project — start one with dgc"))
        return 1
    try:
        record = sessions_mod.load_record(path, cfg.project_root)
        out = sessions_mod.export_markdown(
            path, cfg.project_root, record.get("messages", []), target=target,
            name=str(record.get("name") or ""), model=str(cfg.model or ""),
            redact_secrets=secret_values(cfg))
    except (OSError, ValueError) as exc:
        c.print(f"  [red]export failed:[/red] {_markup_literal(terminal_safe_text(str(exc)))}")
        return 1
    print(terminal_safe_text(str(out)))
    return 0


def _print_resume_hint(agent, config) -> None:
    """The single epilogue printed to the normal screen after the full-screen app exits — ONE block
    offering both ways to come back (the quick `--continue` and the exact `--resume <id>`), so there
    aren't two separate 'Resume this session' notices. Only when a real conversation happened, so a
    glance-and-quit leaves nothing behind."""
    sf = getattr(agent, "session_file", None)
    if not sf or len([m for m in getattr(agent, "messages", []) if m.get("role") != "system"]) < 2:
        return
    name = None
    try:
        name = sessions_mod.name_of(sf, config.project_root)
    except Exception:
        pass
    tty = sys.stdout.isatty()
    dim, bold, rst = ("\x1b[2m", "\x1b[1m", "\x1b[0m") if tty else ("", "", "")
    cont = "dgc --continue"
    res = f"dgc --resume {terminal_safe_text(sf.stem)}"
    exp = f"dgc export {terminal_safe_text(sf.stem)}"
    cls = "dgc --classic"
    w = max(len(cont), len(res), len(exp), len(cls)) + 4   # align the descriptions past the longest command
    safe_name = terminal_safe_text(name).replace("\n", " ") if name else ""
    nm = f" {dim}({safe_name}){rst}" if safe_name else ""
    sys.stdout.write(f"\n  Resume this session{nm}:\n")
    sys.stdout.write(f"    {bold}{cont}{rst}{' ' * (w - len(cont))}{dim}the most recent in this folder{rst}\n")
    sys.stdout.write(f"    {bold}{res}{rst}{' ' * (w - len(res))}{dim}this exact session{rst}\n")
    # Nothing the full-screen app showed survives in the terminal's scrollback; these do.
    sys.stdout.write(f"    {bold}{exp}{rst}{' ' * (w - len(exp))}{dim}save it as Markdown{rst}\n")
    sys.stdout.write(f"    {bold}{cls}{rst}{' ' * (w - len(cls))}{dim}inline mode: the transcript stays in your scrollback{rst}\n\n")
    sys.stdout.flush()


if __name__ == "__main__":
    main()
