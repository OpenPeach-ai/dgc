"""Per-project conversation persistence — the familiar `--continue` / `--resume` model.

Every conversation and its durable rewind state are saved (after each turn) to
~/.dgc/sessions/<project-slug>/<timestamp>.json.
`--continue` resumes the most recent session for the current directory; `--resume` lists and picks.
This is transcript resume, NOT semantic/episodic memory — durable facts still live in DGC.md.
"""
from __future__ import annotations

import json
import math
import os
import re
import stat
import threading
import time
import uuid
from datetime import datetime
from pathlib import Path

from .config import USER_HOME
from .scheduler import named_process_lock

SESSIONS_DIR = USER_HOME / "sessions"
SCHEMA_VERSION = 8
METRICS_SCHEMA_VERSION = 3
WORKSPACE_SCHEMA_VERSION = 1
_MAX_WORKSPACE_SIDECAR_BYTES = 64 * 1024
RECALL_SCHEMA_VERSION = 1
_RECALL_SUFFIX = ".recall"
_IMAGES_SUFFIX = ".images"                  # images: <session>.images/, the viewed-image store
_MAX_SAVED_IMAGES = 512
_DEFAULT_RECALL_BYTES = 512 * 1024          # config `recall_max_bytes`
_MIN_RECALL_BYTES, _MAX_RECALL_BYTES = 64 * 1024, 4 * 1024 * 1024
_MAX_RECALL_ROWS = 800
_MAX_RECALL_BODY_CHARS = 4000
_MAX_RECALL_READ_BYTES = _MAX_RECALL_BYTES + 64 * 1024
_RECALL_ROW_KEYS = frozenset({"gen", "cp", "who", "body", "tools"})
USAGE_KEYS = ("input_tokens", "output_tokens", "cached_input_tokens", "reasoning_tokens", "requests")
ACTIVITY_KEYS = ("tool_calls", "edits", "edit_fails")
TIMING_KEYS = ("builtin_tool_us", "builtin_tool_samples")
TIMING_MAP_KEYS = ("by_tool_us", "by_tool_samples", "by_request_reason")
# These are controller states, not user/model-provided tags. Keep this vocabulary in the durable
# metrics layer so both writers and readers can reject arbitrary text in a tampered sidecar.
REQUEST_REASON_LABELS = frozenset({
    "user_turn", "tool_result", "steering", "output_continue", "tool_reissue",
    "todo_gate", "empty_final", "goal_gate", "autonomous_gate", "verifier_evidence", "convergence_nudge",
    "transport_retry", "context_retry", "provider_pause", "fallback", "title", "suggestion",
    "handoff",
    "compaction", "mcp_sampling", "subagent", "unattributed", "other",
    "monitor_event",
})
_MAX_TIMING_NAMES = 64
_MAX_TIMING_VALUE = (1 << 63) - 1
_LOCKS_GUARD = threading.Lock()
_LOCKS: dict[str, "_SessionLock"] = {}
_SESSION_LOCK_TIMEOUT_S = 30.0
_SUBSCRIPTION_ENGINES = frozenset({"claude", "codex", "qwen", "kimi", "copilot"})
_SUBSCRIPTION_MODES = frozenset({"default", "acceptEdits", "plan", "auto"})


def _session_family(path: Path) -> Path:
    """Map transcript sidecars to one lock/CAS family rooted at the `.json` session path."""
    path = Path(path).resolve(strict=False)
    if path.parent.suffix == _IMAGES_SUFFIX and not path.name.endswith(".json"):
        path = path.parent                        # a file inside a session's image store
    if path.suffix == _IMAGES_SUFFIX:
        return path.with_suffix(".json")
    if path.name.endswith(".plan.md"):
        return path.with_name(path.name[:-len(".plan.md")] + ".json")
    if path.suffix in (".metrics", ".workspace", _RECALL_SUFFIX):
        return path.with_suffix(".json")
    return path


class _SessionLock:
    """Re-entrant thread lock backed by a crash-released cross-process lease."""
    def __init__(self, key: str):
        self._local = threading.RLock()
        self._depth = threading.local()
        self._process = named_process_lock("session", key)

    def __enter__(self):
        self._local.acquire()
        depth = int(getattr(self._depth, "value", 0))
        if depth == 0 and not self._process.acquire(timeout=_SESSION_LOCK_TIMEOUT_S):
            self._local.release()
            raise OSError(self._process.last_error or "timed out waiting for the session lease")
        self._depth.value = depth + 1
        return self

    def __exit__(self, _exc_type, _exc, _tb):
        depth = int(getattr(self._depth, "value", 0))
        if depth <= 0:
            raise RuntimeError("release unlocked session lock")
        self._depth.value = depth - 1
        try:
            if depth == 1:
                self._process.release()
        finally:
            self._local.release()


def _lock_for(path: Path) -> _SessionLock:
    key = str(_session_family(path))
    with _LOCKS_GUARD:
        lock = _LOCKS.get(key)
        if lock is None:
            lock = _SessionLock(key)
            _LOCKS[key] = lock
        return lock


def _generation(path: Path, project_root) -> tuple[bool, int]:
    """Return transcript existence/revision while its session-family lock is held."""
    exists = path.is_file()
    revision = _record_revision(_load_data(path, project_root), path) if exists else 0
    return exists, revision


def _expected_generation_matches(exists: bool, revision: int,
                                 expected_revision: int | None,
                                 expected_exists: bool | None) -> bool:
    """Validate an optional compare-and-swap expectation (both fields or neither)."""
    if expected_revision is None and expected_exists is None:
        return True
    return (not isinstance(expected_revision, bool)
            and isinstance(expected_revision, int) and expected_revision >= 0
            and isinstance(expected_exists, bool)
            and exists == expected_exists and revision == expected_revision)


def generation_matches(path, project_root, *, expected_revision: int,
                       expected_exists: bool) -> bool:
    """Check an Agent's session generation under the family lease without mutating it."""
    try:
        session = resolve_path(project_root, path)
        with _lock_for(session):
            exists, revision = _generation(session, project_root)
            return _expected_generation_matches(
                exists, revision, expected_revision, expected_exists)
    except (OSError, TypeError, ValueError):
        return False


def session_turn_lock(path, project_root):
    """Return the crash-released exclusive foreground-turn lease for one session path."""
    session = resolve_path(project_root, path)
    return named_process_lock("session-turn", str(session))


def _atomic_temp_path(path: Path) -> Path:
    return path.with_name(f".{path.name}.tmp")


def _reclaim_stale_temporary(path: Path) -> None:
    """Remove the prior lease holder's exact orphan without scanning the session directory."""
    temporary = _atomic_temp_path(path)
    try:
        info = temporary.lstat()
        if stat.S_ISREG(info.st_mode) or stat.S_ISLNK(info.st_mode):
            temporary.unlink()
    except FileNotFoundError:
        return


def _open_atomic_temporary(path: Path) -> tuple[int, Path]:
    temporary = _atomic_temp_path(path)
    flags = (os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_CLOEXEC", 0)
             | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0))
    return os.open(temporary, flags, 0o600), temporary


def _atomic_write(path: Path, text: str) -> None:
    """Write private session state atomically in the destination directory."""
    # The deterministic temp is safe only under the session-family lease; enforce that invariant
    # here so a future caller cannot accidentally turn O(1) crash recovery into a writer race.
    if int(getattr(_lock_for(path)._depth, "value", 0)) <= 0:
        raise RuntimeError("atomic session writes require the session-family lease")
    path.parent.mkdir(parents=True, exist_ok=True)
    _reclaim_stale_temporary(path)
    fd, tmp = _open_atomic_temporary(path)
    try:
        try:
            os.fchmod(fd, 0o600)
        except OSError:
            pass
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        try:
            Path(tmp).unlink()
        except OSError:
            pass


def _slug(project_root) -> str:
    # This is a storage identity, not an execution-time filesystem grant. Match Agent.session_root
    # so Darwin's /var -> /private/var spelling and an explicitly selected launch-root symlink use
    # one transcript bucket. Session paths themselves remain confined to that private bucket.
    project = Path(project_root).expanduser().resolve(strict=False)
    s = re.sub(r"[^a-zA-Z0-9]+", "-", str(project)).strip("-").lower()
    return (s[-70:] or "root")


def _clean_subscription_sessions(value) -> dict[str, dict[str, str]]:
    """Validate opaque vendor session references without ever opening vendor auth stores."""
    source = value if isinstance(value, dict) else {}
    out: dict[str, dict[str, str]] = {}
    for engine, raw in source.items():
        if engine not in _SUBSCRIPTION_ENGINES or not isinstance(raw, dict):
            continue
        session_id = str(raw.get("id") or "")
        mode = str(raw.get("mode") or "")
        model = str(raw.get("model") or "")
        effort = str(raw.get("effort") or "")
        if (not session_id or len(session_id) > 512 or mode not in _SUBSCRIPTION_MODES
                or len(model) > 256 or len(effort) > 64
                or any(ord(ch) < 32 for ch in session_id + model + effort)):
            continue
        out[engine] = {"id": session_id, "mode": mode, "model": model, "effort": effort}
    return out


def project_dir(project_root) -> Path:
    d = SESSIONS_DIR / _slug(project_root)
    d.mkdir(parents=True, exist_ok=True)
    try:
        d.chmod(0o700)
    except OSError:
        pass
    return d


def new_path(project_root) -> Path:
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    return project_dir(project_root) / f"{stamp}-{uuid.uuid4().hex[:8]}.json"


def resolve_path(project_root, path, *, must_exist: bool = False) -> Path:
    """Resolve a session path inside this project's private session directory."""
    directory = project_dir(project_root).resolve(strict=False)
    p = Path(path).expanduser()
    if not p.is_absolute():
        p = directory / p
    p = p.resolve(strict=False)
    try:
        p.relative_to(directory)
    except ValueError as e:
        raise ValueError(f"session path is outside this project: {p}") from e
    if p.suffix != ".json":
        raise ValueError("session path must name a .json session file")
    if must_exist and not p.is_file():
        raise FileNotFoundError(f"no such session: {p.name}")
    return p


def metrics_path(session_file, project_root) -> Path:
    """Private crash-safe counter journal beside a session transcript.

    The non-JSON suffix deliberately keeps this file out of session pickers and legacy
    ``*.json`` transcript scans.  It can exist before the first full transcript save.
    """
    p = resolve_path(project_root, session_file)
    return p.with_suffix(".metrics")


def _timing_counter(value) -> int:
    try:
        return min(_MAX_TIMING_VALUE, max(0, int(value or 0)))
    except (OverflowError, TypeError, ValueError):
        return 0


def _timing_values(value) -> dict:
    """Normalize bounded monotonic timing counters without retaining arguments or paths."""
    source = value if isinstance(value, dict) else {}
    out = {key: _timing_counter(source.get(key, 0)) for key in TIMING_KEYS}
    for map_key in TIMING_MAP_KEYS:
        raw = source.get(map_key) if isinstance(source.get(map_key), dict) else {}
        cleaned: dict[str, int] = {}
        for name, amount in sorted(raw.items(), key=lambda item: str(item[0])):
            label = str(name)
            if not re.fullmatch(r"[A-Za-z0-9_.-]{1,64}", label):
                continue
            if map_key == "by_request_reason" and label not in REQUEST_REASON_LABELS:
                continue
            if label not in cleaned and len(cleaned) >= _MAX_TIMING_NAMES:
                continue
            cleaned[label] = max(cleaned.get(label, 0), _timing_counter(amount))
        out[map_key] = cleaned
    return out


def _merge_timing(*values) -> dict:
    normalized = [_timing_values(value) for value in values]
    merged = {key: max((item[key] for item in normalized), default=0) for key in TIMING_KEYS}
    for map_key in TIMING_MAP_KEYS:
        names = {name for item in normalized for name in item[map_key]}
        merged[map_key] = {
            name: max(item[map_key].get(name, 0) for item in normalized)
            for name in sorted(names)[:_MAX_TIMING_NAMES]
        }
    return merged


def save_metrics(path: Path, project_root, *, usage: dict | None = None,
                 activity: dict | None = None, timing: dict | None = None,
                 expected_revision: int | None = None,
                 expected_exists: bool | None = None) -> bool:
    """Atomically checkpoint monotonic counters without rewriting the full transcript.

    A benchmark or supervisor may SIGKILL DGC at its wall-clock deadline, bypassing the normal
    ``run_turn`` finalizer.  Updating this small journal after every completed request/tool call
    keeps observable activity auditable in that case.  Merging with the prior file prevents two
    concurrent best-effort writers (for example title generation and the main loop) from moving a
    counter backwards.
    """
    if usage is None and activity is None and timing is None:
        return True
    try:
        session = resolve_path(project_root, path)
        journal = metrics_path(session, project_root)
        with _lock_for(journal):
            exists, revision = _generation(session, project_root)
            if not _expected_generation_matches(
                    exists, revision, expected_revision, expected_exists):
                return False
            old: dict = {}
            try:
                loaded = json.loads(journal.read_text())
                if isinstance(loaded, dict):
                    old = loaded
            except (OSError, ValueError, TypeError, json.JSONDecodeError):
                pass
            old_usage = old.get("usage") if isinstance(old.get("usage"), dict) else {}
            old_activity = old.get("activity") if isinstance(old.get("activity"), dict) else {}
            old_timing = old.get("timing") if isinstance(old.get("timing"), dict) else {}
            current_usage = usage if isinstance(usage, dict) else {}
            current_activity = activity if isinstance(activity, dict) else {}
            data = {
                "schema_version": METRICS_SCHEMA_VERSION,
                "id": session.stem,
                "project": str(Path(project_root).resolve()),
                "updated": time.time(),
                "usage": {
                    key: max(0, int(old_usage.get(key, 0) or 0),
                             int(current_usage.get(key, 0) or 0))
                    for key in USAGE_KEYS
                },
                "activity": {
                    key: max(0, int(old_activity.get(key, 0) or 0),
                             int(current_activity.get(key, 0) or 0))
                    for key in ACTIVITY_KEYS
                },
                "timing": _merge_timing(old_timing, timing),
            }
            _atomic_write(journal, json.dumps(data, default=str))
        return True
    except (OSError, ValueError, TypeError):
        return False  # metrics are best-effort and must never break the agent loop


def _load_metrics(path, project_root) -> dict:
    try:
        journal = metrics_path(path, project_root)
        with _lock_for(journal):
            _reclaim_stale_temporary(journal)
            data = json.loads(journal.read_text())
        if not isinstance(data, dict):
            return {}
        recorded = data.get("project")
        if recorded and Path(recorded).resolve(strict=False) != Path(project_root).resolve(strict=False):
            return {}
        return data
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return {}


def metrics_of(path, project_root) -> dict:
    """Return the raw validated metrics journal, including before a transcript exists."""
    return _load_metrics(path, project_root)


# Mirrors dgc.tools.TODO_STATUSES (sessions imports no tool code): a save that flattened a
# blocked row to pending made a parked item draw reminders again after every resume.
TODO_STATUSES = ("pending", "in_progress", "done", "blocked")


def save(path: Path, messages: list, project_root, name: str | None = None,
         goal: str | None = None, goal_status: str | None = None,
         usage: dict | None = None, activity: dict | None = None,
         timing: dict | None = None,
         checkpoints: dict | None = None, *, goal_elapsed_seconds: float | None = None,
         goal_details: dict | None = None,
         todos: list | None = None,
         subscription_sessions: dict | None = None,
         chat_changes: dict | None = None,
         images: list | None = None,
         agents: dict | None = None,
         goal_active_since: float | None = None, expected_revision: int | None = None,
         expected_exists: bool | None = None,
         redact_secrets: tuple[str, ...] | list[str] | None = None) -> bool:
    saved = False
    try:
        path = resolve_path(project_root, path)
        if redact_secrets is not None:
            from .redaction import redact_checkpoint_state, redact_messages, redact_text, redact_value
            messages = redact_messages(messages, redact_secrets)
            name = redact_text(name, redact_secrets) if name else name
            goal = redact_text(goal, redact_secrets) if goal else goal
            todos = redact_value(todos, redact_secrets) if todos else todos
            if checkpoints is not None:
                checkpoints = redact_checkpoint_state(checkpoints, redact_secrets)
        data = {"schema_version": SCHEMA_VERSION, "id": path.stem,
                "project": str(Path(project_root).resolve()),
                "updated": time.time(), "messages": messages}
        if name:
            data["name"] = name
        if todos:
            # What is done, in progress and still pending. Without this a reopened session shows
            # an empty checklist and a resumed goal has nothing to pick up from.
            data["todos"] = [
                {"content": str(item.get("content", ""))[:500],
                 "status": (str(item.get("status", "pending"))
                            if str(item.get("status", "")) in TODO_STATUSES else "pending")}
                for item in todos[:100]
                if isinstance(item, dict) and str(item.get("content", "")).strip()]
        if goal:
            data["goal"] = goal          # the standing /goal objective, restored on resume
            status = (goal_status if goal_status in ("active", "paused", "completed", "blocked")
                      else "active")
            data["goal_status"] = status
            if goal_details is not None:
                from .goals import clean_details
                from .redaction import redact_value
                data["goal_details"] = clean_details(redact_value(goal_details, redact_secrets or ()))
            try:
                elapsed = float(goal_elapsed_seconds or 0)
            except (TypeError, ValueError, OverflowError):
                elapsed = 0.0
            data["goal_elapsed_seconds"] = elapsed if math.isfinite(elapsed) and elapsed >= 0 else 0.0
            if status == "active":
                try:
                    active_since = float(goal_active_since or 0)
                except (TypeError, ValueError, OverflowError):
                    active_since = 0.0
                if math.isfinite(active_since) and active_since > 0:
                    data["goal_active_since"] = active_since
        if usage:
            data["usage"] = {key: max(0, int(usage.get(key, 0) or 0)) for key in USAGE_KEYS}
        if activity is not None:
            # Unlike the compacted transcript, these counters never shrink. Benchmarking and
            # telemetry can therefore take reliable per-turn deltas after any number of compactions.
            data["activity"] = {
                key: max(0, int(activity.get(key, 0) or 0)) for key in ACTIVITY_KEYS
            }
        if timing is not None:
            data["timing"] = _timing_values(timing)
        if agents is not None:
            from .redaction import redact_value
            data["agents"] = redact_value(agents, redact_secrets or ())
        if checkpoints is not None:
            data["checkpoints"] = checkpoints
        if chat_changes is not None:
            from .redaction import redact_value
            data["chat_changes"] = redact_value(chat_changes, redact_secrets or ())
        clean_subscription_sessions = _clean_subscription_sessions(subscription_sessions)
        if clean_subscription_sessions:
            data["subscription_sessions"] = clean_subscription_sessions
        if images:
            # images: the viewed-image index, metadata only (the bytes live in <session>.images/).
            # A name is display text a page or tool chose, so it is redacted like any other.
            saved_images = []
            for record in list(images)[-_MAX_SAVED_IMAGES:]:
                if not isinstance(record, dict):
                    continue
                record = dict(record)
                if redact_secrets is not None and isinstance(record.get("name"), str):
                    from .redaction import redact_text as _redact_name
                    record["name"] = _redact_name(record["name"], redact_secrets)
                saved_images.append(record)
            if saved_images:
                data["images"] = saved_images
        with _lock_for(path):
            exists, current_revision = _generation(path, project_root)
            matches = _expected_generation_matches(
                exists, current_revision, expected_revision, expected_exists)
            if matches:
                data["revision"] = current_revision + 1
                _atomic_write(path, json.dumps(data, default=str))
                saved = True
            # Keep the transcript and journal in one deletion-serialized family. A stale writer may
            # merge monotonic counters into a newer generation, but must not recreate state after
            # deletion or contaminate a colliding newly-created path.
            stale_current = (expected_exists is True and exists
                             and not isinstance(expected_revision, bool)
                             and isinstance(expected_revision, int) and expected_revision >= 0)
            if saved or stale_current:
                save_metrics(path, project_root, usage=usage, activity=activity, timing=timing)
    except (OSError, TypeError, ValueError):
        pass  # never let a failed save crash the turn
    return saved


def _load_data(path, project_root) -> dict:
    p = resolve_path(project_root, path, must_exist=True)
    with _lock_for(p):
        _reclaim_stale_temporary(p)
        data = json.loads(p.read_text())
    if (not isinstance(data, dict) or not isinstance(data.get("messages", []), list)
            or any(not isinstance(message, dict) for message in data.get("messages", []))):
        raise ValueError(f"invalid session file: {p.name}")
    _record_revision(data, p)
    recorded = data.get("project")
    if recorded and Path(recorded).resolve(strict=False) != Path(project_root).resolve(strict=False):
        raise ValueError("session belongs to a different project")
    return data


def _record_revision(data: dict, path: Path) -> int:
    """Validate a persisted generation; schemas before v6 migrate from revision zero."""
    revision = data.get("revision", 0)
    if isinstance(revision, bool) or not isinstance(revision, int) or revision < 0:
        raise ValueError(f"invalid session revision: {path.name}")
    recorded_id = data.get("id")
    if recorded_id is not None and str(recorded_id) != path.stem:
        raise ValueError(f"session id does not match its filename: {path.name}")
    return revision


def load_record(path, project_root) -> dict:
    """Load one internally consistent transcript/goal/checkpoint generation under its file lock."""
    return _load_data(path, project_root)


def load(path, project_root) -> list:
    return load_record(path, project_root).get("messages", [])


def subscription_sessions_of(record: dict) -> dict[str, dict[str, str]]:
    """Return bounded, structurally valid vendor thread references from a session record."""
    return _clean_subscription_sessions(
        record.get("subscription_sessions") if isinstance(record, dict) else None)


def checkpoints_of(path, project_root) -> dict:
    """Opaque checkpoint payload; CheckpointManager performs all structural/path validation."""
    try:
        value = _load_data(path, project_root).get("checkpoints")
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}


# Plan persistence: the approved/proposed plan lives beside the session so
# it survives the turn (reopen with /view-plan). We keep a `<session>.plan.md` sidecar.
def plan_path(session_file, project_root) -> Path:
    p = resolve_path(project_root, session_file)
    return p.with_name(p.stem + ".plan.md")


def save_plan(session_file, markdown: str, project_root, *,
              expected_revision: int | None = None,
              expected_exists: bool | None = None,
              redact_secrets: tuple[str, ...] | list[str] | None = None) -> bool:
    try:
        session = resolve_path(project_root, session_file)
        p = plan_path(session, project_root)
        if redact_secrets is not None:
            from .redaction import redact_text
            markdown = redact_text(markdown, redact_secrets)
        with _lock_for(p):
            exists, revision = _generation(session, project_root)
            if not _expected_generation_matches(
                    exists, revision, expected_revision, expected_exists):
                return False
            _atomic_write(p, markdown)
        return True
    except (OSError, TypeError, ValueError):
        return False


def load_plan(session_file, project_root) -> str | None:
    try:
        p = plan_path(session_file, project_root)
        with _lock_for(p):
            _reclaim_stale_temporary(p)
            text = p.read_text().strip()
        return text or None
    except OSError:
        return None


def workspace_path(session_file, project_root) -> Path:
    """Owner-private fleet-workspace association beside a conversation transcript.

    The deliberately non-JSON suffix keeps this implementation sidecar out of session pickers.
    It records where a saved TUI conversation was working, but never owns or deletes that checkout.
    """
    p = resolve_path(project_root, session_file)
    return p.with_name(p.stem + ".workspace")


def save_workspace(session_file, project_root, *, kind: str, worktree, branch: str,
                   metadata="", expected_revision: int | None = None,
                   expected_exists: bool | None = None) -> bool:
    """Atomically associate a saved conversation with a managed/manual worktree."""
    if kind not in ("managed", "manual"):
        raise ValueError("workspace kind must be managed or manual")
    values = {
        "worktree": str(Path(worktree).resolve(strict=False)),
        "branch": str(branch)[:256],
        "metadata": (str(Path(metadata).resolve(strict=False)) if metadata else ""),
    }
    payload = {
        "schema_version": WORKSPACE_SCHEMA_VERSION,
        "project": str(Path(project_root).resolve(strict=False)),
        "kind": kind,
        **values,
    }
    encoded = json.dumps(payload, ensure_ascii=True)
    if len(encoded.encode("ascii")) > _MAX_WORKSPACE_SIDECAR_BYTES:
        raise ValueError("workspace association is too large")
    session = resolve_path(project_root, session_file)
    p = workspace_path(session, project_root)
    with _lock_for(p):
        exists, revision = _generation(session, project_root)
        if not _expected_generation_matches(
                exists, revision, expected_revision, expected_exists):
            return False
        _atomic_write(p, encoded)
    return True


def load_workspace(session_file, project_root) -> dict | None:
    """Load a bounded, non-symlink fleet association for this project only."""
    fd = None
    try:
        p = workspace_path(session_file, project_root)
        if p.is_symlink():
            return None
        with _lock_for(p):
            _reclaim_stale_temporary(p)
            flags = (os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_CLOEXEC", 0)
                     | getattr(os, "O_NONBLOCK", 0) | getattr(os, "O_NOFOLLOW", 0))
            fd = os.open(p, flags)
            info = os.fstat(fd)
            if not stat.S_ISREG(info.st_mode) or info.st_size > _MAX_WORKSPACE_SIDECAR_BYTES:
                return None
            chunks, total = [], 0
            while True:
                chunk = os.read(fd, min(65536, _MAX_WORKSPACE_SIDECAR_BYTES + 1 - total))
                if not chunk:
                    break
                chunks.append(chunk)
                total += len(chunk)
                if total > _MAX_WORKSPACE_SIDECAR_BYTES:
                    return None
            value = json.loads(b"".join(chunks).decode("utf-8"))
        if not isinstance(value, dict) or value.get("schema_version") != WORKSPACE_SCHEMA_VERSION:
            return None
        if value.get("kind") not in ("managed", "manual"):
            return None
        if Path(str(value.get("project", ""))).resolve(strict=False) != Path(project_root).resolve(strict=False):
            return None
        worktree = str(value.get("worktree", ""))
        branch = str(value.get("branch", ""))
        metadata = str(value.get("metadata", ""))
        if (not worktree or len(worktree) > 4096 or len(branch) > 256
                or len(metadata) > 4096 or "\x00" in worktree + branch + metadata):
            return None
        return {"kind": value["kind"], "worktree": worktree,
                "branch": branch, "metadata": metadata}
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return None
    finally:
        if fd is not None:
            try:
                os.close(fd)
            except OSError:
                pass


def clear_workspace(session_file, project_root, *, expected_revision: int | None = None,
                    expected_exists: bool | None = None) -> bool:
    try:
        session = resolve_path(project_root, session_file)
        p = workspace_path(session, project_root)
        with _lock_for(p):
            exists, revision = _generation(session, project_root)
            if not _expected_generation_matches(
                    exists, revision, expected_revision, expected_exists):
                return False
            _reclaim_stale_temporary(p)
            p.unlink(missing_ok=True)
        return True
    except (OSError, ValueError):
        return False


def display_rows(messages) -> list[dict]:
    """Project wire messages to display rows — {who, body, tools} — the way the transcript shows them.

    The compaction wrapper and its canned acknowledgement are not turns and are skipped; tool
    results are omitted exactly as the transcript omits them. Shared by the recall archive, the
    Markdown export and the clipboard, so every reader sees one shape.
    """
    from .agent import _COMPACT_ACK, _COMPACT_PREFIX
    rows: list[dict] = []
    skip_ack = False
    for message in messages or ():
        if not isinstance(message, dict):
            continue
        role, content = message.get("role"), message.get("content")
        if isinstance(content, str):
            text = content
        elif isinstance(content, list):
            text = " ".join(part.get("text", "") for part in content
                            if isinstance(part, dict) and part.get("type") == "text")
        else:
            text = ""
        text = text.strip()
        if skip_ack and role == "assistant" and content == _COMPACT_ACK:
            skip_ack = False
            continue
        skip_ack = False
        if role == "user":
            from .editor_context import _strip_editor_context
            from .workflows import display_prompt, notice_kind
            if notice_kind(message):
                continue                # command output DGC delivered; nobody typed it
            text = display_prompt(_strip_editor_context(text))
            if text.startswith(_COMPACT_PREFIX):
                skip_ack = True
                continue
            if text.startswith("<system-reminder>") or text.startswith("<tool_results>"):
                continue
            text = text.replace("<user-interjection>", "").replace("</user-interjection>", "").strip()
            if text:
                rows.append({"who": "user", "body": text, "tools": ""})
        elif role == "assistant":
            names = ", ".join((call.get("function") or {}).get("name", "?")
                              for call in (message.get("tool_calls") or []) if isinstance(call, dict))
            if text or names:
                rows.append({"who": "assistant", "body": text, "tools": names})
    return rows


def export_dir() -> Path:
    return USER_HOME / "exports"


def render_markdown_transcript(rows, *, title: str = "", model: str = "", session_id: str = "",
                               archived: int = 0) -> str:
    """One Markdown document for a conversation: prompts as blockquotes, replies as prose."""
    out = [f"# {title or 'DGC session'}", ""]
    meta = [m for m in (f"session `{session_id}`" if session_id else "",
                        f"model `{model}`" if model else "",
                        f"{archived} earlier turn{'s' if archived != 1 else ''} restored from the archive"
                        if archived else "") if m]
    if meta:
        out += [" · ".join(meta), ""]
    for row in rows:
        body = str(row.get("body") or "").rstrip()
        if row.get("who") == "user":
            out.append("> " + body.replace("\n", "\n> "))
            out.append("")
        else:
            if body:
                out += [body, ""]
            tools = str(row.get("tools") or "")
            if tools:
                out += [f"_used {tools}_", ""]
    return "\n".join(out).rstrip() + "\n"


def export_markdown(session_file, project_root, messages, *, target=None, name: str = "",
                    model: str = "", redact_secrets=None) -> Path:
    """Write a session — archived turns first, then the live transcript — as Markdown.

    Defaults to ~/.dgc/exports/<session>.md so the project tree is never polluted. Redacted with
    the same secrets the session save uses; a caller that has none passes an empty tuple.
    """
    from .redaction import redact_text
    session = resolve_path(project_root, session_file)
    secrets = tuple(redact_secrets or ())
    rows = [{**r, "body": redact_text(r["body"], secrets), "tools": redact_text(r["tools"], secrets)}
            for r in load_recall(session, project_root)]
    archived = len(rows)
    for row in display_rows(messages):
        rows.append({**row, "body": redact_text(row["body"], secrets),
                     "tools": redact_text(row["tools"], secrets)})
    text = render_markdown_transcript(rows, title=name or session.stem, model=model,
                                      session_id=session.stem, archived=archived)
    if target:
        path = Path(str(target)).expanduser()
        if path.is_dir():
            path = path / f"{session.stem}.md"
    else:
        path = export_dir() / f"{session.stem}.md"
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(path.parent, 0o700)
    except OSError:
        pass
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    try:
        os.chmod(tmp, 0o600)
    except OSError:
        pass
    os.replace(tmp, path)
    return path


def recall_path(session_file, project_root) -> Path:
    """Display-only pre-compaction history beside a transcript.

    The non-JSON suffix keeps it out of `*.json` session scans and pickers, exactly as
    metrics_path/workspace_path do. Rows here are a DISPLAY projection: they carry no role,
    no content and no tool-call ids, so nothing can turn one back into a model message.
    """
    return resolve_path(project_root, session_file).with_suffix(_RECALL_SUFFIX)


def _recall_cap(max_bytes=None) -> int:
    try:
        value = int(max_bytes) if max_bytes is not None else _DEFAULT_RECALL_BYTES
    except (TypeError, ValueError):
        value = _DEFAULT_RECALL_BYTES
    return max(_MIN_RECALL_BYTES, min(_MAX_RECALL_BYTES, value))


def _clean_recall_row(row, secrets) -> dict | None:
    """Validate, redact and bound ONE display row; None for anything not row-shaped.

    Applied on write AND on read, so a hand-edited file cannot smuggle a message-shaped dict
    into the transcript, and a secret learned after a row was written is scrubbed on the next
    rewrite — the transcript itself is re-redacted on every save for the same reason.
    """
    if not isinstance(row, dict) or not set(row) <= _RECALL_ROW_KEYS:
        return None
    who = str(row.get("who") or "")
    if who not in ("user", "assistant"):
        return None
    from .redaction import bounded_redacted_view, redact_text
    secrets = tuple(secrets or ())
    body = bounded_redacted_view(redact_text(str(row.get("body") or ""), secrets),
                                 _MAX_RECALL_BODY_CHARS)
    tools = redact_text(str(row.get("tools") or ""), secrets)[:200]
    if not body and not tools:
        return None
    cp = row.get("cp")
    gen = row.get("gen")
    return {"gen": gen if isinstance(gen, int) and not isinstance(gen, bool) and gen >= 0 else 0,
            "cp": cp if isinstance(cp, int) and not isinstance(cp, bool) else -1,
            "who": who, "body": body, "tools": tools}


def _read_recall_lines(p: Path) -> list[str]:
    """Bounded, symlink-refusing read of a recall sidecar. Never raises."""
    fd = None
    try:
        if p.is_symlink():
            return []
        flags = (os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_CLOEXEC", 0)
                 | getattr(os, "O_NONBLOCK", 0) | getattr(os, "O_NOFOLLOW", 0))
        fd = os.open(p, flags)
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_size > _MAX_RECALL_READ_BYTES:
            return []
        chunks, total = [], 0
        while True:
            chunk = os.read(fd, min(65536, _MAX_RECALL_READ_BYTES + 1 - total))
            if not chunk:
                break
            chunks.append(chunk)
            total += len(chunk)
            if total > _MAX_RECALL_READ_BYTES:
                return []
        return b"".join(chunks).decode("utf-8", "replace").splitlines()
    except (OSError, ValueError):
        return []
    finally:
        if fd is not None:
            try:
                os.close(fd)
            except OSError:
                pass


def _recall_header(lines: list[str], p: Path, project_root) -> dict:
    """Parse and bind line 1 to THIS session, so a copied file is inert."""
    if not lines:
        return {}
    try:
        header = json.loads(lines[0])
    except (ValueError, TypeError):
        return {}
    if (not isinstance(header, dict)
            or header.get("schema_version") != RECALL_SCHEMA_VERSION
            or str(header.get("id") or "") != p.stem):
        return {}
    try:
        if Path(str(header.get("project") or "")).resolve(strict=False) != Path(project_root).resolve(strict=False):
            return {}
    except (OSError, ValueError):
        return {}
    return header


def recall_summary(session_file, project_root) -> dict:
    """Row/dropped counts for the transcript marker. Never raises."""
    try:
        p = recall_path(session_file, project_root)
        with _lock_for(p):
            header = _recall_header(_read_recall_lines(p), p, project_root)
    except (OSError, ValueError):
        return {}
    if not header:
        return {}
    return {"rows": int(header.get("rows") or 0), "dropped": int(header.get("dropped") or 0),
            "generations": int(header.get("generations") or 0)}


def load_recall(session_file, project_root) -> list:
    """Every retained display row, re-redacted. Never raises; [] on any problem."""
    try:
        p = recall_path(session_file, project_root)
        with _lock_for(p):
            lines = _read_recall_lines(p)
            if not _recall_header(lines, p, project_root):
                return []
        secrets = ()          # re-redaction on display is the reader's job (it knows the config)
        rows = []
        for line in lines[1:]:
            if not line.strip():
                continue
            try:
                candidate = json.loads(line)
            except (ValueError, TypeError):
                continue                       # a torn tail loses one row, never the file
            cleaned = _clean_recall_row(candidate, secrets)
            if cleaned is not None:
                rows.append(cleaned)
            if len(rows) >= _MAX_RECALL_ROWS:
                break
        return rows
    except (OSError, ValueError, TypeError):
        return []


def save_recall(session_file, project_root, rows, *, checkpoint_index: int = -1,
                expected_revision: int | None = None, expected_exists: bool | None = None,
                redact_secrets=None, max_bytes=None) -> dict:
    """Append display rows to the recall sidecar, pruning oldest-first within the cap.

    Rewrites the whole file rather than appending, which re-redacts every retained row against
    the secrets known NOW — an append-only file would be strictly weaker than the transcript,
    which sessions.save() re-scrubs on every write.
    """
    failed = {"saved": False, "rows": 0, "dropped": 0, "generation": 0}
    try:
        session = resolve_path(project_root, session_file)
        p = recall_path(session, project_root)
        cap = _recall_cap(max_bytes)
        secrets = tuple(redact_secrets or ())
        with _lock_for(p):
            exists, revision = _generation(session, project_root)
            if not _expected_generation_matches(exists, revision, expected_revision, expected_exists):
                return failed
            lines = _read_recall_lines(p)
            header = _recall_header(lines, p, project_root)
            retained = []
            for line in lines[1:] if header else []:
                try:
                    cleaned = _clean_recall_row(json.loads(line), secrets)
                except (ValueError, TypeError):
                    continue
                if cleaned is not None:
                    retained.append(cleaned)
            generation = int(header.get("generations") or 0) + 1
            dropped = int(header.get("dropped") or 0)
            try:
                point = int(checkpoint_index)
            except (TypeError, ValueError):
                point = -1
            fresh = []
            for row in rows or ():
                if not isinstance(row, dict):
                    continue
                cleaned = _clean_recall_row(
                    {"gen": generation, "cp": point, "who": row.get("who"),
                     "body": row.get("body"), "tools": row.get("tools")}, secrets)
                if cleaned is not None:
                    fresh.append(cleaned)
            if not fresh:
                return {"saved": True, "rows": len(retained), "dropped": dropped,
                        "generation": generation - 1}
            keep = retained + fresh
            encoded = [json.dumps(row, ensure_ascii=True, default=str) for row in keep]
            def _fits() -> bool:
                return (len(keep) <= _MAX_RECALL_ROWS
                        and sum(len(line) + 1 for line in encoded) + 512 <= cap)
            while keep and not _fits():
                keep.pop(0); encoded.pop(0); dropped += 1
            head = json.dumps({"schema_version": RECALL_SCHEMA_VERSION, "id": p.stem,
                               "project": str(Path(project_root).resolve(strict=False)),
                               "updated": time.time(), "rows": len(keep),
                               "dropped": dropped, "generations": generation},
                              ensure_ascii=True, default=str)
            _atomic_write(p, "\n".join([head, *encoded]) + "\n")
        return {"saved": True, "rows": len(keep), "dropped": dropped, "generation": generation}
    except (OSError, TypeError, ValueError):
        return failed


def truncate_recall(session_file, project_root, *, keep_before_cp: int,
                    expected_revision: int | None = None,
                    expected_exists: bool | None = None) -> bool:
    """Drop rows a rewind is about to restore into the live transcript.

    A row written during checkpoint C's turn describes messages present at C. Rewinding to
    `idx <= C` restores those messages, so keeping the row would render them twice.
    """
    try:
        session = resolve_path(project_root, session_file)
        p = recall_path(session, project_root)
        with _lock_for(p):
            exists, revision = _generation(session, project_root)
            if not _expected_generation_matches(exists, revision, expected_revision, expected_exists):
                return False
            lines = _read_recall_lines(p)
            header = _recall_header(lines, p, project_root)
            if not header:
                return False
            keep = []
            for line in lines[1:]:
                try:
                    row = _clean_recall_row(json.loads(line), ())
                except (ValueError, TypeError):
                    continue
                if row is not None and row["cp"] < int(keep_before_cp):
                    keep.append(row)
            encoded = [json.dumps(row, ensure_ascii=True, default=str) for row in keep]
            head = json.dumps({**header, "rows": len(keep), "updated": time.time()},
                              ensure_ascii=True, default=str)
            _atomic_write(p, "\n".join([head, *encoded]) + "\n")
        return True
    except (OSError, TypeError, ValueError):
        return False


def delete(path, project_root, *, expected_revision: int | None = None,
           expected_exists: bool | None = None) -> bool:
    turn_lease = None
    turn_acquired = False
    try:
        p = resolve_path(project_root, path, must_exist=True)
        turn_lease = session_turn_lock(p, project_root)
        turn_acquired = turn_lease.acquire(blocking=False)
        if not turn_acquired:
            return False
        with _lock_for(p):
            exists, revision = _generation(p, project_root)
            if not _expected_generation_matches(
                    exists, revision, expected_revision, expected_exists):
                return False
            sidecars = (plan_path(p, project_root), metrics_path(p, project_root),
                        workspace_path(p, project_root), recall_path(p, project_root))
            for member in (p, *sidecars):
                _reclaim_stale_temporary(member)
            p.unlink()
            for sidecar in sidecars:
                try:
                    sidecar.unlink()
                except OSError:
                    pass
            from .image_views import remove_store
            remove_store(p)                       # images: the session's viewed-image store
        return True
    except (OSError, ValueError):
        return False
    finally:
        if turn_lease is not None and turn_acquired:
            turn_lease.release()


def goal_of(path, project_root) -> str:
    try:
        return _load_data(path, project_root).get("goal") or ""
    except (OSError, ValueError):
        return ""


def goal_status_of(path, project_root) -> str:
    """Persisted lifecycle for a standing goal; schema <=3 goals migrate as active."""
    try:
        data = _load_data(path, project_root)
        if not data.get("goal"):
            return "none"
        status = str(data.get("goal_status") or "active")
        return status if status in ("active", "paused", "completed", "blocked") else "active"
    except (OSError, ValueError):
        return "none"


def name_of(path, project_root) -> str | None:
    try:
        return _load_data(path, project_root).get("name") or None
    except (OSError, ValueError):
        return None


def usage_of(path, project_root, record: dict | None = None) -> dict:
    try:
        usage = (record if isinstance(record, dict) else _load_data(path, project_root)).get("usage") or {}
    except (OSError, ValueError, TypeError):
        usage = {}
    journal = _load_metrics(path, project_root).get("usage") or {}
    try:
        return {key: max(0, int(usage.get(key, 0) or 0), int(journal.get(key, 0) or 0))
                for key in USAGE_KEYS}
    except (ValueError, TypeError):
        return {key: 0 for key in USAGE_KEYS}


def activity_of(path, project_root, record: dict | None = None) -> dict:
    """Return monotonic tool/edit counters, defaulting safely for schema <=4 sessions."""
    try:
        activity = (record if isinstance(record, dict)
                    else _load_data(path, project_root)).get("activity") or {}
    except (OSError, ValueError, TypeError):
        activity = {}
    journal = _load_metrics(path, project_root).get("activity") or {}
    try:
        return {key: max(0, int(activity.get(key, 0) or 0), int(journal.get(key, 0) or 0))
                for key in ACTIVITY_KEYS}
    except (ValueError, TypeError):
        return {key: 0 for key in ACTIVITY_KEYS}


def timing_of(path, project_root, record: dict | None = None) -> dict:
    """Return monotonic argument-free tool timings and provider-request reasons.

    Sessions written before metrics schema v3 have request totals but no reason map. Attribute only
    that historical gap to the fixed ``unattributed`` bucket so a resumed session's reason counters
    remain additive and exactly reconcilable with its completed-request total.
    """
    try:
        timing = (record if isinstance(record, dict)
                  else _load_data(path, project_root)).get("timing") or {}
    except (OSError, ValueError, TypeError):
        timing = {}
    journal = _load_metrics(path, project_root).get("timing") or {}
    try:
        merged = _merge_timing(timing, journal)
        requests = usage_of(path, project_root, record).get("requests", 0)
        explained = sum(merged["by_request_reason"].values())
        if explained > requests:
            # Divergent stale writers or manual sidecar corruption can produce individually
            # monotonic buckets whose union is impossible. Preserve the truthful request total and
            # discard the unprovable breakdown instead of publishing a fabricated overcount.
            merged["by_request_reason"] = ({"unattributed": requests} if requests else {})
        elif requests > explained:
            merged["by_request_reason"]["unattributed"] = min(
                _MAX_TIMING_VALUE,
                merged["by_request_reason"].get("unattributed", 0) + requests - explained)
        return merged
    except (ValueError, TypeError):
        return _timing_values({})


def set_name(path, name: str, project_root, *, expected_revision: int | None = None,
             expected_exists: bool | None = None,
             redact_secrets: tuple[str, ...] | list[str] | None = None) -> bool:
    try:
        p = resolve_path(project_root, path, must_exist=True)
        if redact_secrets is not None:
            from .redaction import redact_text
            name = redact_text(name, redact_secrets)
        with _lock_for(p):
            data = _load_data(p, project_root)  # the lock is re-entrant; retain it through replace
            revision = _record_revision(data, p)
            if not _expected_generation_matches(
                    True, revision, expected_revision, expected_exists):
                return False
            data["name"] = name
            data["revision"] = revision + 1
            data["updated"] = time.time()
            _atomic_write(p, json.dumps(data, default=str))
        return True
    except (OSError, TypeError, ValueError):
        return False


def listing(project_root, *, redact_secrets=()) -> list[tuple[Path, float, str, int, str]]:
    """(path, updated_ts, first-user-message preview, message count, name), newest first."""
    from .redaction import redact_text
    items: list[tuple[Path, float, str, int, str]] = []
    for p in project_dir(project_root).glob("*.json"):
        try:
            data = json.loads(p.read_text())
            msgs = data.get("messages", [])
            first = next((m.get("content", "") for m in msgs if m.get("role") == "user"), "")
            preview = re.sub(
                r"\s+", " ", redact_text(str(first), redact_secrets)).strip()[:56] or "(empty)"
            name = redact_text(str(data.get("name") or ""), redact_secrets)
            items.append((p, float(data.get("updated", p.stat().st_mtime)), preview,
                          len(msgs), name))
        except (OSError, ValueError):
            continue
    items.sort(key=lambda t: -t[1])
    return items


def listing_all(*, redact_secrets=()) -> list[tuple[Path, Path, float, str, int, str]]:
    """Private global index used by protocol adapters: path, project, time, preview, count, name."""
    from .redaction import redact_text
    items: list[tuple[Path, Path, float, str, int, str]] = []
    base = SESSIONS_DIR.resolve(strict=False)
    for candidate in SESSIONS_DIR.glob("*/*.json"):
        try:
            p = candidate.resolve(strict=True)
            p.relative_to(base)  # reject a symlink planted in the session store
            data = json.loads(p.read_text())
            project_value = data.get("project")
            if not project_value:
                continue
            project = Path(project_value).resolve(strict=False)
            if p.parent != (base / _slug(project)).resolve(strict=False):
                continue
            msgs = data.get("messages", [])
            if not isinstance(msgs, list):
                continue
            first = next((m.get("content", "") for m in msgs if m.get("role") == "user"), "")
            preview = re.sub(
                r"\s+", " ", redact_text(str(first), redact_secrets)).strip()[:56] or "(empty)"
            name = redact_text(str(data.get("name") or ""), redact_secrets)
            items.append((p, project, float(data.get("updated", p.stat().st_mtime)), preview,
                          len(msgs), name))
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            continue
    items.sort(key=lambda item: -item[2])
    return items


def find_global(sid: str) -> tuple[Path, Path] | None:
    sid = str(sid).strip().removesuffix(".json")
    if not re.fullmatch(r"[A-Za-z0-9_-]+", sid):
        return None
    matches = [(p, project) for p, project, *_ in listing_all()
               if p.stem == sid or p.stem.startswith(sid)]
    return matches[0] if len(matches) == 1 else None


def latest(project_root) -> Path | None:
    items = listing(project_root)
    return items[0][0] if items else None


def by_id(project_root, sid: str) -> Path | None:
    """Resolve a session id (the file stem, e.g. 20260819-153045, or a unique prefix) to its
    path in this project — for `dgc --resume <id>`. Returns None if nothing matches."""
    sid = str(sid).strip().removesuffix(".json")
    if not re.fullmatch(r"[A-Za-z0-9_-]+", sid):
        return None
    d = project_dir(project_root)
    exact = d / f"{sid}.json"
    if exact.exists():
        return exact
    matches = sorted(d.glob(f"{sid}*.json"))          # allow a short prefix
    return matches[-1] if matches else None


def when(ts: float) -> str:
    return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M")
