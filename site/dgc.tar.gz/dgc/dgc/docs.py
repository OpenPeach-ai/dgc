"""In-app documentation for `/docs` — a small library of how-to pages rendered
right in the TUI. Single source of truth: the DOCS list (title, description,
markdown). Kept concise and accurate to DGC's actual features."""
from __future__ import annotations

import re

from .commands import command_specs


def _slash_command_doc() -> str:
    """Build the TUI reference from the same registry that drives its live palette."""
    lines = [
        "# Slash commands",
        "",
        "Type **/** after a space anywhere in the composer to open the live command palette; filter as you",
        "type, ↑/↓ to select, Enter to run. This is the complete discoverable full-screen TUI surface;",
        "classic and editor clients advertise only the commands they can execute.",
        "",
    ]
    for spec in command_specs("tui"):
        aliases = (" Aliases: " + ", ".join(f"`/{alias}`" for alias in spec.aliases) + "."
                   if spec.aliases else "")
        lines.append(f"- **/{spec.usage or spec.name}** — {spec.description}.{aliases}")
    lines.extend([
        "",
        "## Project commands",
        "",
        "Add a custom prompt command at `.dgc/commands/<name>.md` (or",
        "`~/.dgc/commands/<name>.md`). Use `$ARGUMENTS` or `{{args}}` in the template, then",
        "run `/name optional arguments`. Project commands override personal commands and",
        "appear in the classic/TUI/editor/ACP catalogs automatically. Names begin with a",
        "lowercase letter or digit, then use lowercase letters, digits, `.`, `_`, or `-`",
        "(1–64 characters). Built-in names and aliases are reserved. DGC bounds the catalog",
        "and each template, and rejects symlinked command directories or files.",
    ])
    return "\n".join(lines)


# Each entry: (title, one-line description, markdown body).
DOCS: list[tuple[str, str, str]] = [
    ("Getting started", "install, first launch, connect a model", """
# Getting started

DGC is a local-first coding agent for your terminal. It talks to **supported
native and compatible endpoints** — Ollama, Anthropic Messages, OpenAI Responses,
LM Studio, llama.cpp, vLLM, and cloud providers. The selected model receives the
conversation context it needs; optional remote integrations receive the requests
or tool arguments you direct to them. A configured language server receives workspace
metadata and the full text of documents queried through code intelligence.

## Install

Requires **Python 3.10+**. The installer creates its own virtualenv under
`~/dgc` and links the launcher into `~/.local/bin`, so it never touches your
system Python:

```
curl -fsSL https://vibedgc.com/install.sh | bash
```

Then confirm it is on your PATH:

```
dgc --version
```

If that reports `command not found`, add the bin directory to your PATH:

```
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc && source ~/.bashrc
```

Two environment variables let you override where things land: `DGC_DIR` (the
install directory, default `~/dgc`) and `DGC_BIN` (the launcher directory,
default `~/.local/bin`).

If `cursor`, `code`, or `codium` is already on `PATH`, the installer also verifies
and installs the self-hosted editor extension into the first one it finds. Set
`DGC_SKIP_EXTENSION=1` before the install command to leave editor-managed state
untouched and install an extension later from the editor page.

## First launch

```
dgc
```

On the very first run DGC asks you to pick a provider and a model. You can
change either at any time:

- `/connect` — pick a provider (Ollama, LM Studio, OpenAI, OpenRouter, …) or a
  custom LAN host.
- `/model` — switch the model on the current host.

## Talking to the agent

Type a request and press **Enter**. DGC plans, reads files, runs tools, edits
code, and streams its thinking and its answer back live. Press **Esc** to stop
the current turn; press **Enter** again on a new prompt to queue it.
""".strip()),

    ("Keyboard shortcuts", "essential key bindings in the composer + transcript", """
# Keyboard shortcuts

Press **Ctrl+G** any time for this cheatsheet as an overlay.

## Compose
- **Enter** — send · **Shift+Enter** — newline
- **Shift+Tab** — cycle permission mode (default → acceptEdits → plan → auto)
- **/** — command palette · **@path** — attach one exact bounded file (`@"path with spaces"`)
- **! command** — run a bounded direct shell command · **# note** — atomically save project memory
- **/memory add TEXT** — save project memory · **/memory add user TEXT** — save personal memory
- **Ctrl+R** — recall a past prompt · **Tab / →** — accept the ghost suggestion
- **Ctrl+Y** — copy the last reply to your clipboard (works mid-turn) · **/copy code** — its code block

## This turn
- **Esc** — stop the turn · **Ctrl+C** — cancel · clear draft · quit
- **Enter** — steer native work at the next model/tool boundary; subscription follow-ups queue
- **Tab** — queue a separate turn while working, outside menus and completion
- **/skills** and **/skills show NAME** — browse the current catalog without stopping work
- **/mode MODE** — change native permission decisions during work; explicit ask/deny rules remain

Unconsumed terminal follow-ups remain queued after interruption; a new prompt continues the queue.
In the editor, Enter steers and **Alt+Enter** or **Queue** submits a later turn. Unapplied steering
can be restored to the draft. Subscription CLI mode changes apply to the next launched turn.

## Files pane (`/files`)
- **j / k · ↑ ↓** move · **h / l · ← →** parent / enter · **gg / G** top / bottom · **H / L** back / forward
- **Space** select · **v** visual select · **Ctrl+A** all · **Esc** clear selection, filter, or help
- **y / x / p** copy / cut / paste · **P** paste overwriting · **a** new (end with `/` for a folder) · **r** rename
- **d** trash · **D** delete permanently · **u** undo the last change
- **f** filter · **/** find, **n / N** next / previous · **.** hidden files · **s / S** sort / reverse
- **Enter** insert `@path` into the prompt · **c** insert the plain path · **i / Tab** inspect · **J / K** scroll the preview
- **?** all keys · **q** return to DGC · **Ctrl+C** still stops the agent

## Navigate
- **PageUp / PageDn** — scroll the transcript · **End** — jump to the latest
- click **◆ Thought** — expand the reasoning · click the token count — context details

## Copy text
DGC owns its screen, so it can copy without you selecting anything, from any position, even
while a turn is still running. The text goes to your system clipboard through the terminal
(OSC 52), which works over SSH and inside tmux with `set-clipboard on`.

- **Ctrl+Y** or **/copy** — the last reply · **/copy code** — its last fenced code block
- **/copy 2** — the reply before that · **/copy all** — the whole conversation as Markdown
- **/export** — save the conversation as Markdown (`~/.dgc/exports/`, or `/export PATH`)

If you would rather drag-select with the mouse: DGC captures the mouse so the wheel scrolls its
own transcript and rows stay clickable, and that capture is what stops your terminal's own
selection. **/select** hands the mouse back for this session (PageUp/PageDn still scroll), and
A paste of five lines or more (or a very long one) collapses in the composer to a chip such as
`[Pasted text #1 +40 lines]`, so a tall paste no longer fills the screen; it expands back to the
full text the moment you send. Short pastes insert as typed.

**/mouse off** remembers that choice. **Shift+drag** (**Option+drag** on some terminals) selects
without leaving scroll mode at all, where the terminal passes the modifier through.

## Session
- **Ctrl+N** — new session · **/resume** — reopen a past one · **/name** — rename
""".strip()),

    ("Slash commands", "the full / command reference", _slash_command_doc()),

    ("Command line", "flags, subcommands, and one-shot runs", """
# Command line

`dgc help` prints a short version of this page in the terminal.

## Starting a session

- `dgc` — the full-screen app, rooted at the current directory.
- `dgc --classic` — the classic inline REPL instead of the full-screen app.
- `dgc -p "fix the failing test"` — run one prompt non-interactively and exit.
  Add `--mode auto` for a hands-off run.
- `dgc -c` (`--continue`) — resume the most recent session in this directory.
- `dgc --resume <id>` — resume a past session by id; `dgc --resume` with no id
  opens a picker.

## Per-session flags

- `--mode MODE` — permission mode for this session: `default`, `acceptEdits`,
  `plan`, or `auto`. See **Permission modes**.
- `--think LEVEL` — thinking level for this session: `off`, `low`, `medium`,
  `high`, or `xhigh`. With `dgc -p --engine`, it applies only to that delegated
  turn and does not change the native fallback. See **Thinking & reasoning**.
- `--output-format json` — with `-p`: instead of text, the NDJSON event stream that
  `dgc serve` speaks (`turn_start`, `text_delta`, `tool_call`, `tool_result`, `turn_end`…),
  ending in one `result` object with `ok`, `text`, `session_id` and `usage`.
- `--output FILE` — with `-p`: also write the final answer to FILE.
- `--print-session-id` — with `-p`: print the session id on stderr, for `--resume ID`.
- Piped input: `git diff | dgc -p "review this"` appends stdin to the prompt (2 MB cap);
  `dgc -p -` reads the whole prompt from stdin. Only a pipe or a redirected file is read — a
  terminal, `/dev/null`, and an fd inherited from a launcher (a supervisor, an editor) are left
  alone, so `-p` never waits on input nobody is going to send. A `-p` run never waits on a menu: a tool
  that would ask is denied with the rule to pre-approve, a plan is reported, not executed.
- `--add-dir PATH` — let this run read and edit files under PATH too (repeatable).
- `--allow-tool RULE` — pre-approve a tool for this run, e.g. `"Bash(npm test)"` or `Edit`
  (repeatable; never saved).
- `--sandbox on|off|read-only` — confine shell commands for this run; `read-only` mounts
  the project read-only inside the sandbox and denies every file edit, for review runs.
- `--trust` — persist the canonical workspace in `trusted_dirs` (covering its
  subdirectories) before a non-interactive `acceptEdits`/`auto` run. Without it,
  an unattended run in an untrusted directory will not edit. `dgc trust` lists
  every grant and `dgc trust revoke N|PATH|here` (or `/trust` inside DGC) forgets
  one; the gate then asks again on the next launch there. The gate warns when the
  folder is your home directory or the filesystem root, because a grant covers
  everything under it — including every future clone.
- `--engine NAME` — with `dgc -p`, delegate that one-shot turn to a subscription
  CLI instead of the configured endpoint. See **Subscriptions**.

## Model and endpoint

The model and base URL persist to `config.json`, so you only pass them once. The
API-key environment reference is process-only:

- `--model NAME` — the model to use. It persists for native runs; with
  `dgc -p --engine`, it is a one-turn vendor override and leaves the native model unchanged.
- `--base-url URL` — an OpenAI-compatible endpoint.
- `--api-key-env NAME` — read the endpoint key from environment variable `NAME`
  **without persisting it**. Prefer this to pasting a key anywhere.

## Native-route unattended runs

- `--autonomous-gate "CMD"` — on a native local/API route, a check command that must exit `0` before the
  agent is allowed to stop a turn. A failing check is fed back and the agent
  keeps going. Delegated subscription turns do not execute this gate.
- `--autonomous-max-turns N` — bound on failed gate retries before the turn
  stops anyway (default `30`).

## Subcommands

- `dgc setup` — configure provider / model / context.
- `dgc doctor` — check that the endpoint and model are reachable.
- `dgc update` — update DGC to the latest version.
- `dgc export-training` — export sessions as scrubbed fine-tuning JSONL.
- `dgc protocol describe` — print the installed headless/editor contract as JSON.
- `dgc serve` — the headless JSON backend the VS Code extension drives. Stdout is
  protocol-only.
- `dgc acp` — the agent-client-protocol surface.
- `dgc bug` — print the issue tracker URL.
- `dgc help`, `dgc --version`.

## dgc export-training

- `--out PATH` — output path (default `./dgc-training.jsonl`).
- `--all` — every project, not just the current one.
- `--session ID` — a single session; a unique id prefix is accepted.
- `--successful-only` — apply DGC's outcome heuristic: keep a session when an edit
  landed with no edit-tool failure, or its goal was marked complete. This is a
  curation aid, not proof that tests passed or the result is correct.
- `--min-turns N` — drop sessions with fewer than N user turns (default `1`).

Secrets are scrubbed on the way out. See **Training export**.
"""),

    ("Permission modes", "native default · acceptEdits · plan · auto", """
# Native local/API permission modes

DGC gates what the agent can do without asking. Cycle modes with **Shift+Tab**
or set one with `/mode`.

- **default** — reads run freely; model-requested file writes and shell commands ask by baseline.
- **acceptEdits** — file edits auto-apply by baseline; shell commands ask by baseline.
- **plan** — prevents model-requested project mutations while the agent investigates
  and proposes a plan for approval. See the *Plan mode* page.
- **auto** — model-requested tool actions are approved. Some integration consent
  prompts remain user-gated. Use only in a sandbox or a throwaway repo.

Explicit `/permissions` rules are evaluated deny → ask → allow before those baseline decisions.
Subscription turns map the mode into the selected vendor CLI's own flags and policy instead.
`/sandbox on` uses the strongest supported host boundary for native-loop spawned shell commands
and hooks; it does not confine parent-process structured file tools or delegated vendor CLIs, and
does **not** skip normal permission prompts. Linux/bubblewrap makes the project the only persistent
writable host path for those commands, masks ambient user state, and provides private home, temporary,
runtime, process, and network namespaces. macOS/sandbox-exec denies ambient-home
reads outside the project and host writes except the project and shared system
temporary paths; its temporary and process namespaces are not private. Network is
blocked by default on both. Unsupported platforms fail closed instead of running a
requested sandbox without confinement. Use `/sandbox network on` only when needed.

## In VS Code and Cursor

The approval card shows what the step will do — its summary and, for an edit, the diff it
would apply — so you approve against the change rather than raw arguments. **Deny** can carry
a note; the model reads it as the reason and adjusts.

""".strip()),

    ("Plan mode", "read-only planning, then one-tap approve", """
# Plan mode

The DGC workflow below applies to native local/API routes. Switch to **plan** mode
(`/mode plan` or Shift+Tab) and the native agent goes read-only: it explores the
code, reasons about an approach, and presents a concrete plan — files it will
touch, the steps, the risks — without model-requested project mutations.

A delegated subscription turn instead maps `plan` to the vendor CLI's supported
planning/read-only flag. That CLI owns its behavior; DGC does not inject
`present_plan`, create the approval dialog, or save a native `plan.md` from it.

When the plan lands you get an approval prompt:

- **Approve** — DGC drops back to your previous edit mode and executes the plan.
- **Keep planning** — give feedback, stay read-only, and receive a revised plan.

## What read-only means

Plan mode is enforced in the permission layer, not by instruction. While it is
active the agent may use only the read-only tools — reading files, `grep`,
`glob`, code intelligence, web search — plus the one tool that presents a plan.
Every model-requested mutation tool is denied outright: no file writes, no edits,
no shell commands.
Two further limits apply only in this mode: paths outside the project are
refused, and MCP discovery and execution are not exposed at all.

Plan mode therefore prevents model-requested project mutations before you have read
what the agent intends to do. Configured lifecycle hooks still run at their normal
events, DGC still writes private session and plan state, and the selected model or
remote integrations may receive inspected content, so review those settings before
opening unfamiliar or sensitive code.

DGC keeps the plan inline in the transcript, saves a `plan.md` beside the session,
and (by default) renders a self-contained preview on loopback. `/view-plan` reopens
the saved copy. The preview never inherits LAN sharing; arbitrary project previews
remain disabled in plan mode unless `artifact_in_plan` is explicitly enabled.

## Workflow commands

`/plan` enters read-only mode without starting a turn. `/plan TASK` inspects the
project and prepares a plan. It does not toggle back into execution; use `/mode`
or the mode selector when you want to change permissions.

`/review` enters read-only mode and reviews staged, working, and untracked changes
for concrete bugs. Use `/review --staged`, `/review --working`, `/review --base main`,
or `/review --commit HEAD~1` to choose the comparison, followed by optional focus
text. Native review uses the bounded `git_diff` tool without executing repository
filters or network transports. Partial coverage is explicit. Findings should name
the file/line, trigger, and impact; a source review must not claim tests were run.

`/init` inspects existing guidance and prepares or updates DGC.md using ordinary
edit permissions. In plan mode it proposes the guide before any write. It never
precreates a placeholder or bypasses approval to overwrite existing instructions.

These commands work in the interactive CLI, TUI, and editor. Selecting them after
other text prepares the draft until Send; skills and context stay attached. Pause
an active goal before starting a separate workflow. Unsupported subscription modes
and invalid selections are rejected before starting a model request.
""".strip()),

    ("Artifacts", "preview what the agent builds on a localhost URL", """
# Artifacts

An artifact is how the agent **proposes something visual** on a local URL — most
often a **plan**. In plan mode, DGC renders the plan (`plan.md`) as a clean page
and serves it, as a rendered page — so you read the steps,
files and approach in your browser instead of raw markdown scrolling past. The
agent can also serve any page/app/chart it builds the same way.

- **Project previews share one server and port** (`http://127.0.0.1:45000` by
  default), with a top-left dropdown. Proposed plans use a separate transient
  loopback server so a LAN setting can never expose them.
- DGC prints the URL in the terminal; open it in your browser.
- Run **/artifact** to see them, open one, **stop** one, or toggle **localhost ⇄
  LAN** with `b`.
- **Localhost or your LAN.** By default the server binds `127.0.0.1` (only this
  machine). Switch it to your **local network** (`artifact_bind: lan`, or press
  `b` in `/artifact`) and it binds `0.0.0.0` with a shareable LAN URL —
  open your artifact on your phone or another device. (LAN means anyone on the
  network can view it — there's no auth.)
- **It persists.** The list is saved, so after you restart `dgc` the server
  tries to reuse the same port with your artifacts intact (set the preferred port with
  `artifact_port`, turn off relaunch with `artifact_autostart`).

Artifacts are built with DGC's own design language (the `dgc-design` skill) so
the frontend looks polished by default. They stay on this machine unless you
explicitly confirm LAN sharing; plan previews always stay private.
""".strip()),

    ("MCP servers", "connect external tools over MCP", """
# MCP servers

DGC speaks the **Model Context Protocol**: connect a stdio MCP server and its
tools become callable by the agent as `mcp__<server>__<tool>`.

- **/mcp** — browse connected servers and their tools, resources, templates and prompts.
- **/mcp add docs --url https://mcp.example.com/mcp** — connect a remote server. Add
  `--auth-env DOCS_TOKEN` to reference a bearer token by its environment variable name.
- **/mcp add local-docs --env DOCS_TOKEN -- python /path/to/server.py** — configure a local process.
  Set credential values in those variables before launching DGC; terminal commands accept names,
  never literal credential arguments. The editor stores the credentials it manages in SecretStorage.
- **/mcp edit NAME ...** — change an existing definition; add never overwrites a server.
- **/mcp disable NAME**, **/mcp enable NAME** — change availability without losing the definition.
- **/mcp reconnect NAME** — reconnect one server; omit the name to reconnect all enabled servers.
- **/mcp remove NAME** — disconnect and forget its DGC configuration.

The same commands work outside a chat as `dgc mcp ...`. CLI, TUI and editor share configuration;
SecretStorage-only values remain editor-owned, so use an ambient variable reference when a server
also needs to start from the terminal.

## Attach resources and prompts

Choose **Resources**, **Resource templates** or **Prompts** on a connected server, preview its text,
and choose **Attach to draft**. The snapshot stays in a removable chip; reopening management keeps
existing text and selections. Templates take a concrete server URI, and prompts accept only their
declared arguments.

Terminal examples:

```text
/mcp resources docs
/mcp templates docs
/mcp prompts docs
/mcp read docs docs://api/reference
/mcp prompt docs inspect topic="request validation"
/mcp context
/mcp clear-context
```

Interactive `read` and `prompt` stage a snapshot for the next prompt or goal. `dgc mcp read ...`
prints the result instead. Loading another chat clears terminal staging. Resource URIs belong to
the selected server: even a `file://` URI is fetched from that server, not opened as a local file.
Catalogs and text have explicit bounds; binary/media omissions are reported. Reference text cannot
activate skills or grant tool access. Native reads use normal permissions, hooks and redaction;
plan mode permits attached snapshots but does not execute live MCP tools.

## Remote browser sign-in

Remote entries use the pinned `mcp-remote@0.8.3` bridge and require Node/npm. Explicit reconnects
allow a cancellable browser sign-in window. Decline stops the connection; use Reconnect to retry
an expired login or cold-start failure. OAuth tokens live in the bridge's private user cache,
separate from bearer tokens managed by the editor.

For desktop SSH/remote editors, DGC requests callback forwarding before opening sign-in. If the
editor changes the callback port or address, forward the remote callback port to the same local
port in the Ports panel and reconnect. This bridge cannot use browser-only remote editors that
require another callback origin. Terminal SSH needs equivalent forwarding. Device-code support
belongs to the provider. See [MCP authentication details](https://github.com/OpenPeach-ai/dgc/blob/main/docs/MCP_CONTEXT.md)
for verified flows and current bridge limits.

## Protocol and execution boundaries

DGC probes the stateless MCP 2026 protocol (`server/discover` plus self-describing
requests). If a handshake-era server rejects that probe, DGC discards the probe
process and reconnects cleanly with the legacy `initialize` lifecycle. Long-running
tools update the same tool card with correlated progress and warning/error logs;
`/mcp` reports the negotiated era and connection failures. Per-server config may
set `log_level` to `debug`, `info`, `notice`, `warning` (default), `error`,
`critical`, `alert`, `emergency`, or `off`.

Inbound and outbound stdio frames are bounded. If a server stops reading its pipe,
the request write remains cancellable, the poisoned process is reaped, and `/mcp`
reports the disconnected state instead of freezing the agent.

Modern roots, elicitation, and tools-free sampling inputs are answered through
bounded multi-round-trip requests; legacy elicitation/sampling callbacks are accepted
only while exactly one originating tool request is active. Every frontend makes the requesting server
visible. Forms reject credential/payment fields and are type-checked again before
sharing. URL requests show the exact host and URL, never prefetch, require consent,
and allow remote HTTPS or loopback HTTP only. Sampling has no tools, MCP context, or
project transcript and requires approval before generation and again before its
response is disclosed. Unsupported modes are not advertised and fail closed.

Servers are stored in your config under `mcp_servers`, so they reconnect on the
next launch. Treat every configured server command as a trusted executable: its
process starts unsandboxed in the workspace, and DGC cannot mediate that process's
own filesystem or network activity through tool permissions or the workspace lease.

Headless controllers can enumerate them with the typed `list_mcp_tools` command and invoke one
exact returned route with `call_mcp_tool`. Calls still pass through permission requests, lifecycle
hooks, the workspace lease, cancellation, progress/input consent, redaction, and output bounds.
""".strip()),

    ("Lifecycle hooks", "run observable commands at agent boundaries", """
# Lifecycle hooks

Configure hook commands under `hooks` in `~/.dgc/config.json`. Native local/API turns can call six
lifecycle events: `SessionStart`, `UserPromptSubmit`, `PreToolUse`, `PostToolUse`, `PreCompact`, and
`Stop`. Delegated subscription turns call `SessionStart` and `Stop`; their vendor-owned prompt and
internal tool loop is not visible to DGC's prompt/tool hook events.

- **/hooks** — show every supported event, its bounded configured count, redacted exact tool
  matchers, and invalid configuration state. Shell commands and environment values are never shown.
- `PreToolUse` and `UserPromptSubmit` can block an action with a non-zero exit. `PostToolUse`
  output is returned to the model as bounded feedback.
- Hook batches share the workspace mutation lease, own a process group, have one bounded deadline,
  drain a bounded redacted head/tail, and honor `/sandbox`.
- Headless controllers use `{"type":"list_hooks","request_id":"hooks-1"}` and receive
  `hook_catalog`. Natural execution emits `hook_activity` with `started` and exactly one terminal
  status; there is deliberately no command that executes a hook outside its lifecycle boundary.
- ACP represents configured hook runs as ordinary command-free tool-call lifecycle updates.

## Configuring one

Each event takes a list of entries. `command` is required; `matcher` is optional
and narrows a tool event to one tool:

```
{
  "hooks": {
    "PreToolUse":       [{"matcher": "bash", "command": "./scripts/guard.sh"}],
    "PostToolUse":      [{"command": "./scripts/format.sh"}],
    "UserPromptSubmit": [{"command": "./scripts/log-prompt.sh"}]
  }
}
```

The event payload arrives on **stdin as JSON**, so a hook reads it rather than
taking arguments:

```
#!/usr/bin/env bash
# ./scripts/guard.sh — refuse a bash command that touches the release directory
payload=$(cat)
case "$payload" in
  *dist/release*) echo "release artifacts are off limits to the agent"; exit 1 ;;
esac
```

Exit status is the control surface:

- a **`PreToolUse`** or **`UserPromptSubmit`** hook that exits non-zero **blocks
  the action**, and its output becomes the reason the agent is shown;
- a **`PostToolUse`** hook's output is appended to the tool result as feedback,
  so the agent reads it and can react;
- every other event ignores the exit status.

Use `/hooks` to confirm what DGC actually loaded — it reports the configured
count and redacted matchers per event without echoing your commands.
""".strip()),

    ("Skills", "reusable instruction packages", """
# Skills

A **skill** is a folder with a `SKILL.md` that teaches the agent how to do a
particular kind of work — a house style, a workflow, a checklist. DGC ships a
collection of 22 coding workflows. You can add project or personal packages, including
portable `.agents/skills` directories.

- **/skills** — browse instructions, source, diagnostics, and enabled state. The
  editor's **Create / install** action creates or copies a package; the terminal uses **a**.
- Type **$** or **/** after your draft text to choose skills. The editor attaches removable
  chips without replacing the draft; the terminal inserts an exact `$name` mention.
- Explicit selections load the full instructions for native and delegated subscription
  turns. Up to eight selections share a bounded context allowance. Disabled or removed
  selections are rejected before model execution. Scripts are never executed on install.
- Adaptive mode advertises metadata for narrowly matching skills; `tool_profile: full`
  exposes all enabled skills that permit implicit invocation. Explicit-only skills remain
  available through `$name`. The user request and normal permissions always take precedence.
- Project skills override personal skills, which override built-ins. Metadata refreshes
  at the next turn; use **Reload** to update the picker after external edits.
- **dgc-design** ships by default but stays dormant for normal coding — artifact
  frontend work activates it automatically. It preserves the requested brand and theme;
  DGC's purple palette is for DGC-branded or otherwise unbranded standalone DGC artifacts.

## Included workflows

- **browser-test** — real browser flows, failure recovery, responsive and keyboard checks.
- **fix-ci** — inspect the failed CI job and commit, reproduce the cause and verify a fix.
- **pr-feedback** — evaluate review comments against current code and address justified changes.
- **skill-author** — create focused, portable skill packages with meaningful validation.
- **mcp-builder** — implement and test the tools/resources/prompts an MCP server advertises.
- Also included: **batch**, **code-review**, **dataviz**, **debug**, **deep-research**,
  **dgc-design**, **handoff**, **loop**, **onboard**, **plan**, **refactor**,
  **security-review**, **setup**, **ship**, **ui-review**, **verify**, **write-tests**.

These packages provide instructions, not tools or account access. Browser work needs an
available browser harness; remote CI/PR work needs the appropriate client and account;
MCP development uses the project's SDK. Missing capabilities are reported. Skills do not
install dependencies, change permissions, publish or send messages merely by being selected.
For example: `Check failed-save recovery $browser-test` or
`Create a project API migration skill $skill-author`.

## Writing one

A skill is a directory containing a `SKILL.md`: YAML frontmatter, then the
instructions themselves.

```
~/.dgc/skills/commit/SKILL.md
```

```
---
name: commit
description: Write a conventional commit message for the staged changes
---

Read the staged diff with the native `git_diff` tool's staged view and write a single conventional
commit message for it. Focus (optional): $ARGUMENTS

Describe what changed and why, never how. No trailing period on the subject.
```

`name` is how you invoke it, `description` is what the agent matches against
when deciding whether the skill applies. `$ARGUMENTS` receives the invocation request.
Known metadata fields support plain, quoted, folded (`>`), and literal (`|`) scalar
values. DGC does not execute YAML tags, aliases, or objects. The `when` field is not used.

Discovery is project-first, so a repo can override a personal skill of the same
name:

- `<project>/.dgc/skills/<name>/SKILL.md`
- `<project>/.agents/skills/<name>/SKILL.md`
- `~/.dgc/skills/<name>/SKILL.md`
- `~/.agents/skills/<name>/SKILL.md`
- DGC's bundled skills

Optional `agents/openai.yaml` metadata can set `interface.display_name`,
`interface.short_description`, `interface.default_prompt`, and
`policy.allow_implicit_invocation: false`. Invalid optional metadata is diagnosed
and fails closed to explicit invocation. Supporting files resolve relative to the skill
directory and retain normal filesystem permissions.

## Manage packages

```
dgc skills list
dgc skills create review-api
dgc skills install ./team-skills/review-api
dgc skills disable review-api
dgc skills enable review-api
dgc skills show review-api
```

The same actions work through `/skills ACTION` in the terminal. Use `--user` with
create/install for a personal package. A source outside the project requires
`--allow-external`, or an explicit selection in the editor's folder dialog.
The editor also supports `/skills list|reload|show NAME|enable NAME|disable NAME`.
Creation produces an explicit-only scaffold; edit `SKILL.md` before using it.

Installation never overwrites or merges an existing destination. A local package can
contain up to 128 files/directories, 4 MiB total, eight directory levels, and 512 KiB
per supporting file. `SKILL.md` is limited to 64 KiB and 30,000 instruction characters.
Symlinks, special files, `.env` files, and generated dependency directories are rejected.
The terminal also supports raw-URL installation of a single `SKILL.md`; use local
package installation when supporting files are required. Installed scripts retain
private file permissions and can be run through their interpreter after normal approval.

Disablement is shared in DGC's configuration. The terminal's **x** disables a skill;
it does not delete source files. `/skills` lists the built-ins as examples you can copy.
""".strip()),

    ("Multiple agents", "run a fleet of agents at once + the dashboard", """
# Multiple agents

DGC runs a **fleet** — several agents working at the same time, each with its own
conversation. Kick off a long task on one, spawn another, and keep going.

- **Ctrl+N** — spawn a new agent (even while one is running). The old one keeps
  working in the background; the new one is a clean slate.
- **Ctrl+O** — cycle to the next agent. **Ctrl+\\** — open the **dashboard**.
- **Dashboard** — every agent with its live state: **●** on screen · **⋮**
  working · **◆** needs you · **○** idle. `Enter` attaches · `x` closes · `p`
  pins · `r` renames. `+ New agent` spawns one; saved sessions are listed to reopen.
- When a **background** agent finishes or needs a decision, the bottom bar shows
  **⧉ N · ◆ need you** — switch to it (Ctrl+O or the dashboard) to answer.

New agents use your current model by default; point one at a different model or
a cloud key with `/model` / `/connect` for true parallelism.

The launch agent stays in the checkout you selected. Every additional agent in a Git project gets
an owner-private `dgc/fleet-*` worktree containing the source checkout's exact tracked and
non-ignored untracked baseline. Each checkout has its own crash-safe mutation lease, so fleet writes
can proceed concurrently. Closing an untouched managed checkout removes it; changed, committed,
uncertain, or still-running work is retained with its visible branch/path. Reopening that saved
conversation validates and reattaches to the same checkout. Non-Git projects say when they fall back
to serialized shared-checkout writes. `/worktree <name>` creates a deliberately named long-lived
manual branch.

The model's `task` delegation tool isolates itself automatically in Git projects. Its private
checkout starts with the caller's tracked and non-ignored untracked state. DGC applies only a
completed child's conflict-free delta; it never overwrites paths that were already dirty, and it
retains conflicting or incomplete work with a visible worktree path and branch. Integrated edits
remain part of the parent turn's `/rewind` checkpoint and usage/edit totals.

Use `/tasks` to inspect retained work. `/tasks apply ID` recomputes its delta, rejects paths that were
dirty before delegation or changed in the parent, and adds an applied result to `/rewind`. `/tasks
drop ID --confirm` permanently removes the isolated checkout. Older recovery records created before
baseline fingerprints remain visible and droppable but deliberately require manual inspection instead
of unsafe auto-apply. VS Code/Cursor exposes the same operations through its command Quick Pick.
""".strip()),

    ("Context notes", "what the project already learned, across context windows", """
# Context notes

Compaction protects the model's context window. It also throws away what was already tried,
which is why an agent can cheerfully re-attempt a fix that failed an hour ago. DGC keeps the
durable half separately: short, typed notes about this project, written as the work happens.

They are **per project**, so a run spread over days accumulates one trace, and they are written
by the harness from tool results it already sees — no model cooperation required, so the same
behaviour holds on any local endpoint.

## What gets recorded

- **failure** — a command or an edit that failed, with its exit code and the tail of its output.
- **outcome** — a file that was written or patched; a test command that passed.
- **requirement** / **decision** — from your standing goal and from a compaction summary.

Every note is bounded, redacted with the same secrets a saved session is, and carries the file,
the tool and the date it came from, so a stale note can be judged rather than trusted.

## Reading them

- **`/notes`** — the most recent notes. **`/notes <query>`** searches the whole trace: an error
  string, a test name, a file path. `dgc notes [QUERY]` does the same from a shell, and
  **DGC: Show Context Notes** runs it from the editor.
- The agent has a **`notes`** tool with the same reach, so it can check whether something already
  failed before trying it again. It is read-only and allowed in plan mode.
- **After a compaction**, a bounded digest of requirements, decisions and recent failures is
  carried into the fresh context — the point at which this history would otherwise be lost.
- **While editing**, a file that has failed before carries that history into the result the agent
  reads, once per file per turn, so the next attempt is not the same one again.

## Turning it off

`/notes off` stops recording everywhere, and `notes: false` in the config does the same. The
store lives beside the session transcripts (`~/.dgc/sessions/<project>/notes.sqlite`), holds the
most recent `notes_max_rows` entries, and is never sent anywhere.

This is not the `/recall` archive. That is your raw scrollback, kept for you to read and never
put back into the model's context. Notes are a small curated projection that deliberately can
be — which is why they are bounded and redacted.
""".strip()),

    ("Sessions & rewind", "resume, jump, and undo whole turns", """
# Sessions & rewind

Every conversation is a session, saved as you go.

- **/resume** — reopen a past session (newest first); `dN` deletes one.
- **/new** (Ctrl+N) — start fresh; DGC auto-titles it from your first prompt.
- **/name** — rename the current session.
- **/history** (Ctrl+R) — search and recall any past prompt.
- **/jump** — scroll the transcript straight to a past turn.
- **/recall** — read the earlier conversation a compaction summarised away (see below).
- **/export** (`dgc export [ID] [FILE]`) — save a session as Markdown, archived turns included.
  Nothing the full-screen app shows survives in your terminal's scrollback; this does, and so
  does `dgc --classic`, the inline mode.
- **dgc export-training** / **/export-training** — export your sessions as scrubbed
  fine-tuning JSONL (see *Training export*); read-only, never modifies a session. The
  slash command runs the same export for the current project; the VS Code palette
  exposes it as *DGC: Export Training Data*.
- **/handoff** — create a bounded, redacted continuation document from one stable
  session generation. DGC saves it as a new private `HANDOFF-*.md` through the
  workspace lease; an overlapping turn is rejected instead of mixed into the file.
## Your earlier conversation after a compaction

When a session grows past `compact_threshold` of the context window, DGC replaces the older
turns with a summary. That is the **model's** limit, not yours: the turns themselves are kept
beside the session, so scrolling up shows *Your earlier conversation is still here* instead of a
bare summary. Click it, or run **/recall**, to read those turns back in place; click again to
hide them. `/recall` also works in `/copy` select mode, where the header is not clickable.

What is kept is a display copy — the text of your prompts and the model's replies, plus which
tools each turn used. It carries no tool results and nothing that could be fed back to a model,
and showing it never changes what the model sees or what the turn costs. Secrets are removed with
the same redaction that protects the saved session, including retroactively: a credential DGC
learns about later is scrubbed from turns archived earlier.

The archive is bounded (`recall_max_bytes`, 512 KB by default) and drops the oldest turns first
when it is full, saying so on the same line. Deleting a session deletes it too.

- **/rewind** — restore both the code *and* the conversation to how they were at
  a chosen turn. Exact conversation prefixes and project-root file snapshots are
  saved with the private session, so rewind survives resume and context compaction.
  Direct file-tool and integrated sub-agent changes are captured before mutation;
  the edit is refused if that durable capture fails. Arbitrary shell writes are not
  guaranteed rewindable, and approved external-path snapshots last only for the
  current process so resume never gains ambient authority outside the project.
""".strip()),

    ("Training export", "your real sessions → scrubbed fine-tuning JSONL", """
# Training export

Turn the sessions DGC already keeps into a training set for a local model. Run
it non-interactively — there is nothing to configure:

```
dgc export-training
```

Inside a session, `/export-training` runs the same read-only export for the current
project to `./dgc-training.jsonl` (pass a path to change it), and the VS Code command
palette offers *DGC: Export Training Data*.

Each session becomes one line of JSONL: the conversation as a standard
OpenAI-style `messages` array — `system` / `user` / `assistant`-with-`tool_calls`
/ `tool` results — plus a small `meta` object (model, project, turn and tool
counts, edits, and an outcome flag). That is the shape common SFT and
tool-calling fine-tuning tooling expects, so it drops straight into a training
run for the model you run locally.

## Flags

- `--out <file>` — where to write (default `./dgc-training.jsonl`).
- `--all` — export every project's sessions (default: just this project's).
- `--session <id>` — export a single session (a unique id prefix works).
- `--successful-only` — apply DGC's outcome heuristic: an edit landed with no
  edit-tool failure, or a `/goal` was marked complete. It does not prove test
  success or correctness; review exported records before training.
- `--min-turns N` — drop trivial sessions with fewer than N user turns.

## Secrets are stripped

Every field of every record is deep-scrubbed through DGC's redaction layer
before it is written: configured credentials (API keys, MCP/language-server
secrets) and high-confidence credential shapes (`sk-…` tokens, JWTs, auth
headers, private keys) are replaced with `[REDACTED]`. The export is read-only —
it never modifies a session. Reasoning traces and provider continuation blobs
are dropped so each record is a clean, portable conversation.
""".strip()),

    ("Standing goals", "persistent objectives with an explicit lifecycle", """
# Standing goals

`/goal <objective>` saves the objective and starts work in the terminal or editor.
DGC continues an active goal across work cycles on native local/API and delegated
subscription routes. Ordinary prompts do not create goals.

In the terminal, an active goal keeps a row directly above the composer: the objective, its
status, and the work time counted so far — so what DGC is holding you to, and how long it has
been at it, are visible without asking.

In VS Code/Cursor, entering `/goal <objective>` first saves the tagged goal and
then immediately starts that exact objective as an agent turn. Its status, active
time, review button, pause/resume button, and edit/delete controls stay above the composer.
Editing preserves the goal's identity and accumulated work time. Reopening a saved
session pauses its goal; time spent offline is not counted as work.

- `/goal` or `/goal review` — inspect the objective, status, work time, cycles, and evidence.
- `/goal pause` — stop work and retain the goal for later.
- `/goal complete` — retain the objective as an auditable completed record.
- `/goal blocked` — stop automatic progress while an external blocker exists.
- `/goal resume` — reactivate the goal and continue work immediately.
- `/goal clear` — remove it.

Native models use `update_goal` with a summary and evidence. Delegated models submit
a structured closing report that DGC validates and removes from the displayed answer.
Completion is applied after the work cycle succeeds; failed or cancelled work cannot
complete a goal. Three consecutive cycles without distinct tool progress block the
goal for review. Cancellation or a runtime failure pauses it.

Use `/goal --tokens 100000 <objective>` for an optional token budget, or edit the
budget in the goal card. Budgets are checked between native requests or delegated
work cycles, so a request or concurrent/subagent work can take usage past the limit. A model route that
does not report usage cannot enforce a token budget; DGC pauses instead of continuing
with unknown usage. The goal review shows the reported usage and any budget pause.
Ending one work cycle or finishing one milestone is not whole-goal completion.

## Autonomous gate

On native local/API routes, `--autonomous-gate "<cmd>"` bounds an autonomous run by a real check command: the
agent may not end a turn until that command exits 0. When the model tries to stop
and the gate fails, DGC feeds the command's output back and keeps working; when it
exits 0, the stop is allowed. Bounded by `--autonomous-max-turns` (default 30)
failed attempts, so a persistently red gate can never loop forever. Unset (the
default) leaves turn completion unchanged. e.g. `--autonomous-gate "npm run check"`.

Set it live without restarting: `/autonomous-gate "npm run check"` in the classic
or full-screen TUI (`/autonomous-gate off` clears it, no argument reports the current
gate and retry bound). The gate command and its max-retry bound are also editable in
the TUI settings screen (Behaviour). In the VS Code extension, set `dgc.autonomousGate`
and `dgc.autonomousMaxTurns` in Settings. Delegated subscription turns bypass this
native controller gate; selecting a vendor engine does not make the configured command run.
""".strip()),

    ("Files pane", "a file explorer under the transcript while the agent works", """
# Files pane

`/files` opens a file explorer in the **focus pane** — the split under the transcript that the
agent keeps streaming above. Browse the project, pick files for your next prompt, watch the
model's edits land, and manage files without leaving DGC or stopping the turn.

## Open it

- `/files` opens at the project root · `/files src/auth` jumps to a folder or focuses a file.
- The pane folds away whenever DGC needs your answer (a permission, a prompt, a picker) and
  returns when you have answered. **q** or **Esc** closes it; **Ctrl+C** still stops the agent.
- It works during a turn: the header shows what the agent is doing (`DGC: USING TOOLS`), and
  files the model changed this turn carry a **✎** mark.

## Layout

Three columns like yazi and ranger: the parent folder, the current folder, and a preview of what
is under the cursor — the first lines of a text file with line numbers, a folder's entries, a
symlink's target, or a one-line summary for binaries. Narrow terminals drop the parent column,
then the preview. **i** or **Tab** swaps the preview for details (size, modified time, mode, Git
status). Git status letters (**M** modified · **A** added · **D** deleted · **?** untracked) come
from a read-only `git status` that never runs filters or transports.

## Move and select

- **j / k** or **↑ ↓** move · **h / l** or **← →** go to the parent / enter a folder · **gg / G** top / bottom
- **H / L** back / forward through folders you visited · **-** the previous folder · **~** home · **gr** the project root
- **Space** toggles the entry under the cursor · **v** starts a visual range · **Ctrl+A** selects everything · **Esc** clears
- **f** filters the list as you type (smart case) · **/** finds and **n / N** step through matches · **.** shows hidden files · **s** cycles name → modified → size → extension, **S** reverses

## Use a file in your prompt

- **Enter** (or **o**) on a file inserts `@path` into the composer — the same bounded file attachment as typing it — so you can browse, pick, and ask about exactly that file.
- **c** inserts the plain path instead.

## Change files

- **a** creates a file, or a folder when the name ends with `/` (`docs/notes/` creates both levels).
- **r** renames, with the cursor placed before the extension.
- **y** copies and **x** cuts the selection (or the entry under the cursor); **p** pastes into the current folder, keeping both on a name collision (`name (2).ext`); **P** overwrites instead.
- **d** sends entries to the trash — DGC's own `~/.dgc/trash` by default, kept for 30 days, or the OS trash when `trash_mode` is `os`.
- **D** deletes permanently and always asks first.
- **u** undoes the last change: renames move back, copies are removed unless you edited them, trashed entries return, and permanently deleted *files* (up to 8 MB) are restored from the snapshot taken before deletion. Deleted folders are not restorable.

## What it will not do

- It never runs a shell command and nothing it does enters the model's context unless you insert a path.
- Writes follow the permission mode: **plan** makes the pane read-only; **default** asks before trash, move, and overwrite; **acceptEdits** and **auto** act immediately with undo. Permanent deletion asks in every mode.
- Writes stay inside the project. Browsing above the root is read-only, except in **auto** mode, which asks first.
- The project root itself is never an operand. Trash, delete, rename, and move refuse it and every folder above it, in every mode, so browsing up to the parent and pressing **d** cannot throw the project away.
- Trees over 5,000 entries or 512 MB are refused rather than half-copied; use the shell for those.
""".strip()),
    ("Turn ETA & notifications", "how long the turn still needs, and a ping when it is done", """
# Turn ETA & notifications

While a native turn runs, the status line shows a calibrated range for how much longer it
should take — `1m12s · ~2–4 min left · 3/5 tasks` — so you can decide whether to wait or walk
away. `/eta` says the same in a sentence with its basis and confidence; `/eta stats` shows how
often the range has held on this project.

## How the estimate is made

- **Your history.** Every finished turn on this project is recorded by what it asked for
  (explain · test · fix · add · refactor) and how long the prompt was. The estimate starts from
  the middle and 80th-percentile durations of similar turns — or DGC's built-in priors on a new
  project — and shifts as time passes, because a turn that has already run past the typical
  length is likelier to keep going.
- **The turn's own plan.** Once the model keeps a task list, remaining tasks × the pace of the
  tasks already finished takes over as the main signal. This is where the range gets sharp.
- **Honesty rules.** The range appears only after 20 seconds, may shrink freely but only grows
  when there is a reason, and drops to `~a few min left` instead of a number when confidence is
  low. Predicted-vs-actual is logged for every turn; the site only ever quotes coverage that was
  measured.

The estimate is per-project and private (`~/.dgc/eta-stats.json`, bounded). Turn it off with
`eta: false` in `config.json` or `/settings`. Subscription turns delegated to a vendor CLI have no
estimate: DGC does not see their steps.

## Walk away

- `/notify` during a turn pings you once when it finishes: a terminal notification where the
  terminal supports one (iTerm2, WezTerm, kitty, Windows Terminal, ConEmu), a bell everywhere,
  and a flash in the status line. `/notify` before a turn arms the next one.
- `/notify on` keeps it on for every turn over 20 seconds; `/notify off` turns it back off.
- In the editor, enable **DGC: Notify On Turn End** to get a toast when a turn finishes while
  the DGC panel is not visible.
- For anything else — a phone push, a sound, a script — use the **Stop** lifecycle hook, which
  already fires at the end of every turn (see *Lifecycle hooks*).
""".strip()),
    ("Connect your model", "point DGC at Ollama, llama.cpp, vLLM, or a cloud host", """
# Connect your model

DGC talks to any supported native or OpenAI-compatible endpoint. Pick one with
`/connect` (or `dgc setup` on first run), then `/model` to choose the served model.

## Local runtimes

- **Ollama** — `/connect ollama` uses `http://localhost:11434/v1`. DGC auto-detects
  Ollama and speaks its native chat API (which round-trips the model's own thinking).
- **llama.cpp** — run `llama-server`, then `/connect llamacpp`
  (`http://localhost:8080/v1`, no real key needed). This is the OpenAI-compatible
  `/v1` server built into `llama.cpp`.
- **vLLM / SGLang** — `/connect vllm` (`http://localhost:8000/v1`). The server
  renders the chat template, so DGC sends the reasoning switch it understands.
- **LM Studio** — `/connect lmstudio` (`http://localhost:1234/v1`).

## unsloth GGUFs

unsloth is not a serving runtime — its GGUF/quantized models are served **through**
llama.cpp (`llama-server`), vLLM, or Ollama. Start one of those with your unsloth
model, then pick that runtime's preset. `/think <level>` reaches Qwen3-family
templates (which read the effort from inside `chat_template_kwargs`) automatically.

## Custom / LAN hosts

`/connect http://<host>:<port>` points DGC at any other OpenAI-compatible server.
If you enter a bare host, DGC appends the `/v1` chat-completions path for you and
prints a notice (Anthropic and native Ollama URLs are left as-is). Models are
auto-discovered from the endpoint's `/v1/models`, so `/model` lists what the host
actually serves.

## Cloud providers

`/connect openai | anthropic | openrouter | groq | deepseek | together | mistral`
prompt for the provider's key and use its native auth contract. See **Subscriptions**
to instead run your own Claude/Codex/Qwen/Kimi/Copilot plan through its official CLI.
""".strip()),

    ("Thinking & reasoning", "off · low · medium · high · xhigh, and preserving it", """
# Thinking & reasoning

DGC exposes one thinking dial, mapped to the correct wire format **per provider**.

## Levels

`off` · `low` · `medium` · `high` · `xhigh`. `off` is the default — a coding agent
should act, not deliberate at length. `xhigh` is the deepest budget, for genuinely
hard problems on reasoning-capable models.

- `/think` — cycle, or `/think high` to set a level (persisted across restarts).
- `--think <level>` — set it for one `dgc -p` run.
- TUI: `/think` opens a picker; **Settings → Model & sampling → Thinking effort**.

Reasoning models (o-series, DeepSeek-R1, qwen-thinking) tend to do better on hard
tasks with `/think high` (or `xhigh`); non-reasoning models often ignore the dial.

## Showing thinking

`show_reasoning` (`/thoughts show|hide`) controls whether the model's thinking is
shown, muted, in the transcript. It does **not** change how hard the model reasons —
that is `/think`.

## Preserving thinking across turns

Backends differ in whether prior-turn reasoning is carried back into context:

- **Anthropic** (signed thinking blocks) and **Ollama** (native thinking field)
  round-trip their own reasoning automatically.
- The **OpenAI-compatible / llama.cpp** chat-completions transport **strips** the
  model's reasoning every turn.

`preserve_thinking` (`/preserve-thinking on|off`, default off) re-embeds the last
turn's reasoning as a `<think>…</think>` block in the assistant message sent back,
so a compatible/local model can build on its own earlier thinking. It helps
multi-turn coherence but costs context tokens, and only affects the
chat-completions path (the Anthropic/Ollama paths are untouched).
""".strip()),

    ("Subscriptions", "bring your own Claude / Codex / Qwen / Kimi / Copilot plan", """
# Subscriptions

Instead of a raw model endpoint, DGC can drive a coding CLI you already pay for and
are logged into — from the full-screen app, the classic inline REPL (`dgc --classic`),
the editor/headless backend, or a one-shot `dgc -p --engine` run. Every route renders
the vendor's stream the same way: its tool steps as cards with their diffs, its
reasoning dimmed, and its answer as it arrives.

## Engines

- **Claude Code** — your Anthropic Pro / Max plan (`claude`).
- **Codex** — your ChatGPT Plus / Pro plan (`codex`).
- **Qwen Code** — your Qwen OAuth plan (`qwen`).
- **Kimi for Coding** — your Moonshot plan (`kimi`); its prompt mode is auto-only, so DGC must be
  in `auto` and the vendor controls its automatically approved internal tool actions.
- **GitHub Copilot CLI** — your Copilot plan (`copilot`).

## How it works (orchestration, not a token proxy)

This is orchestration, not credential replay. DGC never reads, stores, refreshes,
or replays the vendor's tokens and never sends vendor-private headers. Each engine
authenticates through the vendor's **own** login command, which opens the vendor's
own browser / device flow and keeps the token in its own store. When you run a turn,
DGC shells out to the official binary in your workspace and streams its output into
DGC's UI. DGC saves the prompt and normalized final assistant response in its own
session; vendor tool and thinking events remain display-only. Authentication, model
execution, and internal tools remain owned by the selected vendor CLI, while DGC
wraps the turn with its own prompt, mode, session mapping, timeout, and cleanup.
The vendor process is not wrapped by DGC's OS sandbox and inherits DGC's ambient
environment, including unrelated credentials. Use a trusted vendor CLI and launch
DGC with only the environment secrets that turn needs.

## Select and sign in

- `dgc setup` lists subscription engines first, with each one's detected login marker. The vendor
  performs the actual authentication check when its CLI launches.
- `/connect claude|codex|qwen|kimi|copilot` selects an engine (a direct `/connect`
  to a provider or URL turns delegation back off).
- Sign in once with the vendor's own command, e.g. `claude auth login`, `codex login`,
  `qwen` (device code), `kimi login`, `copilot login`. `dgc doctor` reports status.

## Model + reasoning effort

- `/model` steers the vendor's own model (e.g. opus/sonnet/haiku for Claude).
- `/think low|medium|high|xhigh|max` sets the reasoning effort for engines that take one
  (Claude, Codex, Copilot); engines without an effort flag steer it via `/model`.
- The editor's composer controls, `/model` and `/think`, and the corresponding
  command-palette pickers all follow the active route. Subscription model pickers
  use vendor aliases when known and otherwise accept a vendor model id directly;
  they never query the configured native endpoint.
- In one-shot automation, `--model` and `--think` override only that delegated
  `dgc -p --engine` turn. They do not rewrite the saved native model or thinking level.
""".strip()),

    ("Python code-action (power mode)", "a persistent Python interpreter for token-efficient work", """
# Python code-action (power mode)

An **optional** power tool, **off by default**. Turn it on with `code_action: true` in
`~/.dgc/config.json` (or a project `.dgc/`), with `/code-action on` in the classic or
full-screen TUI (a row in the TUI settings screen and a toggle in the VS Code panel do
the same), or `/code-action off` to disable it. When on, DGC advertises a **`python`** tool.

## What it is

`python` runs code in a **persistent interpreter tied to your session**. Variables, imports, and
function definitions **persist across tool calls** — the model can load data into a variable **once**
and then run computations over it across many turns.

## Why it saves tokens

The usual loop re-reads data into the context on every step. With a persistent interpreter the model
loads a file/dataset into a variable one time, then each later call is just a small snippet of code
that operates on the already-loaded state. The bulky data never re-enters the prompt — only the code
and its (bounded) output do. This is the "code action" / CodeAct pattern.

## Behavior

- The last statement, if it is a bare expression, has its `repr()` shown (REPL-style).
- `stdout`/`stderr` printed during a call are captured and returned, redacted and length-bounded like
  `bash`.
- An exception returns a clean traceback and the interpreter **stays alive** for the next call.
- Pass `reset: true` to restart with a fresh, empty namespace.
- State also resets when the session ends (or on `/new`).

## Safety

It executes arbitrary code on your machine and inherits DGC's environment, so treat it with the same
trust as an unsandboxed shell. It uses the **same permission path**: it asks in
`default`/`acceptEdits` mode and is **denied in plan mode**. The persistent interpreter is not wrapped
by `/sandbox`, does not use the workspace mutation lease, and its filesystem changes are not captured
by `/rewind` or treated as verifier-invalidating mutations. Review its effects and run verification
explicitly. Because it is off by default, ordinary users never see it until they opt in.
""".strip()),
    ("Configuration", "config.json, models, context, providers", """
# Configuration

Global settings live in `~/.dgc/config.json`; per-project overrides live in a
project's `.dgc/`. Most settings have a slash command, so you rarely edit the
file by hand.

Useful keys:

- `base_url`, `model` — the endpoint and model (`/connect`, `/model`). Credentials live in
  owner-only `~/.dgc/secrets.json`, VS Code SecretStorage, or `DGC_API_KEY` / the other
  `DGC_*_API_KEY` environment references; they are not written into normal config.
- `mode`, `thinking` — permission mode and reasoning effort. `thinking` is **`off`
  by default** (a coding agent should act, not deliberate at length) and accepts
  `off · low · medium · high · xhigh`. DGC maps the requested level to each provider's
  supported control. Some reasoning-only models translate `off` to their minimum effort,
  and endpoints that do not expose a compatible control may ignore it; a set level reaches
  Qwen3-family llama.cpp/unsloth templates through `chat_template_kwargs`. **Reasoning models (o-series,
  DeepSeek-R1, qwen-thinking) may do better on hard tasks with `/think high`.** See the
  **Thinking & reasoning** guide.
- `show_reasoning`, `preserve_thinking` — `show_reasoning` (`/thoughts show|hide`)
  shows the model's thinking, muted, in the transcript. `preserve_thinking`
  (`/preserve-thinking on|off`, default off) re-embeds the prior turn's reasoning in
  the context sent back so a compatible/local model keeps its own thinking across
  turns (costs tokens; only the OpenAI-compatible/chat_completions path — Anthropic and
  Ollama already round-trip their reasoning natively).
- `think_budget_tokens`, `max_tokens` — safety backstops: a reasoning phase that
  runs away with no output is aborted + retried with less reasoning
  (`think_budget_tokens`, 0=off); output is capped at `max_tokens` (length-truncation
  auto-continues, 0=don't send).
- `api_mode`, `provider_state`, `prompt_cache` — transport and continuity. `auto` selects native
  Ollama chat for detected Ollama endpoints, Anthropic Messages for Anthropic, OpenAI Responses for
  OpenAI, and Chat Completions for compatible servers. Use `api_mode: ollama` or `api_mode:
  anthropic` only when a proxy hides its provider identity. Anthropic Messages preserves signed
  thinking and grouped tool-result continuation blocks locally; it never sends the key as Bearer
  authentication.
  Responses defaults to stateless (`store: false`) with local encrypted-reasoning replay and
  a hashed cache-routing key when DGC derives the key. An explicit `prompt_cache_key` of up to
  64 characters is sent verbatim. Choose `provider_state: server` only when provider-side
  response storage is acceptable.
- `provider_capabilities`, `capability_cache_ttl_s` — explicit feature overrides and the bounded
  interval before DGC retries a capability that an endpoint/model rejected.
- `context_size` — the requested operating window. Known model selections apply a
  memory-conscious recommendation; authoritative provider metadata clamps impossible values but
  never silently expands a local Ollama allocation. Long sessions compact at
  `compact_threshold` of the effective value.
- `search_timeout` — bounded 1–60 second lifetime for internal `grep`/`glob` discovery. DGC uses
  ripgrep without a shell when available and a link-safe bounded fallback otherwise.
- `session_redaction` — on by default. Durable transcripts, checkpoint conversation blobs, goals,
  titles, and plans receive an additional credential-redaction pass. Live native-provider/tool and
  editor/headless/ACP masking remains enforced. Delegated vendor-CLI streams in the full-screen TUI
  or subscription one-shot CLI are shown as the vendor emits them after terminal-control cleanup,
  so treat vendor output as sensitive. Exact file rewind snapshots remain byte-for-byte unchanged
  inside the owner-private session so `/rewind` cannot corrupt a file.
- `tool_profile` — `adaptive` (default) keeps all core coding tools while activating web, artifact,
  skill-install, memory, goal, and delegation tools from explicit turn/standing-goal intent. Use
  `full` to expose the whole execution catalog on every model request.
- `code_action` — **off by default.** When `true`, DGC advertises a `python` power tool that runs
  code in a **persistent per-session interpreter** (variables/imports survive across calls). See the
  **Python code-action** guide. It executes arbitrary code and is gated by the same approval path as
  `bash` (asked in default/acceptEdits, denied in plan), but is not wrapped by `/sandbox`,
  checkpointed, or mutation-tracked for verifier reuse. It is never shown until you opt in.
- `theme`, `background` — appearance (`background` defaults to *inherit*, never
  repainting your terminal).
- `suggest` — ghost-text next-prompt suggestions (Tab/→ to accept). Auxiliary title/suggestion
  requests wait for fleet-wide idle time and are canceled before foreground work;
  `aux_idle_delay_ms` controls the grace period.
- `mcp_servers`, `hooks`, `fallback_model`, `subagent_model` — extend the agent. When a fallback or
  sub-agent uses another endpoint, its transport is inferred independently instead of inheriting a
  forced main-provider mode; set `fallback_api_mode` or `subagent_api_mode` only to override that.
  Lifecycle-hook batches are capped at 32 entries and one 20-second deadline, drain only a bounded
  redacted head/tail, own a process group and checkout mutation lease, and honor `/sandbox`.
- `subagent_worktree_root` — optional private storage for automatic delegated checkouts; empty uses
  `~/.dgc/worktrees`. It must be outside the source repository.
- `fleet_worktree_root` — optional private storage for automatically isolated TUI agents; empty uses
  `~/.dgc/fleet-worktrees`. Conversation resume state remains scoped to the source project, and
  changed managed checkouts are retained rather than force-removed.
- `max_parallel_tasks` — bounded `task` fan-out (default 4, maximum 8; set 1 to disable). In a
  Git-backed full-auto turn, two or more independent `task` calls emitted together are snapshotted
  from one parent baseline, run concurrently, and integrated in call order. Hooks, interactive
  permission modes, mixed tool batches, and non-Git projects keep the normal serial path.
- `language_servers`, `code_intel_timeout`, `code_intel_lsp_idle_s` — optional stdio LSP
  commands for richer definitions,
  references, symbols, and diagnostics. Keys may be a language (`python`) or extension (`.py`):
  `{"language_servers":{"python":{"command":"pyright-langserver","args":["--stdio"]}}}`.
  Without one, the bounded dependency-free static analyzer remains available. Configured servers
  receive a minimal environment, run without a shell, and are serialized per project/server spec.
  DGC keeps at most four configured sessions warm for 120 seconds by default, reaps them when idle,
  and retires failed sessions. Explicitly approved external-file queries always stay one-shot; set
  `code_intel_lsp_idle_s` to `0` for one-shot isolation everywhere.

## Credentials

The `api_key`, `search_api_key`, `subagent_api_key`, and `fallback_api_key` values never live in
`config.json`; they are written to `~/.dgc/secrets.json` with owner-only permissions, and each can
be supplied by environment variable instead (`DGC_API_KEY`, `DGC_SEARCH_API_KEY`, …). On the
command line, `--api-key-env NAME` reads a key from the environment **without persisting it at
all**. `fallback_base_url` and `subagent_base_url` point the fallback and sub-agent at their own
endpoints.

## Sampling and limits

Sampling keys are empty by default, which means *use the endpoint's own defaults* — set one only
when you want to override it.

- `temperature`, `top_p`, `top_k`, `min_p` — sampling parameters, passed through when set.
- `max_turns` (default `0`) — optional emergency tool-iteration backstop. `0` lets a progressing
  turn continue until it completes, is cancelled, or reaches an explicitly configured time budget;
  repeated-call and no-progress guards remain active independently.
- `turn_budget_s` (default `0`, meaning no limit) — wall-clock budget for a turn. The agent
  reserves the tail of this budget to converge and persist rather than being cut off mid-edit.
- `request_timeout` (default `1800`) — maximum seconds of provider-stream inactivity between
  response chunks; an active response can take longer overall.
- `bash_timeout` (default `120`) — per-command shell timeout.
- `approval_timeout_s` (default `300`) — how long a permission prompt waits before giving up.
- `ollama_keep_alive` (default `30m`) — how long Ollama keeps the model resident between turns.
- `prompt_cache_key` — an explicit cache key for providers that support prompt caching.

## Web search

- `search_provider` (default `duckduckgo`) — which backend answers the agent's web searches.
- `search_url` — a custom endpoint for a self-hosted search backend; empty uses the provider's own.
- `search_api_key` lives in `secrets.json` (above). Web providers use bounded transport timeouts.

## Sandbox

- `sandbox` (default `false`) — run shell commands inside the sandbox.
- `sandbox_network` (default `false`) — allow network access from sandboxed commands.
- `sandbox_env_allow` (default `[]`) — environment variable names to pass through to sandboxed
  commands. Other non-baseline host variables are withheld; DGC still supplies a small safe
  baseline plus sandbox-specific home, temporary, and runtime paths.

## Artifacts

- `artifact_autostart` (default `true`) — serve artifacts automatically as they are produced.
- `artifact_port` (default `45000`) — the shared port for project artifacts. Plan previews use a
  separate transient loopback server and port.
- `artifact_bind` (default `localhost`) — the bind mode. Set it to `lan` to preview
  from another device on your own network.
- `artifact_hostname` — the hostname used when building the printed URL, if it differs from the
  bind address.
- `plan_artifact` (default `true`) — render proposed plans as an artifact page.
- `artifact_in_plan` (default `false`) — also serve artifacts while in plan mode.

## Native-route unattended runs

- `autonomous_gate` — a check command that must exit `0` before a native local/API agent may stop a turn.
- `autonomous_max_turns` (default `30`) — bound on failed gate retries.
- `verify_before_done` (default `false`) and `verify_command` — run a command and feed a failure
  back before allowing a native local/API turn to end. Passing a check normally returns its
  result to the model so it can finish other requested work and selected skill steps.
- `finish_on_verified` (default `false`) — opt in only when the configured verifier defines the
  entire task. In timed native `auto` runs with `verify_before_done` and `verify_command`, a green
  check can end the turn without another model request. Active goals, explicit skills and unfinished
  todos always retain normal completion. Leave this off for ordinary multi-step work.

Subscription turns are delegated to the selected vendor CLI and bypass these two native-loop gates.

The autonomous-gate pair has command-line equivalents; see **Command line**. The verifier pair is
configured in `config.json`.

## Subscriptions

- `subscription_engine` — which vendor CLI drives the turn.
- `subscription_model`, `subscription_effort` — model and effort passed through to that CLI.

## Turns

- `eta` (default `true`) — show the calibrated "~2–4 min left" range while a turn runs.
- `notify` (default `off`) — `on` pings after every turn over 20 seconds; `/notify` arms a single one.

## Files pane

- `mouse` (default `capture`) — `capture` lets the wheel scroll DGC and rows respond to clicks;
  `off` leaves the mouse to your terminal so drag-select works. `/select` toggles it for one
  session; `/mouse on|off` changes this setting.
- `recall_max_bytes` (default `524288`) — how much earlier conversation `/recall` keeps per
  session after compaction, oldest turns dropped first.
- `trash_mode` (default `dgc`) — where `/files` sends deleted entries: `dgc` keeps them in
  `~/.dgc/trash` for 30 days (undo with **u**), `os` uses the system trash (freedesktop layout on
  Linux, `~/.Trash` on macOS; other platforms fall back to `dgc`).

## Appearance

- `logo_animation` (default `true`) — the animated mark on the welcome screen. Turn it off for a
  static logo.
""".strip()),
]


def titles() -> list[str]:
    return [t for t, _, _ in DOCS]


def slug(title: str) -> str:
    """Stable public identifier for a bundled documentation page."""
    return re.sub(r"[^a-z0-9]+", "-", str(title or "").lower()).strip("-")[:80]


def catalog() -> list[dict[str, str]]:
    """Return editor-safe metadata without duplicating the documentation source of truth."""
    return [{"id": slug(title), "title": title, "description": description}
            for title, description, _markdown in DOCS]


def find_id(identifier: str) -> tuple[str, str, str] | None:
    wanted = str(identifier or "").strip().lower()
    for entry in DOCS:
        if wanted in (entry[0].lower(), slug(entry[0])):
            return entry
    return None


def find(title: str) -> tuple[str, str, str] | None:
    for entry in DOCS:
        if entry[0].lower() == title.lower():
            return entry
    return None
