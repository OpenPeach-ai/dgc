<div align="center">

<img src="docs/dgc-logo.png" alt="DGC" width="380">

# Vibe DGC

**A coding-agent CLI for the models *you* run** — the same `///` you see in the terminal.
Built by Mohit Kalra.

</div>

---

DGC is an interactive coding agent that lives in your terminal and points at **the model endpoint you choose**: local Ollama, llama.cpp, LM Studio, or vLLM; native Anthropic or OpenAI; and compatible clouds such as OpenRouter, Groq, DeepSeek, Together, and Mistral.

![Vibe DGC — the CLI welcome screen](docs/welcome.png)

<sub>The welcome screen, pointed at your own local model — the `///` mark, the session menu, and the **mode · model** status line.</sub>

Pure Python 3.10+, three dependencies (`rich`, `prompt_toolkit`, `requests`). With a local model and local-only integrations, prompts and selected code can stay on your machine; cloud models and remote integrations receive the context or requests you direct to them. A configured language server receives workspace metadata and full text for documents queried through code intelligence.

![DGC docked in your editor — VS Code and Cursor](docs/screenshot.png)

<sub>The same agent and local models inside a native editor side panel — streaming tool cards, inline diffs, session resume. Installs alongside the CLI ([VS Code · Cursor](https://vibedgc.com/vscode/)).</sub>

## Install

One line — nothing needs root:

```bash
curl -fsSL https://vibedgc.com/install.sh | bash
```

If `cursor`, `code`, or `codium` is on `PATH`, the installer also checksum-verifies
and installs the DGC extension into the first one found. Prefix the command with
`DGC_SKIP_EXTENSION=1` to install only the CLI.

Then point it at a model and go:

```bash
dgc setup     # pick a provider + model, interactively
dgc doctor    # check it can reach your model
dgc           # start the interactive agent
```

<sub>Prefer to do it by hand? See [Manual install](#manual-install). Want your own coding agent to set it up? See [Let your agent install it](#let-your-agent-install-it).</sub>

## Connect any model in one command

`dgc setup` walks you through these with **arrow-key menus** (↑/↓ or j/k · enter · esc to go back) — as do `/connect`, `/models`, `/search` and `/resume` inside the REPL:

| Preset | Endpoint | Notes |
|---|---|---|
| `ollama` | `localhost:11434/v1` | local, default |
| `llamacpp` | `localhost:8080/v1` | `llama-server` from llama.cpp |
| `lmstudio` | `localhost:1234/v1` | LM Studio |
| `vllm` | `localhost:8000/v1` | vLLM |
| `openai` | `api.openai.com` | prompts for API key |
| `openrouter` | `openrouter.ai` | 100s of models, one key |
| `groq` · `deepseek` · `together` · `mistral` | — | cloud, prompt for key |

```
/connect ollama
/connect openrouter        # securely prompts for the key
/models                 # list what the endpoint serves
/model qwen3.6:27b-q8_0
```

## Benchmarks

The retained Aider-polyglot measured slice covers 90 problems—15 in each of six languages—with pass@2. Every harness records the same `qwen3.8:27b-orig` alias, caller-declared digest, endpoint URL, and settings; the runner verified context size, but not the endpoint's actual model weights. DGC solved 85/90 (94.4%); Goose solved 86/90 (95.6%). The saved run lacks its runner revision, so it is disclosed as a measured slice rather than release-gating evidence.

The SWE-bench Lite result is founder-published as 184/300. The retained files contain 300 predictions, 292 with non-empty patches, but no grading report or resolved-instance list; they cannot independently reproduce 184/300. See the complete disclosures and sanitized evidence bundles at **[vibedgc.com/benchmark](https://vibedgc.com/benchmark)**.

## Native local/API permission modes

Switch live with `/mode` (cycles) or `/mode <name>`, or launch with `--mode`:

| Mode | Behavior |
|---|---|
| `default` | structured reads auto-run; model-requested file writes and shell commands ask by baseline |
| `acceptEdits` | file edits auto-approved by baseline; shell commands ask by baseline |
| `plan` | **read-only** — the agent researches and proposes a plan you approve |
| `auto` | **full-auto** — model-requested tools are approved; some integration consent prompts still require you |

Fine-grained rules on the native local/API loop (evaluated deny → ask → allow):

```
/permissions allow Bash(npm run *)
/permissions allow Edit(src/**)
/permissions deny  Bash(rm -rf *)
/permissions deny  Read(**/.env)
```

Delegated subscription turns map the selected mode into the vendor CLI's supported flags and policy.

Approval prompts offer **allow once / always allow / deny**. “Always allow” saves a
narrow rule only when the action arguments contain no detected credential.

## What's in the box

- **Multiple agents at once** — run a **fleet**: `Ctrl+N` spawns a new agent (even while one is running), `Ctrl+O` cycles, `Ctrl+\` opens the **dashboard** — every agent with its live state (● on screen · ⋮ working · ◆ needs you · ○ idle), where you attach, close, pin, and rename. A background agent that finishes or needs a decision flags itself in the bottom bar. The launch agent stays in your selected checkout; every additional agent in a Git project automatically gets an owner-private `dgc/fleet-*` worktree containing the source checkout's exact tracked and non-ignored untracked baseline. Each owns its model/config/MCP runtime and can write concurrently under its own crash-safe lease. Closing an untouched managed checkout cleans it up; changed, committed, uncertain, or still-running work is retained with its branch/path, and reopening the saved conversation safely reattaches to it. Non-Git fleets fall back explicitly to serialized shared-checkout writes. `/worktree <name>` remains available for a deliberately named long-lived branch, while delegated `task` work uses separate automatic task worktrees.
- **Interactive REPL** — streaming output, live tool-call display, diffs, todos, a highlighted prompt band, collapsible thinking sections, a per-phase status timer (`Thinking… 0.4s`), a top-right context-window meter (click it for a usage breakdown), and centered dialogs. When DGC records a native action as tracked or potentially workspace-mutating, `verify_before_done` holds only the attempted final answer until its configured verifier passes: a rejected completion claim never reaches the terminal, editor, headless, or ACP output and is replaced in resumable history, while genuine tool commentary still appears before its tool card. The opt-in persistent `python` tool is not mutation-tracked; review its effects and run verification explicitly. In a timed autonomous turn, an edit-only batch runs that explicit verifier immediately: red evidence reaches the next model request directly, while green evidence closes locally without a test-request or summary generation. Untimed interactive cadence remains model-authored, and its no-tools final reuses an exact verifier pass until a later mutation-unknown MCP call invalidates it instead of rerunning the same command; configured PostToolUse hooks conservatively retain the final controller check. Completed generations are also journaled under fixed argument-free controller reasons, making tool continuation, verifier recovery, steering, compaction, and auxiliary work distinguishable in benchmark reports without retaining prompts or model text.
- **Native plan mode** — on local/API routes, read-only research → `present_plan` → reject with feedback or approve into acceptEdits/default/auto. Native plans are saved beside the session, reopened with `/view-plan`, and rendered by default as a self-contained loopback-only preview. Full-auto approval has a separate warning gate. Subscription routes instead map `plan` to the vendor CLI's supported flag; that vendor owns its planning behavior and DGC does not synthesize a native plan artifact.
- **Artifacts** — the agent can serve a page/app/chart it builds. Project artifacts share one configurable server and persisted dropdown; proposed plans use a separate private loopback server so a LAN setting can never expose them. `/artifact` lists, opens, and stops both kinds.
- **Focus pane** — `/files` opens a file explorer *under* the transcript while the agent keeps working: three columns, previews, Git status, copy/cut/paste, rename, trash with undo (DGC's own trash or the OS trash via `trash_mode`), and **Enter** inserts `@path` into your prompt. Files the model changed this turn carry a mark. Writes follow the permission mode and stay inside the project; it never runs a shell. `/diff` opens the other occupant of the same pane: every changed file with its +/− counts and its diff, read live from Git while the turn runs; **Space** selects lines and **Enter** attaches them to your next prompt as a fenced diff, so a question can quote exactly the lines it is about.
- **Turn ETA** — the status line shows a calibrated range for the running turn (`~2–4 min left · 3/5 tasks`) learned from this project's own history and the turn's task list; `/eta stats` reports how often the range held. `/notify` pings the terminal when a turn finishes.
- **Standing goals** — `/goal <objective>` starts durable work in the CLI and editor, including selected skills, templates, file/image attachments and MCP snapshots. Native and subscription routes continue across work cycles, with completion evidence committed only after a successful cycle. The goal card supports pause, resume, edit, delete and review; work time excludes idle/offline time, and reopened active goals pause for review. `/goal --tokens N <objective>` adds an optional budget checked between requests or vendor turns. Three cycles without distinct tool progress block continuation for review. See [goals and selected context](docs/GOALS.md) for commands, route support and limits.
- **Continuation handoffs** — `/handoff` snapshots one generation-stable session, asks the configured model for a bounded self-contained continuation document, redacts it, and saves a new owner-private `HANDOFF-*.md` through the workspace mutation lease and atomic no-follow writer. Concurrent turns fail visibly instead of producing a mixed transcript. VS Code/Cursor renders the same typed result; headless controllers can request output-only or an atomic save.
- **In-app docs** — `/docs` opens a searchable how-to library right in the terminal (getting started, shortcuts, plan mode, artifacts, MCP, skills, sessions…), each page a scrollable reader.
- **Plan, review, and project guides** — `/plan TASK`, `/review [OPTIONS] [FOCUS]`, and `/init [FOCUS]` work in the interactive CLI, TUI, and editor. Inline selections preserve the draft until Send. Reviews inspect real changes in read-only mode; project guides use ordinary edit permissions after inspecting existing instructions. See [workflow commands](docs/WORKFLOWS.md).
- **Next-prompt suggestions** — after each turn DGC predicts a sensible follow-up as ghost text; press **Tab / →** to accept it (toggle with the `suggest` config). Title and suggestion generations wait for fleet-wide idle time, run serially with small output/stall caps, and are canceled before the next real prompt so they never compete with foreground local-model work.
- **Runs tiny local models** — if the endpoint has no native tool-calling, DGC auto-switches to a text tool-call protocol and parses it.
- **Code intelligence without lock-in** — `repo_map` inventories a project and `code_intel` finds symbols, exact definitions/references, and syntax diagnostics with a bounded built-in fallback. Configure a stdio language server for richer results; DGC confines returned paths to the project and safely reuses up to four project/spec sessions with serialized queries and idle cleanup. Set `code_intel_lsp_idle_s: 0` for one-shot isolation.
- **Adaptive tool and skill catalog** — ordinary coding turns keep the complete core read/edit/search/shell surface while web, artifact, skill-install, memory, goal, delegation, and reusable-skill metadata appear only when the request needs them. `bash_output`/`bash_kill` appear automatically only while that agent owns retained output/a background process, and full-auto omits the blocking options prompt. The system prefix stays stable throughout the day for provider/local prefix reuse, and text-only endpoints receive the same schemas as compact JSON instead of repeated formatting whitespace. This removes repeated irrelevant prefill for small local models; set `tool_profile: full` to expose the full catalog allowed by the current permission mode.
- **Auto context compaction** — near ~85% of your model's context window (configurable via `compact_threshold`), official OpenAI Responses endpoints use bounded loss-aware native compaction and durably replay its opaque continuation state; unsupported providers use the bounded local summarizer. Cancellation, malformed/oversized output, or summarizer failure falls back to a deterministic head-and-tail evidence brief instead of dropping prior context. `/compact` forces it.
- **Thinking modes** — `/think off|low|medium|high`; `think` / `think hard` / `ultrathink` in a prompt bump it for that turn. `<think>` streams dim.
- **Memory** — `DGC.md` in your project (and `~/.dgc/DGC.md` personal) load into native local/API sessions; delegated vendor turns do not receive that DGC memory injection. `#a fact` quick-adds; `/init` writes a project guide.
- **Web search** — the model gets a `web_search` tool. DuckDuckGo works keyless out of the box; add Brave/Tavily (API key) or SearXNG (self-hosted URL) via `dgc setup` or `/search`.
- **Session persistence** — every conversation is saved per project; `dgc --continue` resumes the most recent, `dgc --resume` picks one.
- **Credential-safe native loop and history** — live DGC/provider credentials plus high-confidence authorization, token, private-key, and password shapes are masked before native direct-model context, DGC tool results, native terminal/editor/headless/ACP output, saved plans, and persisted session text. Masking survives arbitrary native-provider stream chunk boundaries and preserves opaque signed/encrypted continuation fields. Delegated vendor-CLI streams shown by the full-screen TUI or subscription one-shot CLI are displayed as that vendor emits them after terminal-control cleanup, so treat vendor output as sensitive. A delegated vendor process is unsandboxed and inherits DGC's ambient environment; use a trusted CLI and expose only the secrets it needs. A credential-bearing approval can run once but can never create a persistent permission rule. Exact file rewind snapshots stay byte-for-byte correct inside the owner-private session; they are not text-redacted.
- **Durable checkpoints & rewind** — `/rewind` restores the exact pre-turn conversation plus direct file-tool and integrated sub-agent changes, including binary files, executable modes, symlinks, deletions, and new files. Project-root snapshots live atomically inside the private session, so they survive `/resume` and transcript compaction; a direct edit is refused if its pre-edit state cannot be saved. Arbitrary shell writes cannot be enumerated reliably, and explicitly approved external-path snapshots remain current-process only rather than becoming restart-time authority outside the project.
- **Self-update** — `dgc` checks for a newer version and flags it in the banner; `dgc update` installs it.
- **Skills** — ships [22 built-in workflows](docs/BUNDLED_SKILLS.md), including browser testing, CI diagnosis, PR feedback, skill authoring and MCP server development. Type `$` or `/` after existing draft text to select skills; the editor attaches removable chips and terminal clients insert exact mentions. Project/personal `.dgc/skills` and portable `.agents/skills` packages support metadata, enable/disable, create/install and reload. Explicit instructions reach native and subscription turns through bounded inputs; skills retain normal tool permissions and do not install dependencies or grant service access.
- **Sub-agents** — the `task` tool hands a self-contained job to a fresh autonomous sub-agent with its own context, transient root-scoped config, MCP runtime, cancellation, and correlated tool UI. In a Git project DGC creates a private checkout containing the caller's tracked and non-ignored untracked baseline, then applies only the child's delta after a content-level conflict check. In full-auto mode, an all-`task` model response fans independent calls out concurrently (four workers by default, bounded to eight): every child receives the same leased baseline, completed UI traces replay without interleaving, and integration happens in model-call order. Set `max_parallel_tasks: 1` to disable this. A child never auto-overwrites a file that was already dirty; overlapping, conflicting, or incomplete work is retained with its path and branch, while successful changes join the parent checkpoint and usage/edit accounting. `/tasks` lists preserved work; `/tasks apply ID` revalidates and applies its conflict-free delta into `/rewind`, while `/tasks drop ID --confirm` explicitly discards it. The VS Code/Cursor command palette exposes the same typed recovery flow. Sub-agents can run on a *different* local model/host than the main loop — set `subagent_model` / `subagent_base_url` globally (with that host's key in `DGC_SUBAGENT_API_KEY`), or define named agents in `.dgc/agents/<name>.md` (frontmatter: name, description, model, base_url, `api_mode`, `api_key_env`, effort) and pick one with the task tool's `agent` argument. Another host never receives the main provider key and auto-detects its own transport; `subagent_api_mode` overrides it. `/agents` lists them; `/subagent` sets the defaults.
- **MCP servers** — connect stdio MCP servers (configured in `~/.dgc/config.json` → `mcp_servers`) and their tools join DGC's own. A configured server command is a trusted executable: its process starts unsandboxed in the workspace, outside DGC's tool permissions and workspace mutation lease. DGC negotiates the stateless MCP 2026 wire with a fresh-process fallback for handshake-era servers, exposes a deterministic bounded tool catalog, honors validated cache TTL/scope metadata, and consumes ID-correlated `tools/list_changed` subscriptions with legacy notification compatibility. Small catalogs retain direct zero-round-trip tools; oversized catalogs fit context-relevant definitions into a model-window budget and expose `mcp_search` plus approval-gated `mcp_call`, so hidden or individually oversized definitions remain discoverable and callable without resending megabytes of schema every turn. Schema construction and bounded lexical indexing happen once per catalog generation, including ordinary word inflections, rather than repeatedly serializing every parameter definition on each model round. It bounds inbound/outbound frames and stalled writes, and carries roots MRTR, cancellation, progress, severity-filtered logs, typed content, and visible process failures. Form/URL elicitation and tools-free sampling are capability-negotiated and always user-gated: forms reject credential/payment fields and are validated before disclosure, URLs are never fetched or opened without consent, and sampling uses no project transcript or tools and requires approval before generation and again before its result reaches the server. `/mcp` shows each server's negotiated era and catalog state. Headless controllers use the typed `list_mcp_tools` and `call_mcp_tool` commands; exact calls retain the same permission, hook, lease, progress/input, cancellation, redaction, and output boundaries as model-issued calls.
- **Lifecycle hooks** — native local/API turns can run bounded shell commands on `SessionStart`, `UserPromptSubmit`, `PreToolUse`, `PostToolUse`, `PreCompact`, and `Stop` (config → `hooks`); delegated subscription turns expose only `SessionStart` and `Stop` because the vendor owns its prompt/tool loop. DGC-run hooks share the checkout lease, honor `/sandbox`, and expose command-free lifecycle status across terminal, editor, ACP, and headless clients. `/hooks` and typed `list_hooks` report only bounded event counts and redacted exact matchers—never configured commands or environment values.
- **Vision and file input** — on native local/API routes, the classic CLI and TUI share the same `@path/to/file` route. Text is
  redacted then bounded before entering context; images are byte-bounded and signature-checked.
  Quote paths containing spaces, for example `@"design references/home.png"`. An explicitly named
  external file is a one-file disclosure only—it does not grant the model access to its directory.
  Delegated subscription turns are text-only and reject pending image attachments.
- **Model fallback** — set `fallback_model` (and optional `fallback_base_url`) and DGC retries there if the primary model errors. Put another host's credential in `DGC_FALLBACK_API_KEY`; DGC never forwards the main provider key there, auto-detects its transport, and honors a `fallback_api_mode` override.
- **Custom slash-commands** — drop a Markdown prompt template in `.dgc/commands/*.md` and call it as `/name`; project commands appear in the classic/TUI/editor/ACP catalogs. Names begin with a lowercase letter/digit, then use lowercase letters/digits or `._-` (1–64 characters). Built-in names and aliases are reserved, catalogs/templates are bounded, and symlinked command directories or files are rejected.
- **Editor & ACP integration** — `dgc serve` backs the VS Code / Cursor extension through a generated protocol-v6 command/event contract with bounded frames and strict wire ordering. Permission, plan, option, and MCP decisions are exactly ID-correlated and first-response-wins; control frames bypass prompt backpressure, while expired, duplicate, mismatched, and post-restart responses fail closed. Typed `/skills` and `/handoff` routes render inert bounded metadata/Markdown and never forward built-in slash text to the model. Pasted images are count/byte bounded in the webview and revalidated by media signature before provider use; remote image URLs are rejected. Live multi-root changes are acknowledged and coalesced across active turns so added folders gain access and removed folders lose their session grant; editor context and `@file` mentions keep visible labels separate from typed canonical paths across roots. `dgc acp` speaks bounded UTF-8 Agent Client Protocol JSON-RPC over stdio, limits prompt blocks/text/images, and frames embedded resources as untrusted data.
- **Mid-turn steering and queueing** — in the full-screen terminal, a follow-up typed during a native
  model turn is injected at its next tool boundary. During a delegated subscription turn or direct
  `!` shell command—or once final response ownership has closed—the text is retained in a count/size-bounded per-session FIFO and
  starts as the next turn, including after cancellation or failure. The editor/headless backend
  separately executes up to 32 submitted turns in a count/aggregate-byte-bounded FIFO. Overflow is
  rejected visibly, and prompts submitted while a cancelled turn unwinds are not stranded.
  Editor, ACP, and terminal interrupts also remain effective during worker startup.
- **Tools** — `read_file` · `repo_map` · `code_intel` · `glob` · `grep` · `write_file` · `edit_file` · `multi_edit` · `apply_patch` · `bash` · `bash_output` · `bash_kill` · `web_fetch` · `web_search` · `todo` · `skill` · `add_skill` · `task` · `artifact` · `save_memory` · `present_plan` · `propose_options` · `update_goal`.
  Foreground command output is drained continuously through credential masking into a bounded,
  process-local result; oversized results can be searched literally or paged with `bash_output`
  without relying on a host `/tmp` path that may be invisible inside the sandbox. Background and
  retained-result handles are isolated to the originating agent session and expire after 30 minutes.
  An explicit terminal `!cmd` uses the same sandbox, bounded output, cancellation, checkout lease,
  and process-tree cleanup without asking the model to interpret the command.

## REPL conveniences

```
just type            ask DGC — it uses tools to act on your project
#fact                atomically quick-add project memory (`/memory add user TEXT` for personal)
!cmd                 run directly with DGC's shell boundary (Esc cancels in the TUI)
@path/to/file        attach one exact, bounded text or image file
Tab / →              accept the ghost-text next-prompt suggestion
/help                available commands ·  /keys  keyboard cheatsheet
/docs                in-app how-to guides
/artifact            open / stop localhost artifact previews
/view-plan           reopen the plan saved in plan mode
/files [PATH]        file explorer in the focus pane · Enter inserts @path
/diff [PATH]         every changed file, its counts and its diff, live · select lines for your prompt
/eta [stats]         how long the running turn still needs · calibration
/notify [on|off]     ping when the turn finishes
/goal <objective>    run objective · pause | resume | review | clear
/dashboard           session roster — open, switch, start, or delete sessions
```

## Commands

```
dgc                  interactive REPL
dgc setup            configure provider / model / context / web search
dgc doctor           verify the endpoint + model
dgc -c / --continue  resume the most recent session in this directory
dgc --resume         pick a past session to resume
dgc update           update DGC to the latest version
dgc serve            headless JSON backend (NDJSON over stdio) for editor extensions
dgc acp              Agent Client Protocol backend (stdio) for Zed / Neovim / …
dgc protocol describe --compact    inspect the installed protocol + slash surfaces as JSON
dgc -p "fix the bug in auth.py" --mode auto    one-shot, non-interactive
DGC_API_KEY=... dgc --model NAME --base-url URL  use an environment credential
```

For a configured MCP server, a `dgc serve` controller sends
`{"type":"list_mcp_tools","request_id":"catalog-1","offset":0,"limit":50}` and then
`{"type":"call_mcp_tool","request_id":"invoke-1","call_id":"call-1","name":"mcp__server__tool","arguments":{}}`.
Answer any emitted `permission_request` with its existing ID and a typed `permission_response`;
completion is the correlated `mcp_call_complete` event. The generated protocol-v6 JSON Schema is
`schemas/editor-protocol-v6.schema.json` and is also bundled in the installed Python package.
`dgc protocol describe --compact` reports its SHA-256, byte limits, required/optional fields, every
headless command/event, and the exact discoverable TUI/classic/editor slash catalogs without loading configuration
or contacting a model. `dgc protocol schema` prints the installed schema; validate fixture or captured
NDJSON with `dgc protocol validate command FILE` or `dgc protocol validate event FILE` (`-` reads
stdin). Validation emits one correlated JSON row per input line and exits nonzero if any frame fails.

Python controllers can use the dependency-free synchronous client instead of hand-rolling process
and NDJSON handling:

```python
from dgc.client import DGCClient

with DGCClient(cwd=".") as client:
    config = client.request(
        {"type": "get_config", "request_id": "config-1"},
        "config",
        request_id="config-1",
    )
    skills = client.request(
        {"type": "list_skills", "request_id": "skills-1"},
        "skill_catalog",
    )
```

`DGCClient` accepts a complete argv sequence (never a shell string), validates both wire directions,
retains unrelated events for `next_event()` / `wait_for()`, enforces decision-request IDs, bounds all
frames and buffers, and gracefully shuts down then reaps its child (including the isolated process
group on POSIX). A client instance is deliberately one-shot; create a new one after `close()` or any
protocol/transport failure.

The same controller can verify skill precedence with
`{"type":"list_skills","request_id":"skills-1"}` and receive a correlated `skill_catalog` whose
entries identify `project`, `user`, or `builtin` without absolute paths. It can generate a continuation
document with `{"type":"generate_handoff","request_id":"handoff-1","save":false}`; set `save` to
`true` to request a new atomic project-root file. `handoff_started` opens the cancellable foreground
lifecycle and the correlated `handoff` event closes it only after the worker slot is reusable.

## Manual install

```bash
git clone <your-repo-or-tarball> dgc && cd dgc
python3 -m venv .venv
.venv/bin/pip install -r requirements.lock
.venv/bin/pip install --no-deps -e .
.venv/bin/dgc setup
# optional: ln -sf "$PWD/.venv/bin/dgc" ~/.local/bin/dgc
```

## Let your agent install it

Paste this to any coding agent:

> Install DGC for me: run `curl -fsSL https://vibedgc.com/install.sh | bash`, then run `dgc setup` and connect it to my local Ollama (or ask me which provider). Verify with `dgc doctor`.

## Configuration

`~/.dgc/config.json` (created on first change; credentials are stored separately in owner-only
`~/.dgc/secrets.json`):

```json
{
  "base_url": "http://localhost:11434/v1",
  "model": "qwen3:8b",
  "api_mode": "auto",
  "provider_state": "stateless",
  "prompt_cache": true,
  "capability_cache_ttl_s": 300,
  "mode": "default",
  "thinking": "off",
  "context_size": 32768,
  "max_turns": 0,
  "max_parallel_tasks": 4,
  "fleet_worktree_root": "",
  "bash_timeout": 120,
  "sandbox": false,
  "sandbox_network": false,
  "plan_artifact": true,
  "artifact_in_plan": false,
  "compact_threshold": 0.85,
  "session_redaction": true,
  "search_provider": "duckduckgo",
  "permissions": {"allow": ["Bash(git status:*)"], "ask": [], "deny": ["Bash(rm -rf *)"]}
}
```

Set `context_size` to the operating window you want DGC to use — compaction timing and native
Ollama KV-cache allocation depend on it. Provider-reported hard limits clamp an oversized setting;
DGC never silently expands a local allocation to the model's trained maximum. `/model` applies a
memory-conscious recommendation for known model families (64K for Qwen3.8, whose native maximum is
256K); `/settings` or `/set context_size …` remains authoritative.
Set `subagent_worktree_root` only if private delegated checkouts should live somewhere other than
`~/.dgc/worktrees`; DGC rejects a task-worktree root inside the source repository.
Set `fleet_worktree_root` only to move automatically managed TUI checkouts from
`~/.dgc/fleet-worktrees`; DGC rejects storage inside the source repository. Conversation files stay
in the source project's private session scope so `/resume` can safely reconnect retained work.
`max_parallel_tasks` defaults to 4 (bounded to 8); set it to 1 when a local model server should
process delegated work strictly serially.
`session_redaction` defaults on and applies an additional credential pass whenever durable
conversation, checkpoint-message, goal, title, or plan state is written. Live model/tool/wire
credential masking and one-time-only sensitive approvals remain mandatory. Exact file rewind bytes
are intentionally unchanged and protected by the session directory's owner-only permissions.

With `api_mode: "auto"`, a directly detected Ollama endpoint uses its native `/api/chat`,
`/api/tags`, and `/api/show` contracts; DGC carries native thinking, tool history, `tool_name`, context/output
limits, sampling, keep-alive, multimodal data, and provider token counts without an OpenAI
translation layer. Set `api_mode` to `"ollama"` when Ollama sits behind a URL that cannot be
detected (for example, a loopback proxy), or to `"chat_completions"` to force compatibility mode.
Before the selected native model's first generation, DGC makes one bounded, short-lived metadata
request and caches the result by endpoint and model. Ollama's valid capability list selects native
tools, thinking, and vision before schemas are built; a text-only model therefore receives DGC's
text tool protocol on its first generation instead of spending a failed tool request. Anthropic's
Models API supplies the selected model's input/output limits and resolved ID, so impossible context
and output settings are clamped before use. Explicit capability and smaller operating limits still
win. Missing, malformed, oversized, or unavailable metadata is negative-cached briefly and falls
back to compatible behavior instead of blocking chat.
Context budgeting uses each adapter's provider-visible transcript and exact active tool schemas.
Validated base64 image transport is accounted through a bounded visual-dimension estimate rather
than misclassified as language text, so image compression does not cause premature compaction.
OpenAI-compatible tool streams preserve normal fragmented calls while also tolerating repeated or
cumulative ID/name/argument snapshots, string or omitted indices, and direct argument objects from
local gateways. Invalid non-object arguments are returned to the model for repair instead of
crashing the agent or executing a corrupted call.

A detected Anthropic endpoint uses the native `/v1/messages` contract and `x-api-key`
authentication rather than pretending Claude exposes Chat Completions. DGC maps canonical tool
schemas to `input_schema`, groups correlated `tool_result` blocks before following user content,
streams text/thinking/citations/tool JSON through the native event protocol, and replays valid
provider-signed thinking and server-owned continuation state exactly. Adaptive-capable Claude
generations receive adaptive thinking plus the selected effort control; older extended-thinking
models receive a bounded legacy budget below `max_tokens`. Unsupported
thinking is negotiated away once without abandoning the Messages transport. Anthropic model
discovery, cache-token accounting, cancellation, retry/backoff, base64 vision estimation, and error
responses use the same bounded lifecycle guarantees as the other native transports. Set
`api_mode` to `"anthropic"` only when a proxy hides the provider identity from its URL.

For OpenAI Responses, DGC defaults to `store: false`, locally preserves encrypted reasoning items
needed for tool-loop continuity, and derives a hashed cache-routing key when DGC creates the key;
an explicit `prompt_cache_key` of up to 64 characters is sent as configured. Set
`provider_state` to `"server"` only if you intentionally want provider-side response storage and
`previous_response_id` continuation. `provider_capabilities` can explicitly override feature flags
for a compatible endpoint; rejected features are retried after `capability_cache_ttl_s` rather than
being disabled forever. Across Responses, Chat Completions, native Anthropic Messages, and native
Ollama, transient retries
honor bounded `Retry-After` values but stop immediately on cancellation or a turn deadline; abandoned
streamed responses are always released before retry or transport fallback.

## Development

```bash
.venv/bin/python tests/run_tests.py   # units + end-to-end against a mock LLM server
./scripts/generate-editor-protocol.py # regenerate source/package JSON + TypeScript protocol contracts
./scripts/preflight.sh                # complete local release gate
```

See [AGENTS.md](AGENTS.md) for the layout and conventions, and
[bench/README.md](bench/README.md) for the controlled six-harness protocol.

## Security

DGC is a coding agent that runs shell commands and edits files on your machine. Worth knowing:

- **Ask-by-default.** In the shipped interactive native-loop `default` mode, reads are automatic while model-requested file writes and shell commands ask by baseline. Explicit deny/ask/allow rules are evaluated before that baseline. `auto` is the only mode whose baseline auto-approves both model-requested edits and shell commands, and DGC warns before entering it. A non-interactive `acceptEdits` run may apply structured file edits, but shell actions cannot proceed without an existing matching allow rule because there is no interactive approval path. Direct user `!cmd` commands are intentional user actions and do not prompt again. Subscription modes map into the vendor CLI's own flags. Use `default` / `acceptEdits` for anything you care about.
- **Your route, made explicit.** With a local model and local-only integrations, prompts and selected code can stay on your machine. A cloud model receives the conversation context it needs; remote web, search, MCP, and other integrations receive the requests or arguments you direct to them. A configured language server receives workspace metadata and the full text of queried documents.
- **Deny-rules** apply in every native local/API mode, including auto. They do not wrap a delegated vendor CLI's internal tools. Add native-loop hard blocks such as `/permissions deny Bash(rm -rf *)` or `/permissions deny Read(**/.env)`.
- **Prompt injection.** Web content is marked as untrusted data and private/link-local fetch targets are blocked. A hostile page or repository can still influence a model, so use `default` mode for untrusted work.
- **Optional OS confinement.** `/sandbox on` wraps native-loop spawned shell commands and hooks; it does not confine parent-process structured file tools or delegated vendor CLIs. Wrapped Linux/bubblewrap commands get private home/tmp/runtime and process namespaces; macOS/sandbox-exec instead uses policy enforcement with shared system temp paths. Both protect ambient home state and block network by default, normal approval prompts still apply, and unsupported platforms fail closed. `/sandbox` and `dgc doctor` report the exact active capability.
- **The installer** is non-root, installs the CLI under `~/dgc` with a launcher in `~/.local/bin`, and the production path requires a matching published SHA-256. A custom/private mirror can explicitly opt into `DGC_ALLOW_UNVERIFIED=1`. When a supported editor CLI is on `PATH`, the installer also installs the checksum-verified extension into that editor unless `DGC_SKIP_EXTENSION=1` is set. The current GitHub release carries build-provenance attestations, and the release workflow is configured to produce them for future tagged builds.

## License

[Apache License 2.0](LICENSE) © 2026 Mohit Kalra.
